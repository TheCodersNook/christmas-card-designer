# chilledbeer-studio

Edit your talking-head videos into finished YouTube videos and Reels with a free AI model in
[OpenCode](https://opencode.ai). It edits in the ChilledBeer style:
- cuts on whole sentences;
- zoom punch-ins on your key words;
- you placed inside the thing you talk about (a video editor, a phone, a TV, a browser);
- clean animations and transitions;
- music under your voice.

The editing judgement is in the code, not the model, so a free model is enough: the model runs the steps, fixes
misheard words and applies your feedback.

Shared by [@ChilledBeer](https://www.youtube.com/@ChilledBeer). Free to use for your own videos.

## Setup on a Mac

```bash
curl -fsSL https://opencode.ai/install | bash          # then open a new terminal
brew install uv ffmpeg whisper-cpp                     # whisper-cpp is optional (faster transcription)
cd path/to/chilledbeer-studio
./setup.sh                                             # add --model to download the whisper.cpp model
```

## Setup on Windows (through WSL)

Everything runs inside WSL (Ubuntu on Windows):

1. In PowerShell (as administrator): `wsl --install`. Restart, then open **Ubuntu** from the Start menu.
2. Inside Ubuntu, copy this folder into your Linux home (for example `cp -r /mnt/c/Users/<you>/Downloads/chilledbeer-studio ~/`).
   Then run:
   ```bash
   sudo apt update && sudo apt install -y ffmpeg unzip
   curl -LsSf https://astral.sh/uv/install.sh | sh
   curl -fsSL https://opencode.ai/install | bash
   exec bash                                           # reload the PATH
   cd ~/chilledbeer-studio && ./setup.sh
   ```
3. Your Windows files are under `/mnt/c/Users/<you>/...`, so a video in Downloads is
   `/mnt/c/Users/<you>/Downloads/my_take.mp4`.

Run OpenCode **inside Ubuntu/WSL** with this project in your Linux home. The Windows desktop app or
PowerShell alone will not run the `./cb` workflow. OpenCode's AI model can be cloud-hosted on either
platform; the video rendering and CPU-only transcription happen on your own computer.

## Use it

1. Put your video in `inputs/`, or drag it into the OpenCode chat later.
2. In this folder, run `opencode`. Pick a model with `/models`: the free ones need no login (for example GLM-5.3
   Flash, free for a limited time).
3. Type `/edit my_take.mp4` for a 16:9 YouTube video, or `/reel my_take.mp4` for a 9:16 Reel or Short.
4. Watch `edits/my_take/out/my_take.mp4`. For changes, type for example
   `/fix the music is too loud and zoom on "stop"`.

`PROMPT.md` has the full prompt to paste if the slash commands don't show up.

With no AI model at all, one command still makes an edit:

```bash
./cb make inputs/my_take.mp4            # add --reel for 9:16, --draft for a fast preview
```

## Good to know

- **Music:** none is included. Add your own tracks to `music/` (see `music/README.md`).
- **Computer load:** the editor uses several render workers when hardware allows, capped by available
  CPU, memory and video resolution. On Windows/WSL, when at least two logical CPUs are available
  and the OS permits it, it also pins editing and its child processes to no more than 75% of
  those CPUs. On macOS the worker limits and lower priority
  leave headroom, but no exact CPU/GPU percentage is guaranteed. Transcription and rendering use
  CPU paths; choose a cloud-hosted OpenCode model instead of a local GPU model while editing.
- **Your handle:** `edit.json` has a `"handle"` (shown on the phone and post scenes). Set it to your own.
- **What it can't do:** it can't capture screenshots of websites by itself. Drop them in `assets/` and ask it to use
  them.
- **Speed:** a 3-4 minute video takes a few minutes to edit plus the render. Long jobs run in the background
  (`./cb start` + `./cb wait`), so OpenCode's command timeout never kills a render.
- **Quality:** it's a strong first cut. Every scene can be changed with `/fix` and a timestamp.

## What's in here

| Path | What |
|---|---|
| `AGENTS.md` | the step-by-step workflow the AI follows (OpenCode loads it automatically) |
| `PROMPT.md` | what to type in OpenCode |
| `.opencode/skills/chilledbeer-edit/` | the editing style, the scene library and the render engine |
| `.opencode/commands/` | `/edit`, `/reel`, `/fix`, `/status` |
| `cb` | runs the engine (`./cb doctor`, `./cb make`, `./cb start`, `./cb wait`, ...) |
| `inputs/` | your videos (never modified) |
| `edits/<name>/` | each video's plan, script, report and output |
| `assets/`, `music/` | your screenshots and your music |

Third-party parts (the fonts and the face-detection model) are listed in `NOTICE.md`.
