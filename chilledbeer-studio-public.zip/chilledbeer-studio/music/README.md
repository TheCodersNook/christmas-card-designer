# Music

The project ships with no music: tracks from music libraries can't be passed around in a zip. Add your own:

- `long/`: calm beds for YouTube videos (lo-fi, chill, soft piano). They sit about 18 dB under your voice.
- `reel/`: livelier beds for Reels and Shorts. They sit about 12 dB under.

The editor picks one track per video from the right folder. With both folders empty, videos have no music.

Free, legal sources: the YouTube Audio Library (YouTube Studio > Audio Library), Pixabay Music, Mixkit. Check each
track's licence, and put any credit it asks for in your video's description.
