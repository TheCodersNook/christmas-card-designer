#!/usr/bin/env bash
# One-time setup (macOS, Linux, or Windows through WSL): checks the tools the engine needs and installs its Python deps.
#   ./setup.sh            check the tools + install the Python deps
#   ./setup.sh --model    also download the whisper.cpp model (~550 MB) if you use whisper.cpp
# Transcription works out of the box with faster-whisper (installed with the deps); whisper.cpp is optional and faster.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
say() { printf '%s\n' "$*"; }
need() { command -v "$1" >/dev/null 2>&1; }
if [ "$(uname)" = "Darwin" ]; then PKG="brew install"; else PKG="sudo apt install -y"; fi

missing=0
if need uv; then say "ok    uv"; else say "MISSING uv     -> curl -LsSf https://astral.sh/uv/install.sh | sh"; missing=1; fi
if need ffmpeg; then say "ok    ffmpeg"; else say "MISSING ffmpeg -> $PKG ffmpeg"; missing=1; fi
if need opencode || [ -x "$HOME/.opencode/bin/opencode" ]; then say "ok    opencode"
else say "note  opencode not installed -> curl -fsSL https://opencode.ai/install | bash   (then open a new terminal)"; fi
[ "$missing" = 0 ] || { say "Install the missing tools, then run ./setup.sh again."; exit 1; }

if need whisper-cli; then
  model="${CBEDIT_WHISPER_MODEL:-}"
  for g in "$HOME/.cache/whisper.cpp/"ggml-*.bin; do [ -z "$model" ] && [ -f "$g" ] && model="$g"; done
  if [ -n "$model" ]; then say "ok    whisper.cpp model: $model"
  elif [ "${1:-}" = "--model" ]; then
    mkdir -p "$HOME/.cache/whisper.cpp"
    curl -L --fail -o "$HOME/.cache/whisper.cpp/ggml-large-v3-turbo-q5_0.bin" \
      "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin"
    say "ok    whisper.cpp model downloaded to ~/.cache/whisper.cpp"
  else say "note  whisper.cpp has no model: ./setup.sh --model (or it falls back to faster-whisper)"; fi
else
  say "note  no whisper.cpp: transcription uses faster-whisper (slower; brew install whisper-cpp on a Mac is faster)"
fi

uv sync --project "$HERE" --quiet
"$HERE/cb" doctor
say ""
say "Ready. Put a video in inputs/, run 'opencode' in this folder, pick a model with /models, and type: /edit <file>"
