# What to type in OpenCode

## 1. Open the project

Terminal:

```bash
cd path/to/chilledbeer-studio
opencode
```

OpenCode desktop app: open the chilledbeer-studio folder as the project.

Pick a cloud-hosted model with `/models`. The free hosted ones need no login. Avoid local Ollama/MLX models while
editing: their GPU load is outside this editor's resource guard.

**Resource rule:** editing must leave the computer usable on macOS or Windows/WSL. `./cb` limits
render workers and transcription threads, uses CPU rather than GPU processing, and on WSL with
at least two cores restricts the engine and its child processes to no more than 75% of available
logical CPUs when the OS permits it. On macOS the worker
limits are best effort; no exact 75% utilization guarantee is possible. Do not bypass these limits.

## 2. Give it the video (either way works)

- **Put it in `inputs/`** (Finder: drag the file into the `inputs` folder), then type its name.
- **Or drag the video straight into the OpenCode chat**, or type `@` and pick the file, or paste its path. It copies
  the video into `inputs/` itself (your original is never touched). OpenCode may ask once for permission to read a
  folder outside the project (Downloads, Desktop): allow it. If a big file won't attach, use `inputs/` instead.

## 3. Type one line

YouTube video (16:9):
```
/edit my_take.mp4
```

Reel or Short (9:16):
```
/reel my_take.mp4
```

Instead of `my_take.mp4` you can drag the file in right after `/edit `.

If the slash commands don't show up, paste this instead (change the file name, and `16:9 YouTube video` to `9:16 Reel`
for a Reel):

```
Edit my video in my style. The take: my_take.mp4 (if it isn't in inputs/, run ./cb add "<path>" first).
Format: 16:9 YouTube video.
Load the chilledbeer-edit skill (.opencode/skills/chilledbeer-edit/SKILL.md), read AGENTS.md, and follow
"The workflow" steps 0 to 7 exactly. Use only ./cb commands; long jobs go through ./cb start and ./cb wait
until FINISHED. Keep the computer responsive; don't bypass the automatic worker cap or enable GPU processing. When done, tell me
the video path, its length, what you changed, and what is still open.
```

You can add notes after the file name, for example:
`/edit my_take.mp4 keep it fast, put me in the TV when I say breaking news`.

## 4. Watch it, then give feedback

The video is at `edits/<name>/out/<name>.mp4`, and one frame of every beat is at `edits/<name>/out/stills.jpg`.

```
/fix the music is too loud, remove the line "like we all know that", and zoom on "stop"
```

`/status` lists what has been edited and where the videos are.
