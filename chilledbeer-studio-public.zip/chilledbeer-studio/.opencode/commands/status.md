---
description: List the takes, the edits and their renders
---
Summarise for them, in a short list: which takes are in inputs/, which have an edit, and the final video path and
length of each edit (from its out/ folder). Don't run any render.

!`ls -1 inputs; echo ---; for d in edits/*/; do echo "$d"; ls -1 "$d"out 2>/dev/null; done`
