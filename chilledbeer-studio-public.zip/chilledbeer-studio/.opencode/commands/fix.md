---
description: Apply the creator's feedback to the latest edit and re-render
---
Load the `chilledbeer-edit` skill. Apply this feedback to the edit they mean (the newest folder in edits/ unless they
name one), following AGENTS.md "Editing the plan by hand" and its feedback table:

$ARGUMENTS

Rules: change only what the feedback asks for; never run `./cb auto` again; after editing run `./cb check` (0 errors),
then `./cb start render <edit.json>` + `./cb wait` until FINISHED, and `./cb qa`. Report what you changed in a few lines.

Edits, newest first:
!`ls -1t edits 2>/dev/null | head -5`
