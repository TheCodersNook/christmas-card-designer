---
description: Edit a take into a finished 16:9 YouTube video in the ChilledBeer style (give a file name in inputs/ or drag a video in)
---
Load the `chilledbeer-edit` skill (.opencode/skills/chilledbeer-edit/SKILL.md) and read AGENTS.md.

The take they gave: $ARGUMENTS

Step 0: if that is not already a file inside inputs/ (a dragged or attached file, a path anywhere, an @file), run
`./cb add "<that path>"` first and use the inputs/ path it prints. If they gave only a name, it is inputs/<name>. If they
gave nothing, use the newest file in inputs/.

Then follow AGENTS.md "The workflow" steps 1-7 exactly, as a 16:9 YouTube video (no --reel).

Files currently in inputs/:
!`ls -1t inputs`
