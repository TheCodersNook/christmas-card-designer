---
description: Edit a take into a 9:16 Reel / YouTube Short in the ChilledBeer style (give a file name in inputs/ or drag a video in)
---
Load the `chilledbeer-edit` skill (.opencode/skills/chilledbeer-edit/SKILL.md) and read AGENTS.md.

The take they gave: $ARGUMENTS

Step 0: if that is not already a file inside inputs/ (a dragged or attached file, a path anywhere, an @file), run
`./cb add "<that path>"` first and use the inputs/ path it prints. If they gave only a name, it is inputs/<name>. If they
gave nothing, use the newest file in inputs/.

Then follow AGENTS.md "The workflow" steps 1-7 exactly, as a Reel: step 1 is
`./cb start make inputs/<file> --draft --reel` (then `./cb wait` until FINISHED). A Reel is a complete mini-talk in
whole sentences with no end screen. If the take is longer than ~90 s, use the strongest self-contained 30-75 s
stretch (drop the rest with `./cb cut ... --drop`) and say which part you kept.

Files currently in inputs/:
!`ls -1t inputs`
