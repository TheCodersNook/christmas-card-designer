"""cbedit: the ChilledBeer editing style as a command line.

  python -m cbedit doctor                         what is installed (ffmpeg, numpy, Pillow, a transcriber, OpenCV)
  python -m cbedit init take.mp4 [--reel] [--dir edits/name] [--transcript words.json|subs.srt]
                                                  transcribe + sentence-safe cut + a starter edit.json + script.txt
  python -m cbedit make take.mp4 [--reel] [--music DIR] [--draft] [--transcript f]
                                                  EVERYTHING in one go: init, faces, auto plan, gate, stills, render, QA
  python -m cbedit auto edit.json [--music DIR] [--no-recut]
                                                  the automatic director: tidy cut + a gate-clean plan + auto_report.md
  python -m cbedit cut edit.json [--drop s3,s7] [--drop-words 120,121] [--pause 0.32] [--start 2 --end 95] [--fillers]
                                                  re-cut (whole sentences) and rewrite script.txt
  python -m cbedit words edit.json [--find Cloud]   word ids with output times (for respell, punch, type)
  python -m cbedit faces edit.json                face centres for the lens (needs OpenCV)
  python -m cbedit check edit.json                the style gate (0 errors before any render)
  python -m cbedit stills edit.json --at 1,4.5,w120 [-o sheet.jpg]
                                                  frames exactly as the render draws them, on one sheet
  python -m cbedit render edit.json [--draft] [--workers N]   resource-capped parallel render
  python -m cbedit qa out/name.mp4 [--sheet sheet.jpg]
"""
from __future__ import annotations

import argparse
import importlib
import importlib.util
import json
import os
import re
import shutil
import sys
from pathlib import Path

from .resources import apply_cpu_affinity

apply_cpu_affinity()


def _doctor(a):
    ok = True
    for mod in ("numpy", "PIL"):
        try:
            importlib.import_module(mod)
            print(f"ok    {mod}")
        except ImportError:
            ok = False
            print(f"MISSING {mod}  (pip install numpy pillow)")
    from .media import ffmpeg
    try:
        print(f"ok    ffmpeg {ffmpeg()}")
    except SystemExit as e:
        ok = False
        print(f"MISSING {e}")
    print(("ok    " if shutil.which("ffprobe") else "note  ") + "ffprobe" + ("" if shutil.which("ffprobe") else
                                                                            " (optional; frame counts are skipped)"))
    tr = [n for n in ("whisper-cli", "whisper-cpp") if shutil.which(n)]
    for mod in ("faster_whisper", "whisper"):
        # found, not imported: faster-whisper's PyAV and OpenCV each bundle libavdevice, and loading both in one
        # process makes macOS print duplicate-class warnings
        if importlib.util.find_spec(mod) is not None:
            tr.append(mod)
    print(("ok    transcriber: " + ", ".join(tr)) if tr else
          "note  no transcriber: pip install faster-whisper (or bring words.json / an .srt with --transcript)")
    try:
        import cv2  # noqa
        print("ok    opencv (face-centred lens)")
    except ImportError:
        print("note  no OpenCV: the lens centres on (0.5, 0.42); pip install opencv-python-headless")
    from .resources import cpu_budget, ffmpeg_threads, render_workers, whisper_threads
    print(f"resource guard: up to {render_workers(1080)} workers at 1080p, {render_workers(2160)} at 4K, "
          f"{ffmpeg_threads()} thread per FFmpeg decoder/encoder, {whisper_threads()} Whisper CPU threads, "
          f"GPU off; budget {cpu_budget()} logical CPUs")
    return 0 if ok else 1


def _init(a):
    from .media import probe
    from .words import build_cut, script, sentences, transcribe
    src = Path(a.video).resolve()
    d = Path(a.dir or (Path.cwd() / "edits" / src.stem)).resolve()
    d.mkdir(parents=True, exist_ok=True)
    wf = d / "words.json"
    if not wf.exists() or a.transcript:
        print("transcribing ...")
        transcribe(src, wf, language=a.lang, engine=a.engine, model=a.model, transcript=a.transcript)
    words = json.loads(wf.read_text())["words"]
    segs, sents = build_cut("a", src, words, pause=a.pause)
    info = probe(str(src))
    (d / "cut.json").write_text(json.dumps(dict(pause=a.pause, drop=[], drop_words=[], segments=segs), indent=1))
    reel = a.reel
    edit = {
        "name": src.stem,
        "format": "9:16" if reel else "16:9",
        "kind": "reel" if reel else "long",
        "res": 1080,
        "sources": {"a": str(src)},
        "words": "words.json",
        "cut": "cut.json",
        "speed": 1.0,
        "look": "white",
        "accent": "#F0412B",
        "grade": "clean",
        "handle": "@yourhandle",
        "jumpcut": True,
        "captions": "full" if reel else "off",
        "music": {"file": None, "db": -12 if reel else -18, "duck": True},
        "punch": [],
        "beats": [{"at": 0, "stage": "full", "cam": "push", "why": "the hook on his face"}],
        "type": [],
    }
    ef = d / "edit.json"
    if ef.exists() and not a.force:
        print(f"kept the existing {ef} (use --force to overwrite)")
    else:
        ef.write_text(json.dumps(edit, indent=2))
    txt, dur = script(words, sents, segs, 1.0, info["fps"])
    (d / "script.txt").write_text(txt + "\n")
    print(f"{len(words)} words, {len(sents)} sentences, {len(segs)} segments -> {dur:.1f}s after the pause trim")
    print(f"wrote {d}/words.json, cut.json, edit.json, script.txt")
    return 0


def _cut(a):
    from .media import probe
    from .plan import Plan
    from .words import build_cut, script
    ef = Path(a.edit).resolve()
    j = json.loads(ef.read_text())
    d = ef.parent
    src_key = next(iter(j["sources"]))
    src = Path(j["sources"][src_key]).expanduser()
    src = src if src.is_absolute() else d / src
    wfile = j["words"] if isinstance(j["words"], str) else j["words"][src_key]
    words = json.loads((d / wfile).read_text())["words"]
    cf = d / (j["cut"] if isinstance(j.get("cut"), str) else "cut.json")
    old = json.loads(cf.read_text()) if cf.exists() else {}
    # drops add up (the director's tidy-up stays) unless --reset; --keep takes sentences back
    base = [] if a.reset else old.get("drop", [])
    drop = sorted(set(base) | {int(x.strip().lstrip("s")) for x in (a.drop or "").split(",") if x.strip()})
    drop = [k for k in drop if k not in {int(x.strip().lstrip("s")) for x in (a.keep or "").split(",") if x.strip()}]
    basew = [] if a.reset else old.get("drop_words", [])
    dropw = sorted(set(basew) | {int(x.strip().lstrip("w")) for x in (a.drop_words or "").split(",") if x.strip()})
    pause = a.pause or old.get("pause", 0.32)
    start = a.start if a.start is not None else old.get("start")
    end = a.end if a.end is not None else old.get("end")
    segs, sents = build_cut(src_key, src, words, drop, dropw, pause, start, end, a.fillers)
    cf.write_text(json.dumps(dict(pause=pause, drop=drop, drop_words=dropw, start=start, end=end, segments=segs),
                             indent=1))
    info = probe(str(src))
    txt, dur = script(words, sents, segs, float(j.get("speed", 1.0)), info["fps"])
    (d / "script.txt").write_text(txt + "\n")
    print(txt)
    print(f"-> {len(segs)} segments, {dur:.1f}s")
    return 0


def _make(a):
    from .media import probe
    src = Path(a.video).resolve()
    d = Path(a.dir or (Path.cwd() / "edits" / src.stem)).resolve()
    ef = d / "edit.json"
    if not ef.exists():
        _init(argparse.Namespace(video=str(src), dir=str(d), reel=a.reel, lang=a.lang, engine="auto", model=None,
                                 transcript=a.transcript, pause=0.32, force=False))
    if a.res:
        j = json.loads(ef.read_text())
        j["res"] = a.res
        ef.write_text(json.dumps(j, indent=2))
    from .plan import Plan
    try:
        import cv2  # noqa
        if not (d / ".cbedit" / "faces.json").exists():
            from .lens import detect_faces
            detect_faces(Plan(ef))
    except ImportError:
        print("faces: no OpenCV, the lens uses the default centre")
    from .auto import run
    if run(ef, music_dir=a.music):
        print("the gate found errors: read auto_report.md")
        return 1
    from .render import render, stills, prepare_events
    plan = Plan(ef)
    prepare_events(plan)
    mids = [round((b["t0"] + b["t1"]) / 2, 2) for b in plan.beats][:24]
    (d / "out").mkdir(exist_ok=True)
    stills(ef, mids, d / "out" / "stills.jpg")
    print(f"stills: {d / 'out' / 'stills.jpg'}")
    out = render(ef, draft=a.draft)
    from .qa import qa
    qa(out, sheet=str(d / "out" / "sheet.jpg"))
    print(f"\nDONE  video: {out}\n      report: {d / 'auto_report.md'}\n      script: {d / 'script.txt'}")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="cbedit", description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sp = p.add_subparsers(dest="cmd", required=True)
    sp.add_parser("doctor")
    x = sp.add_parser("init")
    x.add_argument("video")
    x.add_argument("--dir")
    x.add_argument("--reel", action="store_true")
    x.add_argument("--lang", default="en")
    x.add_argument("--engine", default="auto")
    x.add_argument("--model")
    x.add_argument("--transcript")
    x.add_argument("--pause", type=float, default=0.32)
    x.add_argument("--force", action="store_true")
    x = sp.add_parser("cut")
    x.add_argument("edit")
    x.add_argument("--drop")
    x.add_argument("--drop-words")
    x.add_argument("--pause", type=float)
    x.add_argument("--start", type=float)
    x.add_argument("--end", type=float)
    x.add_argument("--fillers", action="store_true")
    x.add_argument("--keep", help="sentence ids to take back")
    x.add_argument("--reset", action="store_true", help="forget earlier drops")
    x = sp.add_parser("make")
    x.add_argument("video")
    x.add_argument("--dir")
    x.add_argument("--reel", action="store_true")
    x.add_argument("--music", default=os.environ.get("CBEDIT_MUSIC"))
    x.add_argument("--draft", action="store_true")
    x.add_argument("--transcript")
    x.add_argument("--lang", default="en")
    x.add_argument("--res", type=int)
    x = sp.add_parser("auto")
    x.add_argument("edit")
    x.add_argument("--music", default=os.environ.get("CBEDIT_MUSIC"))
    x.add_argument("--no-recut", action="store_true")
    x = sp.add_parser("words", help="word ids with their times (to respell, punch or time type)")
    x.add_argument("edit")
    x.add_argument("--find", help="only words containing this text (case-insensitive)")
    x.add_argument("--word", help="only this whole word (case-insensitive, punctuation ignored)")
    for name in ("faces", "check"):
        x = sp.add_parser(name)
        x.add_argument("edit")
    x = sp.add_parser("stills")
    x.add_argument("edit")
    x.add_argument("--at", help="times or word ids, comma separated")
    x.add_argument("--auto", action="store_true", help="one frame from the middle of every beat")
    x.add_argument("-o", "--out")
    x.add_argument("--final", action="store_true", help="at the final resolution (default: draft size)")
    x = sp.add_parser("render")
    x.add_argument("edit")
    x.add_argument("--draft", action="store_true")
    x.add_argument("--workers", type=int)
    x.add_argument("-o", "--out")
    x = sp.add_parser("qa")
    x.add_argument("video")
    x.add_argument("--sheet")
    a = p.parse_args(argv)

    if a.cmd == "doctor":
        return _doctor(a)
    if a.cmd == "init":
        return _init(a)
    if a.cmd == "cut":
        return _cut(a)
    if a.cmd == "make":
        return _make(a)
    if a.cmd == "auto":
        from .auto import run
        return 1 if run(a.edit, music_dir=a.music, recut=not a.no_recut) else 0
    if a.cmd == "qa":
        from .qa import qa
        return qa(a.video, sheet=a.sheet)
    from .plan import Plan
    if a.cmd == "words":
        p = Plan(a.edit)
        bare = lambda x: re.sub(r"[^\w']+", "", x.lower())
        ws = [w for w in p.wlist if (not a.find or a.find.lower() in w["w"].lower())
              and (not a.word or bare(w["w"]) == bare(a.word))]
        line = []
        for w in ws:
            line.append(f"{w['id']}@{w['s']:.2f}:{w['w']}")
            if len(line) == 8:
                print("  ".join(line))
                line = []
        if line:
            print("  ".join(line))
        return 0
    if a.cmd == "faces":
        from .lens import detect_faces
        detect_faces(Plan(a.edit))
        return 0
    if a.cmd == "check":
        from .check import report
        from .render import prepare_events
        plan = Plan(a.edit)
        prepare_events(plan)
        return 1 if report(plan) else 0
    if a.cmd == "stills":
        from .render import stills
        out = a.out or str(Path(a.edit).resolve().parent / "out" / "stills.jpg")
        Path(out).parent.mkdir(exist_ok=True, parents=True)
        if a.auto or not a.at:
            pl = Plan(a.edit)
            times = [round((b["t0"] + b["t1"]) / 2, 2) for b in pl.beats][:30]
        else:
            times = [x if x.startswith(("w", "b:")) or ":" in x else float(x) for x in a.at.split(",")]
        print(stills(a.edit, times, out, draft=not a.final))
        return 0
    if a.cmd == "render":
        from .check import check
        from .render import prepare_events, render
        plan = Plan(a.edit, draft=a.draft)
        prepare_events(plan)
        E, W, _ = check(plan)
        if E:
            for e in E:
                print("ERROR " + e)
            print("render stopped: fix the plan (cbedit check) first")
            return 1
        render(a.edit, draft=a.draft, out=a.out, workers=a.workers)
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
