"""Words in, a sentence-safe cut out.

transcribe(): word timings from whichever engine is here (whisper.cpp's whisper-cli, faster-whisper, openai-whisper),
or an existing transcript (a words JSON, or an SRT, spread evenly per line).
build_cut(): keep whole sentences, trim pauses with edges in real quiet (the voice envelope decides, not the word
times, which absorb or clip syllables), drop the sentences and words the plan names.
"""
from __future__ import annotations

import glob
import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np

from .media import ffmpeg, load_audio, probe
from .resources import whisper_threads

FILLERS = {"um", "umm", "uh", "uhh", "erm", "hmm", "mm", "ah", "aah"}
MODEL_GLOBS = [
    os.environ.get("CBEDIT_WHISPER_MODEL", ""),
    "~/.cache/whisper.cpp/ggml-*.bin", "~/models/ggml-*.bin", "./models/ggml-*.bin",
    "/opt/homebrew/share/whisper-cpp/ggml-*.bin", "/usr/local/share/whisper-cpp/ggml-*.bin",
]


def _norm(text):
    return re.sub(r"[^\w']+", "", text.lower())


def _save(words, out, src, engine, language):
    words = [dict(i=i, w=w["w"].strip(), s=round(float(w["s"]), 3), e=round(float(w["e"]), 3))
             for i, w in enumerate(x for x in words if x["w"].strip())]
    Path(out).write_text(json.dumps(dict(source=str(src), engine=engine, language=language, words=words), indent=0))
    return words


def from_json(path):
    j = json.loads(Path(path).read_text())
    ws = j.get("words") if isinstance(j, dict) else j
    if ws is None and isinstance(j, dict):
        ws = j.get("transcript", {}).get("words")
    out = []
    for w in ws:
        t = w.get("w", w.get("word", w.get("text", "")))
        out.append(dict(w=t, s=w.get("s", w.get("start")), e=w.get("e", w.get("end"))))
    return out


def from_srt(path):
    out = []
    blocks = re.split(r"\n\s*\n", Path(path).read_text(encoding="utf-8", errors="ignore"))
    ts = lambda s: sum(float(x) * m for x, m in zip(s.replace(",", ".").split(":"), (3600, 60, 1)))
    for b in blocks:
        m = re.search(r"(\d+:\d+:\d+[,.]\d+)\s*-->\s*(\d+:\d+:\d+[,.]\d+)\s*\n(.+)", b, re.S)
        if not m:
            continue
        a, z = ts(m.group(1)), ts(m.group(2))
        toks = m.group(3).replace("\n", " ").split()
        n = max(1, len(toks))
        for i, t in enumerate(toks):
            out.append(dict(w=t, s=a + (z - a) * i / n, e=a + (z - a) * (i + 0.9) / n))
    return out


def _dtw_preset(name):
    n = name.lower().replace("ggml-", "").split(".bin")[0]
    n = re.sub(r"-q\d.*$", "", n)
    for key, preset in (("large-v3-turbo", "large.v3.turbo"), ("large-v3", "large.v3"), ("large-v2", "large.v2"),
                        ("large-v1", "large.v1"), ("medium.en", "medium.en"), ("medium", "medium"),
                        ("small.en", "small.en"), ("small", "small"), ("base.en", "base.en"), ("base", "base"),
                        ("tiny.en", "tiny.en"), ("tiny", "tiny")):
        if n.startswith(key):
            return preset
    return None


def _wav16(src, tmp):
    wav = Path(tmp) / "a16.wav"
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-i", str(src), "-vn", "-ac", "1", "-ar", "16000", str(wav)],
                   check=True)
    return wav


def _whisper_cpp(src, language, tmp):
    exe = shutil.which("whisper-cli") or shutil.which("whisper-cpp") or shutil.which("main")
    if not exe:
        return None
    model = None
    for g in MODEL_GLOBS:
        if not g:
            continue
        hits = sorted(glob.glob(os.path.expanduser(g)))
        if hits:
            model = hits[0]
            break
    if not model:
        return None
    wav = _wav16(src, tmp)
    base = Path(tmp) / "wcpp"
    # full JSON with DTW token times (accurate onsets) and a punctuated prompt (whisper drops punctuation without one)
    cmd = [exe, "-ng", "-t", str(whisper_threads()), "-m", model, "-f", str(wav), "-ojf", "-of", str(base), "-np", "-l", language or "auto",
           "--prompt", "Hi everyone, welcome back. So, in this video, I'll show you how I do it. Right?"]
    preset = _dtw_preset(Path(model).name)
    if preset:
        cmd += ["-nfa", "-dtw", preset]
    r = subprocess.run(cmd, capture_output=True, text=True)
    jf = Path(str(base) + ".json")
    if r.returncode != 0 or not jf.exists():
        return None
    j = json.loads(jf.read_text(errors="ignore"))
    toks = []
    for seg in j.get("transcription", []):
        for tk in seg.get("tokens", []):
            t = tk.get("text", "")
            if not t or t.startswith("[_") or t.startswith("<|"):
                continue
            d = tk.get("t_dtw", -1)
            st = d / 100 if (d is not None and d >= 0) else tk["offsets"]["from"] / 1000
            toks.append((t, st, tk["offsets"]["to"] / 1000))
    out = []
    for t, st, en in toks:
        new = t.startswith(" ") and re.search(r"\w", t)
        if new or not out:
            out.append(dict(w=t.strip(), s=st, e=en))
        else:
            out[-1]["w"] += t.strip() if not t.startswith(" ") else t
            out[-1]["e"] = max(out[-1]["e"], en)
    # a word ends where the next one starts (DTW gives onsets); long gaps are left to the voice envelope
    for a_, b_ in zip(out, out[1:]):
        a_["e"] = max(a_["s"] + 0.05, min(b_["s"] - 0.01, a_["s"] + max(0.12, min(0.9, a_["e"] - a_["s"]))))
    if out:
        out[-1]["e"] = max(out[-1]["s"] + 0.1, out[-1]["e"])
    return out, "whisper.cpp " + Path(model).name


def _faster(src, language, model):
    """faster-whisper in a child process (CPU, the resource guard's threads): its PyAV and OpenCV each bundle
    libavdevice, and one process loading both (transcription, then the face track in `make`) makes macOS warn of
    duplicate classes and risks a crash."""
    import importlib.util
    import sys
    if importlib.util.find_spec("faster_whisper") is None:
        return None
    # the audio is decoded by our ffmpeg and handed over as samples: faster-whisper's own decoder (PyAV) breaks across
    # PyAV versions ("open() got an unexpected keyword argument 'metadata_errors'", PyAV 16)
    code = ("import json, sys, subprocess\nimport numpy as np\nfrom faster_whisper import WhisperModel\n"
            "src, lang, model, th, ff = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5]\n"
            "pcm = subprocess.run([ff, '-v', 'error', '-i', src, '-vn', '-ac', '1', '-ar', '16000', '-f', 'f32le', '-'],"
            " capture_output=True, check=True).stdout\n"
            "audio = np.frombuffer(pcm, np.float32).copy()\n"
            "m = WhisperModel(model, device='cpu', compute_type='int8', cpu_threads=th, num_workers=1)\n"
            "segs, info = m.transcribe(audio, word_timestamps=True, language=None if lang == 'auto' else lang)\n"
            "print(json.dumps([dict(w=w.word, s=w.start, e=w.end) for s in segs for w in (s.words or [])]))\n")
    r = subprocess.run([sys.executable, "-c", code, str(src), language or "auto", model or "small", str(whisper_threads()),
                        ffmpeg()], capture_output=True, text=True)
    if r.returncode != 0 or not r.stdout.strip():
        print(r.stderr[-800:], file=sys.stderr)
        return None
    return json.loads(r.stdout.strip().splitlines()[-1]), f"faster-whisper {model or 'small'}"


def _openai(src, language, model):
    try:
        import whisper
        import torch
    except ImportError:
        return None
    torch.set_num_threads(whisper_threads())
    m = whisper.load_model(model or "small", device="cpu")
    r = m.transcribe(str(src), word_timestamps=True, fp16=False,
                     language=None if language == "auto" else language)
    out = [dict(w=w["word"], s=w["start"], e=w["end"]) for s in r["segments"] for w in s.get("words", [])]
    return out, f"openai-whisper {model or 'small'}"


def transcribe(src, out, language="en", engine="auto", model=None, transcript=None):
    if transcript:
        p = Path(transcript)
        ws = from_srt(p) if p.suffix.lower() in (".srt", ".vtt") else from_json(p)
        return _save(ws, out, src, f"import {p.name}", language)
    with tempfile.TemporaryDirectory() as tmp:
        for name, fn in (("whisper.cpp", lambda: _whisper_cpp(src, language, tmp)),
                         ("faster-whisper", lambda: _faster(src, language, model)),
                         ("openai-whisper", lambda: _openai(src, language, model))):
            if engine not in ("auto", name):
                continue
            r = fn()
            if r:
                return _save(r[0], out, src, r[1], language)
    raise SystemExit("No transcriber found. Install one of: whisper.cpp (brew install whisper-cpp, plus a ggml model; "
                     "set CBEDIT_WHISPER_MODEL), `pip install faster-whisper`, `pip install openai-whisper`; "
                     "or pass --transcript words.json / captions.srt.")


def load_words(path):
    j = json.loads(Path(path).read_text())
    return j["words"]


def sentences(words, gap=1.1):
    """Split into sentences on . ? ! (and on a pause of `gap` s or more with no punctuation)."""
    out, cur = [], []
    for i, w in enumerate(words):
        cur.append(i)
        end = re.search(r"[.?!]['\")\]]*$", w["w"]) is not None
        nxt = words[i + 1] if i + 1 < len(words) else None
        if end or nxt is None or (nxt["s"] - w["e"] >= gap):
            out.append(cur)
            cur = []
    return out


def envelope(audio: np.ndarray, sr=48000, hop=0.005):
    """RMS in dB every `hop` s (mono)."""
    mono = audio.mean(axis=1) if audio.ndim == 2 else audio
    n = int(sr * hop)
    k = len(mono) // n
    if k == 0:
        return np.zeros(1) - 90
    r = np.sqrt((mono[: k * n].reshape(k, n) ** 2).mean(axis=1) + 1e-12)
    return 20 * np.log10(r)


def build_cut(src_key, src_path, words, drop_sentences=(), drop_words=(), pause=0.32, start=None, end=None,
              fillers=False, filler_after=60.0):
    """Segments [{src, in, out, w0, w1}] (word index range inclusive) on the source timeline."""
    audio = load_audio(src_path)
    env = envelope(audio)
    hop = 0.005
    lo, hi = np.percentile(env, 10), np.percentile(env, 92)
    thr = lo + 0.33 * (hi - lo)
    sents = sentences(words)
    sid = {}
    for k, s in enumerate(sents):
        for i in s:
            sid[i] = k
    drop = set()
    for k in drop_sentences:
        drop.update(sents[int(k)])
    drop.update(int(i) for i in drop_words)
    if fillers:
        for w in words:
            if _norm(w["w"]) in FILLERS and w["s"] >= filler_after:
                drop.add(w["i"])
    keep = [w for w in words if w["i"] not in drop and (start is None or w["s"] >= start)
            and (end is None or w["e"] <= end)]
    runs, cur = [], []
    for w in keep:
        if cur and (w["i"] != cur[-1]["i"] + 1 or w["s"] - cur[-1]["e"] >= pause):
            runs.append(cur)
            cur = []
        cur.append(w)
    if cur:
        runs.append(cur)

    def speech(t):
        i = int(t / hop)
        return 0 <= i < len(env) and env[i] > thr

    # silences in the voice itself (whisper's word times have no reliable gaps): stretches under thr for >= pause
    quiet = []
    below = env <= thr
    i = 0
    n_env = len(env)
    while i < n_env:
        if below[i]:
            j = i
            while j < n_env and below[j]:
                j += 1
            if (j - i) * hop >= pause:
                quiet.append((i * hop, j * hop))
            i = j
        else:
            i += 1

    def carve(a_, b_):
        """[a_, b_] minus its inner silences (kept: 0.08 s of tail, 0.06 s of lead around each)."""
        parts, cur = [], a_
        for qa, qb in quiet:
            if qb <= cur or qa >= b_:
                continue
            ca, cb = qa + 0.08, qb - 0.06
            if cb - ca < 0.12 or ca <= cur + 0.15 or cb >= b_ - 0.15:
                continue
            parts.append((cur, ca))
            cur = cb
        parts.append((cur, b_))
        return parts

    segs = []
    for run in runs:
        a, z = run[0], run[-1]
        prev_end = words[a["i"] - 1]["e"] if a["i"] > 0 else 0.0
        next_start = words[z["i"] + 1]["s"] if z["i"] + 1 < len(words) else z["e"] + 1.0
        # onset: walk back while the voice is still up (a clipped first syllable), then a short lead in the quiet
        t_in = a["s"]
        floor_in = max(prev_end + 0.02, a["s"] - 0.25)
        while t_in - hop > floor_in and speech(t_in - hop):
            t_in -= hop
        t_in = max(floor_in, t_in - 0.06)
        # offset: walk on while the voice is still up (whisper's end often clips the tail), then a short tail
        t_out = z["e"]
        ceil_out = min(next_start - 0.02, z["e"] + 0.35)
        while t_out + hop < ceil_out and speech(t_out):
            t_out += hop
        t_out = min(ceil_out, t_out + 0.08)
        for pa, pb in carve(t_in, t_out):
            ws_in = [w["i"] for w in run if w["s"] < pb and w["s"] >= pa - 0.1] or [a["i"]]
            segs.append(dict(src=src_key, **{"in": round(pa, 3), "out": round(pb, 3)}, w0=min(ws_in), w1=max(ws_in)))
    # merge segments that touch
    merged = []
    for s in segs:
        if merged and s["in"] - merged[-1]["out"] < 0.04:
            merged[-1]["out"], merged[-1]["w1"] = s["out"], s["w1"]
        else:
            merged.append(s)
    return merged, sents


def script(words, sents, segs, speed=1.0, fps=30.0):
    """A readable script on the OUTPUT timeline: one line per kept sentence with its word ids."""
    kept = {}
    t = 0.0
    for s in segs:
        n = round((s["out"] - s["in"]) / speed * fps)
        for i in range(s["w0"], s["w1"] + 1):
            kept[i] = t + (words[i]["s"] - s["in"]) / speed
        t += n / fps
    lines = []
    for k, sent in enumerate(sents):
        ins = [i for i in sent if i in kept]
        if not ins:
            lines.append(f"  [s{k} dropped] {' '.join(words[i]['w'] for i in sent)}")
            continue
        txt = " ".join(f"{words[i]['w']}" for i in ins)
        lines.append(f"{kept[ins[0]]:7.2f}s  s{k:<3} w{ins[0]}-w{ins[-1]}  {txt}")
    return "\n".join(lines), t
