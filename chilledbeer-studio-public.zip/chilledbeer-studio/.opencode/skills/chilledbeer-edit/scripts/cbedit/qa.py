"""QA on a rendered file: format, loudness, black and frozen stretches, and a contact sheet to look at."""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

from .media import ffmpeg, probe


def qa(path, every=None, sheet=None, freeze=None):
    path = str(path)
    info = probe(path)
    dur = info["duration"]
    print(f"file: {info['w']}x{info['h']} @ {info['fps']:.3f} fps, {dur:.2f}s, audio={info['audio']}")
    r = subprocess.run([ffmpeg(), "-hide_banner", "-nostats", "-i", path, "-filter_complex",
                        "[0:a]ebur128=peak=true[a]", "-map", "[a]", "-f", "null", "-"], capture_output=True, text=True)
    I = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
    tp = re.findall(r"Peak:\s+(-?[\d.]+) dBFS", r.stderr)
    bad = []
    if I:
        li = float(I[-1])
        pk = float(tp[-1]) if tp else 0
        print(f"loudness: {li:.1f} LUFS, true peak {pk:.1f} dBTP  (target -14, <= -1.5)")
        if abs(li + 14) > 1.0 or pk > -1.0:
            bad.append("loudness")
    fz = freeze or (2.5 if info["h"] > info["w"] else 4.0)
    r = subprocess.run([ffmpeg(), "-hide_banner", "-nostats", "-i", path, "-vf",
                        f"scale=480:-2,blackdetect=d=0.3:pix_th=0.06,freezedetect=n=0.002:d={fz}", "-an", "-f", "null",
                        "-"], capture_output=True, text=True)
    blacks = re.findall(r"black_start:([\d.]+) black_end:([\d.]+)", r.stderr)
    frz = re.findall(r"freeze_start: ([\d.]+)", r.stderr)
    for a, b in blacks:
        print(f"BLACK  {float(a):.2f}-{float(b):.2f}s")
        bad.append("black")
    for a in frz:
        print(f"FROZEN from {float(a):.2f}s for {fz}s+ (a still that should move, or a readable hold?)")
        bad.append("freeze")
    if sheet:
        n = 12
        step = every or max(0.5, dur / n)
        cols = 4
        rows = -(-int(dur / step) // cols)
        subprocess.run([ffmpeg(), "-v", "error", "-y", "-i", path, "-vf",
                        f"fps=1/{step},scale=480:-2,drawtext=text='%{{pts\\:hms}}':x=8:y=8:fontsize=18:fontcolor=white:"
                        f"box=1:boxcolor=black@0.5,tile={cols}x{max(1, rows)}", "-frames:v", "1", str(sheet)],
                       capture_output=True)
        print(f"sheet: {sheet}")
    print("qa: PASS" if not bad else f"qa: WARN ({', '.join(sorted(set(bad)))})")
    return 0 if not bad else 1
