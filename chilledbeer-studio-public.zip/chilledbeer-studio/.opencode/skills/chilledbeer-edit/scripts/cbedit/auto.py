"""The automatic director: a complete, gate-clean edit plan from the transcript alone.

It does what the skill asks a director to do, with fixed rules, so any model (or none) gets a good edit:
  1. tidy the cut: drop restarts (a sentence whose opening the next one repeats), lone "right?"/"okay?" asides and a
     trailing fragment, then re-cut (whole sentences only);
  2. split the talk into beats of one thought (Reel 2.2-5.5 s, long-form 3.5-9 s);
  3. the hook: his face, at least 3 s (5 s on long-form), a punch and a slam/pop by ~1 s;
  4. the context rule: a beat whose words name an editor / phone / TV / laptop / site / call / film / photo / post
     puts him inside it;
  5. other beats rotate full / beside card / beside circle / takeover (statement, number, list) within the budgets
     (no layout over 35 %, never three in a row, away under 8 s on a Reel and 12 s on long-form);
  6. transitions by meaning, never the same twice in a row, whips under 40 %;
  7. punches on stressed words (spaced 3 s / 5 s), type on his punchy lines and product names;
  8. a report of what it decided and what is left for a human or model (spellings, Hinglish subtitles, real
     screenshots to capture).
All on-screen words are his own words; numbers only when he said them.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .check import CONTEXT, CONTEXT_RX

STRESS = set("""stop never always only free every nothing everything best worst huge crazy insane actually literally
no not can't won't don't must secret mistake wrong money exactly seriously really biggest fastest simple easy hard
problem truth lie fake real dead killed changed everyone nobody zero million billion lakh crore percent""".split())
FILLER_SENT = {"right", "okay", "ok", "so", "yeah", "yes", "na", "hai na", "you know", "like", "basically", "achha",
               "acha", "theek hai", "haan"}
HINGLISH = set("""hai hain nahi nahin kya kyun kaise matlab aur kar karo karna kiya ki ka ke ko se mein main hum tum
aap bhi toh tha thi the hoga hogi raha rahi rahe wala wali wale bahut bohot sab kuch yaar bhai abhi phir lekin agar
apna apni apne dekho dekh samjho chahiye sakte sakta""".split())
CONTEXT_ORDER = ["editor", "tv", "phone", "call", "cinema", "polaroid", "post", "laptop", "browser"]
SCREEN_STAGES = {"editor", "tv", "cinema"}          # 16:9 screens: a reveal from his full frame is seamless
NUM = re.compile(r"^[₹$]?\d[\d,]*(\.\d+)?(%|k|K|x)?$")
UNITS = {"percent", "%", "lakh", "lakhs", "crore", "crores", "k", "thousand", "million", "billion", "rupees", "x",
         "times", "minutes", "hours", "days", "years", "dollars"}


def norm(w):
    return re.sub(r"[^\w']+", "", w.lower())


# ---- 1. the cut -------------------------------------------------------------------------------------------------------
def suggest_drops(words, sents):
    drops, why = [], {}
    texts = [[norm(words[i]["w"]) for i in s] for s in sents]
    for k, s in enumerate(sents):
        t = [x for x in texts[k] if x]
        joined = " ".join(t)
        # a lone aside: "Right?", "Okay?", "So."
        if joined in FILLER_SENT or (len(t) <= 2 and all(x in FILLER_SENT or x in ("na", "hai") for x in t)):
            drops.append(k)
            why[k] = "aside"
            continue
        # a restart: the next sentence opens with the same 3 words (keep the last take)
        if k + 1 < len(sents):
            nxt = [x for x in texts[k + 1] if x]
            if len(t) >= 3 and nxt[:3] == t[:3]:
                drops.append(k)
                why[k] = "restart"
                continue
            # an unfinished sentence (no closing punctuation) whose words the next one re-says
            last = words[s[-1]]["w"]
            if not re.search(r"[.?!]$", last) and len(t) >= 2 and " ".join(t[:2]) in " ".join(nxt[:6]):
                drops.append(k)
                why[k] = "restart"
                continue
    # a trailing fragment: the last sentence has no closing punctuation and is short
    if sents:
        k = len(sents) - 1
        last = words[sents[k][-1]]["w"]
        if not re.search(r"[.?!]$", last) and len(sents[k]) <= 8 and k not in drops:
            drops.append(k)
            why[k] = "trailing fragment"
    return sorted(set(drops)), why


# ---- 2. beats ---------------------------------------------------------------------------------------------------------
def out_sentences(plan):
    """Kept words on the output timeline, split into sentences."""
    out, cur = [], []
    for w in plan.wlist:
        cur.append(w)
        if re.search(r"[.?!]['\")]*$", w["w"]):
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return out


def split_on_context(groups, reel, hook_min):
    """A long beat that names a context (after its first seconds) splits there: the new beat starts 2 words before."""
    lo = 2.2 if reel else 3.5
    out = []
    for gi, g in enumerate(groups):
        t0 = g[0]["s"]
        cut = None
        for i, w in enumerate(g):
            if w["s"] - t0 < (hook_min if gi == 0 else lo) or g[-1]["e"] - w["s"] < lo * 0.8:
                continue
            win = " ".join(norm(x["w"]) for x in g[i:i + 3])
            if any(CONTEXT_RX[st].match(win) for st in CONTEXT_ORDER):
                cut = max(1, i - 2)
                break
        if cut and g[cut]["s"] - t0 >= (hook_min - 0.5 if gi == 0 else lo * 0.8):
            out += [g[:cut], g[cut:]]
        else:
            out.append(g)
    return out


def split_beats(sents, reel, duration):
    lo, tgt, hi = (2.2, 3.6, 5.5) if reel else (3.5, 6.0, 9.0)
    beats, cur = [], []

    def dur(ws):
        return ws[-1]["e"] - ws[0]["s"] if ws else 0

    for s in sents:
        if dur(s) > hi:
            # a long sentence: split at a comma (or a word) near the target
            if cur:
                beats.append(cur)
                cur = []
            part = []
            for w in s:
                part.append(w)
                if dur(part) >= tgt and (re.search(r",$", w["w"]) or dur(part) >= hi * 0.85):
                    beats.append(part)
                    part = []
            if part:
                if beats and dur(part) < lo:
                    beats[-1] = beats[-1] + part
                else:
                    beats.append(part)
            continue
        if cur and dur(cur + s) > hi:
            beats.append(cur)
            cur = []
        cur = cur + s
        if dur(cur) >= tgt:
            beats.append(cur)
            cur = []
    if cur:
        if beats and dur(cur) < lo:
            beats[-1] = beats[-1] + cur
        else:
            beats.append(cur)
    return beats


# ---- text helpers ------------------------------------------------------------------------------------------------------
def is_product(w, first):
    """A name: a capitalised word that does not start a sentence, or one with inner capitals (GitHub, ChatGPT)."""
    raw = re.sub(r"[^\w.+-]", "", w["w"])
    return bool(raw) and not first and (raw[0].isupper() and raw.lower() not in ("i", "im", "ill", "ive", "id")
                                        or any(c.isupper() for c in raw[1:]))


STOP = set("""a an the is are was were be been being to of in on at for and or but so if then that this these those it
its i you we they he she my your our their me him her them us as with by from just very also which what who whom how
when where there here do does did doing have has had will would can could should shall may might about into than like
okay ok right yeah yes well um uh basically actually literally thing things something anything some any all one get
got go going gonna want wanna know let make made said say says tell told""".split())
LEAD = {"but", "so", "and", "because", "then", "or", "like", "okay", "right", "also", "now", "well", "anyway"}


def first_of_sentence(ws, i):
    return i == 0 or bool(re.search(r"[.?!]['\")]*$", ws[i - 1]["w"]))


def key_score(w, i, ws):
    n = norm(w["w"])
    s = 0.0
    if n in STRESS:
        s += 2
    if NUM.match(re.sub(r"[.,?!]$", "", w["w"])):
        s += 2.5
    if is_product(w, first_of_sentence(ws, i)):
        s += 1.5
    return s


def _clauses(ws):
    cl, cur = [], []
    for w in ws:
        cur.append(w)
        if re.search(r"[,;:.?!]['\")]*$", w["w"]):
            cl.append(cur)
            cur = []
    if cur:
        cl.append(cur)
    return cl


def clause(ws, max_words=6, min_score=1.6):
    """His own words for a card: the best 3-max_words window inside one clause, scored on key words and content
    words, with no leading 'but/so/and' and no dangling 'the/is/to' at the end. ("", None) when nothing is strong."""
    best, best_s = None, -9.0
    for c in _clauses(ws):
        idx = [ws.index(w) for w in c]
        while c and norm(c[0]["w"]) in LEAD:
            c, idx = c[1:], idx[1:]
        n = len(c)
        for a_ in range(n):
            for b_ in range(a_ + 3, min(n, a_ + max_words) + 1):
                win = c[a_:b_]
                if norm(win[-1]["w"]) in STOP and not re.search(r"[.?!]$", win[-1]["w"]):
                    continue
                ks = sum(key_score(w, idx[a_ + j], ws) for j, w in enumerate(win))
                content = sum(1 for w in win if norm(w["w"]) not in STOP)
                sc = ks + 0.7 * content - 0.15 * len(win) + (0.8 if (a_ == 0 and b_ == n) else 0)
                if sc > best_s:
                    best, best_s = (win, [idx[a_ + j] for j in range(len(win))]), sc
    if not best or best_s < min_score:
        return "", None
    win, ids = best
    k = max(range(len(win)), key=lambda j: (key_score(win[j], ids[j], ws), norm(win[j]["w"]) not in STOP))
    toks = [re.sub(r"^[,;:]+|[,;:]+$", "", w["w"]) for w in win]
    if key_score(win[k], ids[k], ws) > 0 or norm(win[k]["w"]) not in STOP:
        toks[k] = "*" + toks[k] + "*"
    text = " ".join(t for t in toks if t)
    if text and text[0] != "*":
        text = text[0].upper() + text[1:]
    return text, win


def number_in(ws):
    for i, w in enumerate(ws):
        raw = re.sub(r"[.,?!]$", "", w["w"])
        if NUM.match(raw):
            unit = ""
            if i + 1 < len(ws) and norm(ws[i + 1]["w"]) in UNITS:
                unit = " " + re.sub(r"[.,?!]$", "", ws[i + 1]["w"])
            return raw + unit, w
    return None, None


def list_items(ws):
    marks = ("first", "second", "third", "fourth", "one", "two", "three", "step", "number")
    items = []
    cur = []
    for w in ws:
        if norm(w["w"]) in marks and cur:
            items.append(cur)
            cur = []
        cur.append(w)
    if cur:
        items.append(cur)
    if len(items) >= 2 and sum(1 for it in items if norm(it[0]["w"]) in marks) >= 2:
        return [(" ".join(x["w"] for x in it[:5]).rstrip(",."), it[0]["id"]) for it in items[:4]]
    return None


def text_of(ws):
    return " ".join(w["w"] for w in ws)


# ---- the director -------------------------------------------------------------------------------------------------------
def direct(plan, music_dir=None):
    reel = plan.portrait or not plan.long
    dur = plan.duration
    sents = out_sentences(plan)
    groups = split_beats(sents, reel, dur)
    # the hook: merge until it is long enough on his face
    hook_min = 3.0 if reel else 5.0
    while len(groups) > 1 and groups[0][-1]["e"] - groups[0][0]["s"] < hook_min:
        groups[0] = groups[0] + groups.pop(1)
    groups = split_on_context(groups, reel, hook_min)

    from .lens import Faces
    faces = Faces(plan.work / "faces.json")

    def view_of(g):
        votes = []
        for w in g[:: max(1, len(g) // 6)]:
            src, st, _ = plan.src_time(w["s"])
            votes.append(faces.view(src, st))
        return "screen" if votes.count("screen") > len(votes) / 2 else "cam"

    beats, used = [], {}
    share = {}
    last_ctx = {}
    away = 0.0
    since_take = 0.0
    todo = []
    away_cap = 8.0 if reel else 12.0

    def gdur(g, nxt):
        a = g[0]["s"]
        b = nxt[0]["s"] if nxt else dur
        return b - a

    for k, g in enumerate(groups):
        nxt = groups[k + 1] if k + 1 < len(groups) else None
        d = gdur(g, nxt)
        txt = text_of(g).lower()
        at = 0 if k == 0 else g[0]["id"]
        prev = [b["stage"] for b in beats[-2:]]
        b = dict(at=at, stage="full", why=text_of(g)[:70], props={})
        if view_of(g) == "screen":
            # his screen recording: show it, calmly; every other screen beat sits on the laptop
            n_scr = sum(1 for x in beats if x.get("props", {}).get("view") == "screen")
            # whole screen (slow push), a tight read of the left, the laptop, a tight read of the right
            kind = ["whole", "left", "laptop", "right"][n_scr % 4]
            if kind == "laptop" and prev and prev[-1] == "laptop":
                kind = "whole"
            st = "laptop" if kind == "laptop" else "full"
            b.update(stage=st, why="his screen: " + text_of(g)[:50])
            if kind == "laptop":
                b.update(cam="hold")
                b["props"] = dict(view="screen", app="player")
            elif kind == "whole":
                b.update(cam="push")
                b["props"] = dict(view="screen")
            else:
                b.update(cam="tight")
                b["props"] = dict(view="screen", focus=[0.3, 0.4] if kind == "left" else [0.7, 0.4])
            beats.append(b)
            share[st] = share.get(st, 0) + d
            since_take += d
            continue
        if k == 0:
            b.update(cam="push", why="the hook on his face")
            beats.append(b)
            share["full"] = share.get("full", 0) + d
            continue

        last_beat = nxt is None

        def ok(stage):
            if prev[-2:] == [stage, stage]:
                return False
            if stage in ("takeover", "broll") and (last_beat or (prev and prev[-1] in ("takeover", "broll"))):
                return False
            if (share.get(stage, 0) + d) / dur > 0.35 and stage != "full":
                return False
            if stage == "full" and (share.get(stage, 0) + d) / dur > 0.38:
                return False
            return True

        chosen = None
        # the context rule
        for st in CONTEXT_ORDER:
            m = CONTEXT_RX[st].search(txt)
            if not m:
                continue
            if st == (prev[-1] if prev else None) or (k - last_ctx.get(st, -9)) < 3 or not ok(st):
                continue
            word = next((w for i, w in enumerate(g)
                         if CONTEXT_RX[st].match(" ".join(norm(x["w"]) for x in g[i:i + 3]))), g[0])
            chosen = st
            b["why"] = text_of(g[max(0, g.index(word) - 2):g.index(word) + 4])
            last_ctx[st] = k
            break
        if chosen:
            b["stage"] = chosen
            cl, _ = clause(g)
            P = b["props"]
            if chosen == "phone":
                said = re.split(r"\b(?:asking|asked|said|says|messaged|wrote|commented)\b,?", text_of(g), maxsplit=1)
                if len(said) == 2 and len(said[1].split()) >= 3:
                    P["notif"] = dict(at=g[min(len(g) - 1, 2)]["id"], app="DM", title="viewer",
                                      text=said[1].strip(" ,")[:90])
                if not reel and cl:
                    P["x"] = 0.32
                    P["content"] = dict(kind="text", text=cl, size=84)
            elif chosen == "tv":
                P.update(live=True, ticker=re.sub(r"\*", "", cl) or text_of(g)[:70], ticker_label="NEW")
            elif chosen == "call":
                P["others"] = [dict(name="AI interviewer", kind="orb")] if re.search(r"\bai\b|bot|chakra", txt) \
                    else [dict(name="Guest", kind="avatar")]
                P["title"] = "Interview" if "interview" in txt else "Call"
            elif chosen == "laptop":
                P["app"] = "player"
            elif chosen == "browser":
                P["player"] = True
                P["video_title"] = re.sub(r"\*", "", cl)[:48] or "Watch"
                m2 = re.search(r"\b([A-Z][\w.]+(?:\.com|\.ai|\.io)?)\b", text_of(g)[1:])
                todo.append(f"browser beat at {g[0]['s']:.1f}s (\"{b['why']}\"): if he names a real site or repo, "
                            f"capture its page into assets/ and set props.image (+ url, mark) instead of the player.")
            elif chosen == "polaroid":
                P["caption"] = re.sub(r"\*", "", cl).lower()[:22]
            elif chosen == "post":
                P["caption"] = re.sub(r"\*", "", cl)[:40]
                P["likes"] = "liked by you and others"
                P["like"] = g[min(len(g) - 1, len(g) // 2)]["id"]
        else:
            num, nw = number_in(g)
            items = list_items(g)
            short = len(g) <= 9
            want_takeover = (since_take > (14 if reel else 22)) and ok("takeover") and d <= away_cap + 3
            if items and ok("takeover"):
                b["stage"] = "takeover"
                b["props"] = dict(kind="list", title=None, items=[[t, i] for t, i in items])
            elif num and ok("takeover") and d <= away_cap + 3:
                cl, _ = clause(g)
                b["stage"] = "takeover"
                b["props"] = dict(kind="number", value=num, at=nw["id"], label=re.sub(r"\*", "", cl)[:44])
            elif (want_takeover or (short and ok("takeover") and since_take > 8)) and clause(g, 7, 3.0)[0]:
                cl, _ = clause(g, max_words=7, min_score=3.0)
                b["stage"] = "takeover"
                b["props"] = dict(kind="statement", text=cl)
            else:
                # rotate his framings
                cycle = ["beside", "full", "beside", "full"]
                for st in cycle[len(beats) % 4:] + cycle[: len(beats) % 4]:
                    if ok(st) and not (prev and prev[-1] == st):
                        b["stage"] = st
                        break
                else:
                    b["stage"] = "full" if prev and prev[-1] != "full" else "beside"
                cl, _ = clause(g)
                if b["stage"] == "beside" and not cl and ok("full") and not (prev and prev[-1] == "full"):
                    b["stage"] = "full"
                if b["stage"] == "beside":
                    n_beside = sum(1 for x in beats if x["stage"] == "beside")
                    b["props"] = dict(shape="circle" if n_beside % 2 else "card",
                                      side="right" if n_beside % 2 else "left",
                                      content=dict(kind="text", text=cl or clause(g, 6, 0.0)[0] or text_of(g)[:40],
                                                   size=88 if not reel else 80))
                else:
                    b["cam"] = ["drift", "pull", "push", "arc"][len(beats) % 4]
        # away budget: a takeover never runs past the cap
        if b["stage"] == "takeover" and d > away_cap:
            split_at = next((w for w in g if w["s"] - g[0]["s"] >= away_cap * 0.7), None)
            if split_at:
                beats.append(b)
                share["takeover"] = share.get("takeover", 0) + (split_at["s"] - g[0]["s"])
                b2 = dict(at=split_at["id"], stage="full", cam="push", why="back to his face", props={})
                beats.append(b2)
                share["full"] = share.get("full", 0) + d - (split_at["s"] - g[0]["s"])
                since_take = 0
                continue
        beats.append(b)
        share[b["stage"]] = share.get(b["stage"], 0) + d
        since_take = 0 if b["stage"] == "takeover" else since_take + d

    _rebalance(beats, plan, dur)
    _transitions(beats)
    punch = _punches(plan, beats, reel)
    typ = _type(plan, beats, groups, reel)
    _fill(plan, beats, punch, typ, reel)
    music = _music(plan, reel, music_dir)
    todo += _todos(plan, sents)
    return beats, punch, typ, music, todo


def _rebalance(beats, plan, dur):
    """No layout over 35 %: turn the shortest non-context beats of an over-budget layout into full frame."""
    starts = [plan.T(b["at"]) for b in beats]
    lens_ = [(e - s_) for s_, e in zip(starts, starts[1:] + [dur])]
    for st in ("beside", "takeover"):
        while sum(l for b, l in zip(beats, lens_) if b["stage"] == st) / dur > 0.35:
            full = sum(l for b, l in zip(beats, lens_) if b["stage"] == "full")
            cands = [i for i, b in enumerate(beats) if b["stage"] == st and i > 0
                     and not (beats[i - 1]["stage"] == "full" and i + 1 < len(beats) and beats[i + 1]["stage"] == "full")]
            if not cands or (full + min(lens_[i] for i in cands)) / dur > 0.35:
                break
            i = min(cands, key=lambda i: lens_[i])
            beats[i]["stage"], beats[i]["props"], beats[i]["cam"] = "full", {}, "drift"


def _fill(plan, beats, punch, typ, reel):
    """Never a dead stretch: a small zoom step on a word inside any gap longer than the cadence allows, and on a
    Reel a step inside the first half-second (movement by 0.5 s)."""
    lim = 2.8 if reel else 5.5
    starts = [plan.T(b["at"]) for b in beats]
    ends = starts[1:] + [plan.duration]

    def events():
        ev = set(starts) | {plan.T(p) for p in punch} | set(plan.joins) | {plan.T(t["at"]) for t in typ}
        for b, a, z in zip(beats, starts, ends):
            if b.get("cam") in ("push", "pull", "drift", "arc", "tight") and z - a > 4:
                ev.add((a + z) / 2)
            ev |= {plan.T(j["at"]) for j in b.get("jumps", [])}
        return sorted(t for t in ev if 0 <= t <= plan.duration) + [plan.duration]

    def add_jump(t_lo, t_hi, target):
        ws = [w for w in plan.wlist if t_lo + 0.25 < w["s"] < t_hi - 0.25]
        if not ws:
            return False
        w = min(ws, key=lambda w: abs(w["s"] - target))
        k = max(i for i, a in enumerate(starts) if a <= w["s"])
        b = beats[k]
        if b["stage"] in ("takeover",):
            return False
        js = b.setdefault("jumps", [])
        z = 1.0 if len(js) % 2 else (1.07 if reel else 1.06)
        js.append(dict(at=w["id"], z=z))
        return True

    if reel and not any(t < 0.6 for t in events()[1:-1] if t > 0):
        first = next((w for w in plan.wlist if 0.2 <= w["s"] <= 0.9), None)
        if first:
            beats[0].setdefault("jumps", []).append(dict(at=first["id"], z=1.08))
    for _ in range(60):
        ev = [0.0] + events()
        gaps = [(b_ - a_, a_, b_) for a_, b_ in zip(ev, ev[1:]) if b_ - a_ > lim]
        if not gaps:
            break
        g, a_, b_ = max(gaps)
        if not add_jump(a_, b_, (a_ + b_) / 2):
            # nowhere to step inside it (a takeover or a word-less gap): leave it to the gate
            lim_hit = [x for x in gaps if x != (g, a_, b_)]
            if not lim_hit:
                break
            for g2, a2, b2 in sorted(lim_hit, reverse=True):
                if add_jump(a2, b2, (a2 + b2) / 2):
                    break
            else:
                break


def _transitions(beats):
    hist = []
    for i, b in enumerate(beats):
        if i == 0:
            b["in"] = "cut"
            continue
        p = beats[i - 1]["stage"]
        st = b["stage"]
        if st in SCREEN_STAGES and p == "full" and st != "tv":
            want = ["reveal"]
        elif st in SCREEN_STAGES and st != "tv":
            want = ["push", "iris", "whip"]
        elif st == "tv":
            want = ["static", "reveal" if p == "full" else "glitch"]
        elif st in ("phone", "laptop", "polaroid", "post"):
            want = ["rise", "push", "iris"]
        elif st == "takeover":
            want = ["zoom", "flash", "push"]
        elif st == "full":
            want = ["fade"] if p == "takeover" else ["cut", "whip"]
        elif st == "beside":
            want = ["whip", "push", "cut"]
        elif st in ("call", "browser"):
            want = ["push", "whip", "iris"]
        else:
            want = ["cut"]
        whips = hist.count("whip")
        pick = None
        for w in want + ["push", "cut", "iris"]:
            if hist and w == hist[-1] and w != "cut":
                continue
            if w == "whip" and (whips + 1) / max(1, len(hist) + 1) > 0.4:
                continue
            pick = w
            break
        b["in"] = pick or "cut"
        hist.append(b["in"])
    # a device with a 16:9 screen dives back into his face when full follows
    for i in range(len(beats) - 1):
        if beats[i]["stage"] in ("editor", "cinema") and beats[i + 1]["stage"] == "full":
            beats[i]["out"] = "dive"
            beats[i + 1]["in"] = "cut"


def _punches(plan, beats, reel):
    gap = 3.0 if reel else 5.5
    per = 5.0 if reel else 9.0
    starts = [plan.T(b["at"]) for b in beats]
    ends = starts[1:] + [plan.duration]
    env = None
    p = plan.work / "env.npy"
    if p.exists():
        import numpy as np
        env = np.load(p)
    cands = []
    for b, a, z in zip(beats, starts, ends):
        if b["stage"] not in ("full", "beside", "editor") or b.get("props", {}).get("view") == "screen":
            continue
        ws = [w for w in plan.wlist if a + 0.5 <= w["s"] <= z - 0.4]
        for i, w in enumerate(ws):
            s = key_score(w, i, ws)
            if env is not None:
                s += float(env[min(len(env) - 1, int(w["s"] * plan.fps))])
            if s >= 1.2:
                cands.append((s, w["s"], w["id"]))
    cands.sort(reverse=True)
    picked = []
    budget = max(1, int(plan.duration / per))
    for s, t, wid in cands:
        if len(picked) >= budget:
            break
        if all(abs(t - u) >= gap for u, _ in picked):
            picked.append((t, wid))
    # the hook gets one early punch if a word allows
    picked.sort()
    return [wid for _, wid in picked]


def _type(plan, beats, groups, reel):
    out = []
    starts = [plan.T(b["at"]) for b in beats]
    ends = starts[1:] + [plan.duration]
    last_t = -9
    for bi, (b, a, z) in enumerate(zip(beats, starts, ends)):
        if b["stage"] not in ("full", "editor"):
            continue
        ws = [w for w in plan.wlist if a <= w["s"] < z]
        # a short punchy sentence -> slam
        sent, cur = [], []
        for w in ws:
            cur.append(w)
            if re.search(r"[.?!]$", w["w"]):
                sent.append(cur)
                cur = []
        slam = next((s for s in sent if len(s) <= 3 and any(norm(w["w"]) in STRESS or NUM.match(norm(w["w"]))
                                                            for w in s)), None)
        if bi == 0 and not slam:
            # the hook: the strongest word by ~1-3 s
            k = max(range(len(ws)), key=lambda i: key_score(ws[i], i, ws), default=None)
            k = ws[k] if k is not None and key_score(ws[k], k, ws) >= 1.5 else None
            if k is not None:
                t = re.sub(r"[,;:]$", "", k["w"])
                out.append(dict(at=k["id"] + "-0.05", text=t.upper() if reel else t[0].upper() + t[1:], style="slam",
                                dur=0.9))
                last_t = k["s"]
                continue
        if slam and slam[0]["s"] - last_t > (4 if reel else 7):
            out.append(dict(at=slam[0]["id"] + "-0.05", text=" ".join(w["w"] for w in slam).upper(), style="slam",
                            dur=1.0))
            last_t = slam[0]["s"]
            continue
        prod = next((w for i, w in enumerate(ws) if is_product(w, first_of_sentence(ws, i))
                     and len(re.sub(r"\W", "", w["w"])) > 2), None)
        if prod and prod["s"] - last_t > (5 if reel else 8) and b["stage"] == "full":
            t = re.sub(r"[,;:.]$", "", prod["w"])
            q = any(re.search(r"\?$", w["w"]) for w in ws if w["s"] >= prod["s"])
            out.append(dict(at=prod["id"] + "-0.1", text=t + ("?" if q else ""), style="pop", dur=1.5))
            last_t = prod["s"]
    return out


def _music(plan, reel, music_dir):
    if not music_dir:
        return None
    d = Path(music_dir)
    sub = d / ("reel" if reel else "long")
    pool = sorted([p for p in (sub if sub.exists() else d).glob("*") if p.suffix.lower() in (".mp3", ".wav", ".m4a")])
    if not pool:
        return None
    pick = pool[abs(hash(plan.j.get("name", ""))) % len(pool)]
    return dict(file=str(pick), db=-12 if reel else -18, duck=True, name=pick.name)


def _todos(plan, sents):
    out = []
    hl = []
    for s in sents:
        ws = [norm(w["w"]) for w in s]
        if ws and sum(1 for w in ws if w in HINGLISH) / len(ws) >= 0.3 and len(ws) >= 4:
            hl.append(s)
    for s in hl[:12]:
        out.append(f"Hinglish at {s[0]['s']:.1f}s ({s[0]['id']}-{s[-1]['id']}): \"{text_of(s)[:90]}\" -> add a type "
                   f"event {{\"at\": \"{s[0]['id']}\", \"until\": \"{s[-1]['id']}.end\", \"style\": \"sub\", "
                   f"\"text\": \"<English meaning>\"}}")
    known = {"claude", "chatgpt", "gemini", "github", "youtube", "instagram", "google", "openai", "anthropic",
             "hackerrank", "linkedin", "whatsapp", "netflix", "apple", "iphone", "android", "windows", "python",
             "javascript", "react", "india", "chakra", "opus", "sonnet", "haiku", "gpt", "ai", "api", "pro", "max",
             "cursor", "copilot", "figma", "notion", "canva", "capcut", "premiere", "davinci", "x", "twitter"}
    names = {}
    for s_ in sents:
        for i, w in enumerate(s_):
            raw = re.sub(r"[.,?!;:]+$", "", w["w"])
            if is_product(w, first_of_sentence(s_, i)) and len(re.sub(r"\W", "", raw)) > 2 \
                    and norm(raw) not in known:
                names.setdefault(raw, []).append(w["id"])
    if names:
        out.append("Names to check against the audio (fix ONLY the misheard ones; leave correct ones alone): "
                   + "; ".join(f"{k} ({', '.join(v[:3])})" for k, v in sorted(names.items()))
                   + ". A fix goes in edit.json as \"respell\": {\"<word id>\": \"<correct spelling>\"}.")
    short = [s_ for s_ in sents if len(s_) <= 4 and not any(key_score(w, i, s_) > 0 for i, w in enumerate(s_))]
    if short:
        out.append("Possible asides (drop only if they add nothing): "
                   + "; ".join(f"\"{text_of(s_)}\" ({s_[0]['id']})" for s_ in short[:8]))
    return out


def run(plan_path, music_dir=None, recut=True, log=print):
    """Tidy the cut, write the plan into edit.json, and the report into auto_report.md."""
    from .plan import Plan
    from .words import build_cut, script
    path = Path(plan_path).resolve()
    j = json.loads(path.read_text())
    d = path.parent
    if recut:
        src_key = next(iter(j["sources"]))
        src = Path(j["sources"][src_key]).expanduser()
        src = src if src.is_absolute() else d / src
        wfile = j["words"] if isinstance(j["words"], str) else j["words"][src_key]
        words = json.loads((d / wfile).read_text())["words"]
        cf = d / (j["cut"] if isinstance(j.get("cut"), str) else "cut.json")
        old = json.loads(cf.read_text()) if cf.exists() else {}
        from .words import sentences
        sents = sentences(words)
        drops, why = suggest_drops(words, sents)
        drops = sorted(set(drops) | set(old.get("drop", [])))
        pause = old.get("pause", 0.32)
        segs, sents = build_cut(src_key, src, words, drops, old.get("drop_words", []), pause, old.get("start"),
                                old.get("end"))
        cf.write_text(json.dumps(dict(pause=pause, drop=drops, drop_words=old.get("drop_words", []),
                                      start=old.get("start"), end=old.get("end"), segments=segs), indent=1))
        from .media import probe
        txt, total = script(words, sents, segs, float(j.get("speed", 1.0)), probe(str(src))["fps"])
        (d / "script.txt").write_text(txt + "\n")
        for k in drops:
            log(f"  dropped s{k} ({why.get(k, 'earlier')}): {' '.join(words[i]['w'] for i in sents[k])[:80]}")
    plan = Plan(path)
    beats, punch, typ, music, todo = direct(plan, music_dir)
    j = json.loads(path.read_text())
    j["beats"], j["punch"], j["type"] = beats, punch, typ
    if music and not (j.get("music") or {}).get("file"):
        j["music"] = music
    path.write_text(json.dumps(j, indent=2))
    # the report
    plan = Plan(path)
    from .render import prepare_events
    from .check import check
    prepare_events(plan)
    E, W, I = check(plan)
    lines = [f"# Auto plan: {plan.j.get('name')}", "",
             f"{plan.duration:.1f}s, {len(plan.beats)} beats, {len(punch)} punches, {len(typ)} type events, "
             f"music: {(plan.j.get('music') or {}).get('name', 'none')}", "",
             "rhythm: " + " · ".join(b["stage"].upper() for b in plan.beats), "", "## Beats", ""]
    for b in plan.beats:
        lines.append(f"- {b['t0']:6.2f}s  {b['stage']:9s} in:{b['in']:7s} \"{b.get('why', '')}\"")
    lines += ["", "## Gate", ""] + [f"- ERROR {e}" for e in E] + [f"- WARN {w}" for w in W] + \
             [f"- {i}" for i in I if i.startswith("layout")]
    lines += ["", "## To do (for the model or a human)", ""] + [f"- {t}" for t in todo] + \
             ["- Read script.txt: drop any sentence that is a restart, an aside or off-topic "
              "(`./cb cut <edit.json> --drop <sentence ids>`), then run `./cb auto <edit.json> --no-recut` ONCE."]
    (d / "auto_report.md").write_text("\n".join(lines) + "\n")
    log(f"auto: {len(plan.beats)} beats, {len(punch)} punches, {len(typ)} type; gate {len(E)} errors, {len(W)} warnings")
    log(f"wrote {d / 'auto_report.md'}")
    return len(E)
