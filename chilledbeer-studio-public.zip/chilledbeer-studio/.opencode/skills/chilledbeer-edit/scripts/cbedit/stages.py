"""Stages: where he is on screen, beat by beat.

  full      his room as shot, the lens on him (inserts: a picture placed on a wall/board of his room)
  beside    him in a card or circle beside one idea (points, a number, a statement, a screenshot, a logo)
  editor    him inside a video editor: program monitor, inspector values that follow the lens, a timeline whose cuts
            are the real cuts, a razor that splits on his punch words
  phone     him on a phone in a generic Reels UI (like pop, notification banner)
  tv        him on a TV in a room (news ticker, LIVE, channel static), or a retro CRT
  laptop    him in a window on a laptop (a video player, a call, or a page)
  browser   a page (screenshot scrolled, a mark highlighted) with him in a corner circle, or him as the page's player
  call      a video call grid: him and the other tiles (an AI orb, avatars), the speaking ring follows his voice
  cinema    him on a cinema screen, the room lit by his picture
  polaroid  him in a polaroid taped to paper, a handwritten caption
  post      him in a social post card, likes counting up, a double-tap heart
  takeover  him off screen, one idea owns the frame: statement, number, list, compare, image, chapter
  broll     another clip full screen while his voice carries on

Every stage draws in world px (1920x1080, or 1080x1920 for 9:16) through a View, so its camera can rise, reveal
(start filling the screen with his picture, pull out to the device) and dive (push back into the screen).
"""
from __future__ import annotations

import functools
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

from . import lens as L
from .core import (View, back_out, clamp, expo_in, expo_inout, expo_out, font, inout3, lerp, out3, out5, rgba, smooth,
                   win)
from .sprites import Sprite, icon
from .typeset import count_text, draw_rich, tokens, sync


# ---- per-frame context ----------------------------------------------------------------------------------------------
class Ctx:
    def __init__(self, plan, faces, res):
        self.plan, self.faces, self.res = plan, faces, res

    def set(self, beat, t, frame, src, src_t, env, clip=None):
        self.beat, self.t, self.frame, self.src, self.src_t, self.env, self.clip = beat, t, frame, src, src_t, env, clip
        self.tl = t - beat["t0"]
        self.dur = beat["dur"]
        self.P = beat["props"]
        return self

    def him(self, v: View, x, y, w, h, r=0.0, alpha=1.0, zoom=None, force_him=False):
        b = v.box(x, y, w, h)
        sw, sh = b[2] - b[0], b[3] - b[1]
        if sw < 1 or sh < 1:
            return
        if self.clip is not None and not force_him:
            fw, fh = self.clip.size
            A = sw / sh
            cw, ch = (fw, fw / A) if A >= fw / fh else (fh * A, fh)
            box = ((fw - cw) / 2, (fh - ch) / 2, (fw + cw) / 2, (fh + ch) / 2)
            v.place(self.clip, b, box, r * v.z, alpha)
            return
        box, _ = L.crop(self.plan, self.faces, self.beat, self.t, self.frame.size, (sw, sh), self.src, self.src_t,
                        zoom=zoom)
        v.place(self.frame, b, box, r * v.z, alpha)

    def zoom(self):
        return L.zoom_at(self.plan, self.beat, self.t)


class Res:
    """Images, thumbnails and envelopes, loaded once per worker."""

    def __init__(self, plan):
        self.plan = plan
        self._img = {}
        self.env = None
        self.menv = None
        p = plan.work / "env.npy"
        if p.exists():
            self.env = np.load(p)
        p = plan.work / "menv.npy"
        if p.exists():
            self.menv = np.load(p)

    def image(self, path):
        if path not in self._img:
            from .media import load_image
            self._img[path] = load_image(self.plan._p(path))
        return self._img[path]

    def thumb(self, k):
        p = self.plan.work / "thumbs" / f"seg{k:04d}.jpg"
        key = str(p)
        if key not in self._img:
            self._img[key] = Image.open(p).convert("RGB") if p.exists() else Image.new("RGB", (320, 180), (40, 40, 44))
        return self._img[key]

    def env_at(self, t):
        if self.env is None or len(self.env) == 0:
            return 0.0
        return float(self.env[min(len(self.env) - 1, max(0, int(t * self.plan.fps)))])


# ---- base -----------------------------------------------------------------------------------------------------------
class Stage:
    screen = None          # world rect (x, y, w, h) of his picture, for reveal / dive

    def __init__(self, plan, beat, res):
        self.plan, self.beat, self.res = plan, beat, res
        self.WW, self.WH = plan.WW, plan.WH
        self.Lk = plan.look
        self.P = beat["props"]
        self.setup()

    def setup(self):
        pass

    def base_cam(self, ctx):
        """The stage's resting camera: a slow push for life."""
        return self.WW / 2, self.WH / 2, 1.0 + 0.022 * smooth(ctx.tl / max(0.01, ctx.dur))

    def fill_cam(self):
        x, y, w, h = self.screen
        return x + w / 2, y + h / 2, max(self.WW / w, self.WH / h)

    def camera(self, ctx):
        cx, cy, z = self.base_cam(ctx)
        b = self.beat
        if b["in"] == "reveal" and self.screen:
            fx, fy, fz = self.fill_cam()
            hold = float(self.P.get("reveal_hold", 0.12))
            u = expo_inout(clamp((ctx.tl - hold) / float(self.P.get("reveal_dur", 0.9))))
            cx, cy, z = lerp(fx, cx, u), lerp(fy, cy, u), math.exp(lerp(math.log(fz), math.log(z), u))
        elif b["in"] == "rise":
            u = ctx.tl / 0.62
            k = back_out(u, 1.1)
            cy += (1 - k) * self.WH * 0.55
            z *= lerp(0.94, 1.0, out3(u))
        if b.get("out") == "dive" and self.screen:
            fx, fy, fz = self.fill_cam()
            d = float(self.P.get("dive_dur", 0.55))
            u = expo_in(clamp((ctx.tl - (ctx.dur - d)) / d))
            if u > 0:
                cx, cy, z = lerp(cx, fx, u), lerp(cy, fy, u), math.exp(lerp(math.log(z), math.log(fz), u))
        return cx, cy, z

    def view(self, img, ctx):
        cx, cy, z = self.camera(ctx)
        return View(img, cx, cy, z * self.plan.scale)

    def page(self, v, color=None, grid=True):
        v.fill(color or self.Lk["page"])
        if grid and self.plan.j.get("grid", True):
            step = 64
            g = self.Lk["grid"]
            # world bounds on screen
            x0 = v.cx - v.W / 2 / v.z
            x1 = v.cx + v.W / 2 / v.z
            y0 = v.cy - v.H / 2 / v.z
            y1 = v.cy + v.H / 2 / v.z
            for gx in range(int(x0 // step) * step, int(x1) + step, step):
                sx = v.p(gx, 0)[0]
                v.d.line([(sx, 0), (sx, v.H)], fill=rgba(g), width=1)
            for gy in range(int(y0 // step) * step, int(y1) + step, step):
                sy = v.p(0, gy)[1]
                v.d.line([(0, sy), (v.W, sy)], fill=rgba(g), width=1)

    def draw(self, img, ctx):
        raise NotImplementedError


# ---- full -----------------------------------------------------------------------------------------------------------
def _persp_coeffs(dst, src):
    """Coefficients for PIL's PERSPECTIVE transform mapping dst quad (output) -> src quad (input)."""
    A, B = [], []
    for (x, y), (u, v) in zip(dst, src):
        A.append([x, y, 1, 0, 0, 0, -u * x, -u * y])
        A.append([0, 0, 0, x, y, 1, -v * x, -v * y])
        B += [u, v]
    return np.linalg.solve(np.array(A, float), np.array(B, float)).tolist()


class Full(Stage):
    def setup(self):
        self.screen = (0, 0, self.WW, self.WH)

    def base_cam(self, ctx):
        return self.WW / 2, self.WH / 2, 1.0

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        v.fill("#000000")
        ctx.him(v, 0, 0, self.WW, self.WH)
        ins = self.P.get("insert")
        if ins:
            self._insert(v, ctx, ins)

    def _insert(self, v, ctx, ins):
        """A picture on a surface of his room: quad = 4 corners [x, y] as fractions of the source frame (tl, tr, br,
        bl). It rides with the lens crop, so it stays on the wall while the camera moves."""
        plan = self.plan
        a = plan.T(ins.get("at", self.beat["t0"]))
        b = plan.T(ins.get("until", self.beat["t1"]))
        if not (a <= ctx.t <= b + 0.3):
            return
        u = out3((ctx.t - a) / 0.35) * (1 - out3((ctx.t - b) / 0.3) if ctx.t > b else 1)
        src_img = self.res.image(ins["image"]).convert("RGBA")
        fw, fh = ctx.frame.size
        box, _ = L.crop(plan, ctx.faces, self.beat, ctx.t, ctx.frame.size, (plan.W, plan.H), ctx.src, ctx.src_t)
        sxk, syk = plan.W / (box[2] - box[0]), plan.H / (box[3] - box[1])
        quad = [((qx * fw - box[0]) * sxk, (qy * fh - box[1]) * syk) for qx, qy in ins["quad"]]
        xs, ys = [q[0] for q in quad], [q[1] for q in quad]
        x0, y0 = max(0, int(min(xs))), max(0, int(min(ys)))
        x1, y1 = min(plan.W, int(math.ceil(max(xs)))), min(plan.H, int(math.ceil(max(ys))))
        if x1 - x0 < 2 or y1 - y0 < 2:
            return
        iw, ih = src_img.size
        # flip in from the left edge of the quad
        qd = [(qx - x0, qy - y0) for qx, qy in quad]
        if u < 1:
            l0, l1 = qd[0], qd[3]
            qd = [qd[0], (lerp(l0[0], qd[1][0], u), lerp(l0[1], qd[1][1], u)),
                  (lerp(l1[0], qd[2][0], u), lerp(l1[1], qd[2][1], u)), qd[3]]
        c = _persp_coeffs(qd, [(0, 0), (iw, 0), (iw, ih), (0, ih)])
        warped = src_img.transform((x1 - x0, y1 - y0), Image.PERSPECTIVE, c, Image.BICUBIC)
        a_ = warped.getchannel("A").point(lambda q: int(q * float(ins.get("opacity", 0.96))))
        img = v.img
        img.paste(warped.convert("RGB"), (x0, y0), a_)


# ---- shared content blocks (beside + takeover) -----------------------------------------------------------------------
def block(v, ctx, c, x, y, w, h, plan):
    """One idea inside the world box (x, y, w, h): points | number | text | image | logo."""
    kind = c.get("kind", "text")
    t = ctx.t
    ink, muted, acc = plan.look["ink"], plan.look["muted"], plan.accent
    a0 = plan.T(c.get("at", ctx.beat["t0"]))
    if kind == "text":
        size = float(c.get("size", 96))
        bh = text_height(c["text"], c.get("font", "display"), size, w, int(c.get("lines", 4)))
        if c.get("kicker"):
            u = out5((t - a0) / 0.3)
            v.text(x + w / 2, y + h / 2 - bh / 2 - 46, c["kicker"].upper(), "monob", 26, acc, "mm", alpha=u,
                   tracking=2)
        draw_rich(v, plan, x + w / 2, y + h / 2, c["text"], t, a0, ctx.beat["t1"], name=c.get("font", "display"),
                  size=size, max_w=w, max_lines=int(c.get("lines", 4)))
        if c.get("sub"):
            sa = plan.T(c.get("sub_at", a0))
            u = out5((t - sa) / 0.35)
            v.text(x + w / 2, y + h / 2 + bh / 2 + 60, c["sub"], "body", 36, muted, "mm", alpha=u)
    elif kind == "points":
        items = c.get("items", [])
        title = c.get("title")
        yy = y
        if title:
            u = out5((t - a0) / 0.3)
            v.text(x, yy + (1 - u) * 16, title, "heavy", 58, ink, "la", alpha=u)
            yy += 100
        step = min(150, (y + h - yy) / max(1, len(items)))
        for i, it in enumerate(items):
            txt, at = (it, None) if isinstance(it, str) else (it[0], it[1] if len(it) > 1 else None)
            ti = plan.T(at) if at is not None else a0 + 0.35 * (i + 1)
            u = out5((t - ti) / 0.32)
            if u <= 0:
                continue
            iy = yy + i * step + (1 - u) * 24
            v.shadow(x, iy, w, step - 22, r=22, blur=18, alpha=0.08 * u, dy=8)
            v.rect(x, iy, w, step - 22, fill=plan.look["card"], r=22, outline=plan.look["hair"], width=1.5, alpha=u)
            v.circle(x + 52, iy + (step - 22) / 2, 26, fill=acc, alpha=u)
            v.text(x + 52, iy + (step - 22) / 2, str(i + 1), "heavy", 28, "#FFFFFF", "mm", alpha=u)
            fs = 44 if font("bold", 44).getlength(txt) < w - 130 else 36
            v.text(x + 100, iy + (step - 22) / 2, txt, "bold", fs, ink, "lm", alpha=u)
    elif kind == "number":
        dur = float(c.get("dur", 1.0))
        txt = count_text(c["value"], (t - a0) / dur, c.get("from"))
        u = out5((t - a0) / 0.3)
        size = float(c.get("size", 220))
        v.text(x + w / 2, y + h * 0.46 + (1 - u) * 20, txt, "display", size, c.get("color", ink), "mm", alpha=u)
        if c.get("label"):
            v.text(x + w / 2, y + h * 0.46 + size * 0.7, c["label"], "bold", 44, muted, "mm", alpha=u)
        if c.get("ring") is not None:
            frac = float(c["ring"]) * out5((t - a0) / dur)
            ring(v, x + w / 2, y + h * 0.46, size * 1.25, size * 0.09, frac, acc, plan.look["hair"], u)
    elif kind == "image":
        img = ctx.res.image(c["file"])
        iw, ih = img.size
        s = min(w / iw, h / ih)
        dw, dh = iw * s, ih * s
        u = out5((t - a0) / 0.4)
        ix, iy = x + (w - dw) / 2, y + (h - dh) / 2 + (1 - u) * 30
        v.shadow(ix, iy, dw, dh, r=18, blur=26, alpha=0.14 * u, dy=14)
        v.image(img, ix, iy, dw, dh, r=float(c.get("radius", 18)), alpha=u)
        if c.get("mark"):
            mx, my, mw, mh = c["mark"]
            ma = plan.T(c.get("mark_at", a0 + 0.5))
            k = out3((t - ma) / 0.45)
            if k > 0:
                v.rect(ix + mx * s, iy + my * s, mw * s * k, mh * s, fill=rgba(acc, 0.28), r=4)
        if c.get("caption"):
            v.text(x + w / 2, iy + dh + 46, c["caption"], "mono", 24, muted, "mm", alpha=u)
    elif kind == "logo":
        img = ctx.res.image(c["file"])
        iw, ih = img.size
        hh = float(c.get("height", 220))
        s = hh / ih
        u = back_out((t - a0) / 0.45, 1.3)
        dw, dh = iw * s * u, ih * s * u
        v.image(img, x + w / 2 - dw / 2, y + h * 0.42 - dh / 2, dw, dh, alpha=clamp((t - a0) / 0.15))
        if c.get("name"):
            v.text(x + w / 2, y + h * 0.42 + hh * 0.5 + 60, c["name"], "heavy", 56, ink, "mm",
                   alpha=out5((t - a0 - 0.15) / 0.3))


def text_height(text, name, size, max_w, max_lines):
    from .typeset import fit, layout
    toks = tokens(text)
    size = fit(toks, name, size, max_w, max_lines)
    return len(layout(toks, name, size, max_w)) * size * 1.08


def ring(v, cx, cy, d, th, frac, color, track, alpha=1.0):
    """A progress ring (anti-aliased) of diameter d and thickness th, filled to frac clockwise from 12 o'clock."""
    b = v.box(cx - d / 2, cy - d / 2, d, d)
    x0, y0 = int(b[0]), int(b[1])
    n = int(b[2] - b[0]) + 2
    if n < 4:
        return
    r_out, r_in = (b[2] - b[0]) / 2, (b[2] - b[0]) / 2 - th * v.z
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float32)
    dx, dy = xx + 0.5 - (b[0] - x0) - r_out, yy + 0.5 - (b[1] - y0) - r_out
    rr = np.hypot(dx, dy)
    cov = np.clip(r_out - rr + 0.5, 0, 1) * np.clip(rr - r_in + 0.5, 0, 1)
    ang = (np.arctan2(dx, -dy) / (2 * np.pi)) % 1.0
    on = np.clip((frac - ang) * n * 0.5, 0, 1)
    for col, m in ((track, cov * (1 - on)), (color, cov * on)):
        mm = Image.fromarray((m * 255 * alpha).astype(np.uint8), "L")
        v.img.paste(rgba(col)[:3], (x0, y0), mm)


# ---- beside ---------------------------------------------------------------------------------------------------------
class Beside(Stage):
    def setup(self):
        P, WW, WH = self.P, self.WW, self.WH
        self.shape = P.get("shape", "card")
        right = P.get("side", "left") == "right"
        if self.plan.portrait:
            if self.shape == "circle":
                d = 700
                self.me = (WW / 2 - d / 2, 250, d, d)
            else:
                self.me = (90, 220, 900, 1000)
            self.slot = (90, self.me[1] + self.me[3] + 70, 900, WH - (self.me[1] + self.me[3] + 70) - 260)
        else:
            if self.shape == "circle":
                d = 660
                self.me = (WW - 160 - d if right else 160, (WH - d) / 2, d, d)
            else:
                self.me = (WW - 120 - 760 if right else 120, 130, 760, 820)
            sx = 120 if right else self.me[0] + self.me[2] + 110
            self.slot = (sx, 150, WW - 120 - (self.me[2] + 110) - 120, WH - 300)
        self.screen = self.me

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        self.page(v)
        x, y, w, h = self.me
        r = w / 2 if self.shape == "circle" else 40
        v.shadow(x, y, w, h, r=r, blur=30, alpha=0.18, dy=20)
        ctx.him(v, x, y, w, h, r=r)
        c = self.P.get("content")
        if c:
            block(v, ctx, c, *self.slot, self.plan)


# ---- editor ---------------------------------------------------------------------------------------------------------
ED = dict(bg="#0F1013", panel="#18191D", border="#2A2C32", txt="#E8E8EA", dim="#8B8E96", lane="#141518",
          v1="#2F5FD0", v1top="#4C7DF0", a1="#1B4D36", a1w="#3ADB8C", v2="#6B47C9", v2top="#8C68EA", a2="#5A3E14",
          a2w="#F2B04A", head="#1F2025")


class Editor(Stage):
    def setup(self):
        WW, WH = self.WW, self.WH
        pt = self.plan.portrait
        if pt:
            self.mon = (40, 96, 1000, 562.5)
            self.tl = dict(x=12, y=760, w=1056, h=1120, hx=104, ruler=812, pps=86,
                           tracks=[("V2", 846, 84), ("V1", 938, 170), ("A1", 1116, 130), ("A2", 1254, 96)])
            self.insp = None
            self.transport_y = 690
        else:
            self.mon = (488, 62, 944, 531)
            self.tl = dict(x=12, y=652, w=1896, h=416, hx=122, ruler=698, pps=112,
                           tracks=[("V2", 728, 54), ("V1", 788, 96), ("A1", 890, 78), ("A2", 974, 60)])
            self.insp = (1508, 52, 400, 588)
            self.transport_y = 616
        self.screen = self.mon
        self.trk = {n: (y, h) for n, y, h in self.tl["tracks"]}
        self.static = Sprite(WW, WH, self._chrome)
        self.razors = self._razors()

    def _razors(self):
        P, plan, b = self.P, self.plan, self.beat
        r = P.get("razor", "auto")
        if r == "auto":
            ts = [tp for tp, _, _ in plan.punches if b["t0"] + 0.9 < tp < b["t1"] - 0.2]
        else:
            ts = [plan.T(x) for x in (r or [])]
        return sorted(ts)

    def _chrome(self, k):
        WW, WH = self.WW, self.WH
        pt = self.plan.portrait
        k.rect(0, 0, WW, WH, fill=ED["bg"])
        # title bar
        k.rect(0, 0, WW, 44, fill="#151619")
        for i, c in enumerate(("#FF5F57", "#FEBC2E", "#28C840")):
            k.ellipse(18 + i * 24, 15, 14, 14, fill=c)
        k.text(WW / 2, 22, self.P.get("project", "main_edit_v7  —  Edited"), "mono", 16, ED["dim"], "mm")
        mx, my, mw, mh = self.mon
        if not pt:
            # media bin
            k.rect(12, 52, 466, 588, fill=ED["panel"], r=10, outline=ED["border"])
            k.text(30, 70, "Media", "bold", 18, ED["txt"])
            k.text(110, 72, "Effects   Titles   Audio", "body", 15, ED["dim"])
            names = self.P.get("files", ["take_01.mp4", "take_02.mp4", "take_03.mp4", "music_bed.wav",
                                         "broll_desk.mp4", "end_card.png"])
            segs = self.plan.segs
            for i, nm in enumerate(names[:6]):
                cx, cy = 30 + (i % 2) * 222, 110 + (i // 2) * 168
                if nm.endswith((".wav", ".mp3")):
                    k.rect(cx, cy, 204, 115, fill=ED["a2"], r=6)
                    for j in range(30):
                        hh = 10 + 34 * abs(math.sin(j * 1.7) * math.cos(j * 0.37))
                        k.rect(cx + 14 + j * 6, cy + 57 - hh / 2, 3, hh, fill=ED["a2w"])
                elif nm.endswith(".png"):
                    k.rect(cx, cy, 204, 115, fill="#26272C", r=6)
                    k.text(cx + 102, cy + 58, "Aa", "display", 44, "#FFFFFF", "mm")
                else:
                    th = self.res.thumb(min(len(segs) - 1, (i * max(1, len(segs) // 3)) % max(1, len(segs))))
                    k.paste(th, cx, cy, 204, 115, r=6)
                k.text(cx, cy + 128, nm, "mono", 14, ED["dim"])
            # inspector
            ix, iy, iw, ih = self.insp
            k.rect(ix, iy, iw, ih, fill=ED["panel"], r=10, outline=ED["border"])
            k.text(ix + 18, iy + 18, "Inspector", "bold", 18, ED["txt"])
            k.text(ix + 18, iy + 66, "TRANSFORM", "monob", 13, ED["dim"])
            for j, nm in enumerate(("Scale", "Position", "Rotation", "Opacity")):
                k.text(ix + 18, iy + 104 + j * 46, nm, "body", 17, ED["txt"])
            k.text(ix + 18, iy + 300, "COLOR", "monob", 13, ED["dim"])
            for j, nm in enumerate(("Exposure", "Contrast", "Saturation")):
                k.text(ix + 18, iy + 338 + j * 46, nm, "body", 17, ED["txt"])
                k.rect(ix + 200, iy + 349 + j * 46, 120, 4, fill="#2E3036", r=2)
            k.text(ix + 18, iy + 486, "SPEED", "monob", 13, ED["dim"])
            k.text(ix + 18, iy + 524, "Rate", "body", 17, ED["txt"])
        # program monitor
        if pt:
            k.rect(12, 56, WW - 24, 680, fill=ED["panel"], r=10, outline=ED["border"])
        else:
            k.rect(484 - 8 - 4, 52, 1032 - 8 + 16, 588, fill=ED["panel"], r=10, outline=ED["border"])
        k.rect(mx, my, mw, mh, fill="#000000")
        ty = self.transport_y
        k.text(mx + mw - 6, ty, "Fit  ▾", "body", 16, ED["dim"], "rm")
        # timeline
        T = self.tl
        k.rect(T["x"], T["y"], T["w"], T["h"], fill=ED["panel"], r=10, outline=ED["border"])
        k.rect(T["x"] + 1, T["y"] + 1, T["hx"] - T["x"], T["h"] - 2, fill=ED["head"], r=10)
        for n, y, h in T["tracks"]:
            k.rect(T["hx"], y, T["x"] + T["w"] - T["hx"] - 4, h, fill=ED["lane"])
            k.text(T["x"] + 22, y + h / 2, n, "monob", 18, ED["txt"], "lm")
            k.ellipse(T["x"] + 64, y + h / 2 - 6, 12, 12, outline=ED["dim"], width=2)

    # timeline x of output time tt
    def tx(self, tt, off):
        return self.tl["hx"] + tt * self.tl["pps"] - off

    def offset(self, t):
        T = self.tl
        lane_w = T["x"] + T["w"] - T["hx"]
        return max(0.0, t * T["pps"] - 0.42 * lane_w)

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        plan, t = self.plan, ctx.t
        self.static.draw(v, 0, 0)
        mx, my, mw, mh = self.mon
        ctx.him(v, mx, my, mw, mh)
        z = ctx.zoom()
        # timecode + transport
        ty = self.transport_y
        f = int(round(t * plan.fps))
        fps_i = int(round(plan.fps))
        tc = f"{f // (3600 * fps_i):02d}:{f // (60 * fps_i) % 60:02d}:{f // fps_i % 60:02d}:{f % fps_i:02d}"
        v.text(mx + 6, ty, tc, "monob", 20, ED["txt"], "lm")
        icon(v, "play", mx + mw / 2 - 12, ty - 12, 24, ED["txt"])
        # inspector values (follow the lens)
        if self.insp:
            ix, iy, iw, ih = self.insp
            punch = any(tp - 0.1 <= t <= tp + hold for tp, _, hold in plan.punches)
            if punch:
                v.rect(ix + 8, iy + 88, iw - 16, 34, fill=rgba(plan.accent, 0.22), r=6)
            vals = [f"{z * 100:.1f} %", "960, 540", "0.0 °", "100 %"]
            for j, s in enumerate(vals):
                v.rect(ix + 200, iy + 92 + j * 46, 176, 28, fill="#24262B", r=5)
                v.text(ix + 210, iy + 106 + j * 46, s, "mono", 16, plan.accent if (j == 0 and punch) else ED["txt"],
                       "lm")
            for j, (val, frac) in enumerate((("+0.20", 0.58), ("+8", 0.54), ("+6", 0.53))):
                v.rect(ix + 200, iy + 349 + j * 46, 120 * frac, 4, fill=plan.accent, r=2)
                v.text(ix + 336, iy + 351 + j * 46, val, "mono", 15, ED["txt"], "lm")
            v.text(ix + 200, iy + 530, f"{plan.speed * 100:.0f} %", "mono", 16, ED["txt"], "lm")
        else:
            v.rect(mx + 16, my + 16, 190, 40, fill=(0, 0, 0, 150), r=8)
            v.text(mx + 30, my + 36, f"Scale {z * 100:.0f}%", "mono", 18, "#FFFFFF", "lm")
        self._timeline(v, ctx)
        self._cursor(v, ctx)

    def _timeline(self, v, ctx):
        plan, t, T = self.plan, ctx.t, self.tl
        off = self.offset(t)
        pps = T["pps"]
        lx0, lx1 = T["hx"], T["x"] + T["w"] - 4
        t_lo, t_hi = off / pps, (off + lx1 - lx0) / pps
        # ruler
        ry = T["ruler"]
        s = int(t_lo)
        while s <= t_hi + 1:
            for half in (0, 0.5):
                tt = s + half
                x = self.tx(tt, off)
                if lx0 <= x <= lx1:
                    hgt = 12 if half == 0 else 6
                    v.rect(x, ry + 22 - hgt, 1.5, hgt, fill=ED["dim"])
                    if half == 0 and s % 2 == 0:
                        v.text(x + 4, ry + 4, f"00:{s // 60:02d}:{s % 60:02d}", "mono", 12, ED["dim"])
            s += 1
        clipv = lambda x0, x1: (max(lx0, x0), min(lx1, x1))
        # V1: the real cut
        y1, h1 = self.trk["V1"]
        for k, sg in enumerate(plan.segs):
            a, b = sg["f0"] / plan.fps, (sg["f0"] + sg["n"]) / plan.fps
            if b < t_lo or a > t_hi:
                continue
            x0, x1 = clipv(self.tx(a, off) + 1, self.tx(b, off) - 1)
            if x1 - x0 < 2:
                continue
            sel = a <= t < b
            v.rect(x0, y1, x1 - x0, h1, fill=ED["v1"], r=4)
            v.rect(x0, y1, x1 - x0, 22, fill=ED["v1top"], r=4)
            th = self.res.thumb(k)
            tw = (h1 - 26) * 16 / 9
            xx = self.tx(a, off) + 2
            while xx < x1 - 4:
                if xx + tw > lx0:
                    w_ = min(tw, x1 - 2 - xx)
                    if w_ > 6:
                        v.image(th, max(xx, x0), y1 + 24, w_ - max(0, x0 - xx), h1 - 26,
                                sbox=(th.width * max(0, x0 - xx) / tw, 0, th.width * w_ / tw, th.height))
                xx += tw
            label = " ".join(w["w"] for w in plan.wlist if w["seg"] == k)[:40]
            if x1 - x0 > 60:
                v.text(x0 + 6, y1 + 11, label or f"clip {k + 1}", "body", 13, "#FFFFFF", "lm")
            if sel:
                v.rect(x0, y1, x1 - x0, h1, outline="#FFFFFF", width=2, r=4)
        # razor splits (drawn after they happen)
        for tr in self.razors:
            if tr <= t:
                x = self.tx(tr, off)
                if lx0 < x < lx1:
                    v.rect(x - 1.5, y1 - 4, 3, h1 + 8, fill="#FFFFFF")
        # V2: the plan's type events as title clips
        y2, h2 = self.trk["V2"]
        for ev in plan.j.get("type", []):
            a, b = ev.get("_t0"), ev.get("_t1")
            if a is None or b < t_lo or a > t_hi:
                continue
            x0, x1 = clipv(self.tx(a, off), self.tx(b, off))
            if x1 - x0 < 3:
                continue
            v.rect(x0, y2 + 6, x1 - x0, h2 - 12, fill=ED["v2"], r=4)
            if x1 - x0 > 40:
                v.text(x0 + 8, y2 + h2 / 2, "T  " + ev.get("text", "").replace("*", "")[:24], "bold", 13, "#FFFFFF",
                       "lm")
        # A1: his voice, the real waveform
        ya, ha = self.trk["A1"]
        env = self.res.env
        for k, sg in enumerate(plan.segs):
            a, b = sg["f0"] / plan.fps, (sg["f0"] + sg["n"]) / plan.fps
            if b < t_lo or a > t_hi:
                continue
            x0, x1 = clipv(self.tx(a, off) + 1, self.tx(b, off) - 1)
            if x1 - x0 > 2:
                v.rect(x0, ya, x1 - x0, ha, fill=ED["a1"], r=4)
        if env is not None:
            cy = ya + ha / 2
            x = lx0
            while x < lx1:
                tt = (x - lx0 + off) / pps
                if 0 <= tt < plan.duration:
                    e = float(env[min(len(env) - 1, int(tt * plan.fps))])
                    hh = max(2, e * (ha - 14))
                    v.rect(x, cy - hh / 2, 2, hh, fill=ED["a1w"])
                x += 4
        # A2: the music bed
        ym, hm = self.trk["A2"]
        if plan.j.get("music", {}).get("file"):
            x0, x1 = clipv(self.tx(0, off), self.tx(plan.duration, off))
            v.rect(x0, ym, x1 - x0, hm, fill=ED["a2"], r=4)
            menv = self.res.menv
            x = x0
            while x < x1:
                tt = (x - lx0 + off) / pps
                e = float(menv[min(len(menv) - 1, int(tt * plan.fps))]) if menv is not None and len(menv) else \
                    0.5 + 0.3 * math.sin(tt * 3.1) * math.cos(tt * 1.3)
                hh = max(2, e * (hm - 14))
                v.rect(x, ym + hm / 2 - hh / 2, 2, hh, fill=ED["a2w"])
                x += 4
            if x1 - x0 > 80:
                v.text(x0 + 8, ym + 12, plan.j["music"].get("name", "music_bed"), "body", 12, "#FFFFFF", "lm")
        # playhead
        px = self.tx(t, off)
        v.rect(px - 1, ry, 2.5, T["y"] + T["h"] - ry - 8, fill=plan.accent)
        v.poly([(px - 9, ry), (px + 9, ry), (px + 9, ry + 12), (px, ry + 20), (px - 9, ry + 12)], fill=plan.accent)

    def _cursor(self, v, ctx):
        """The cursor: idles near the monitor, takes the razor before each split and clicks on the playhead."""
        t = ctx.t
        T = self.tl
        off_at = self.offset
        idle = (self.mon[0] + self.mon[2] * 0.82, self.mon[1] + self.mon[3] + 40)
        tool = (T["x"] + 74, T["y"] + 22)
        way = [(self.beat["t0"], idle, None)]
        for tr in self.razors:
            way.append((tr - 0.85, tool, "razor"))
            way.append((tr, (self.tx(tr, off_at(tr)) + 2, self.trk["V1"][0] + self.trk["V1"][1] * 0.55), "cut"))
        if self.razors:
            way.append((self.razors[-1] + 0.9, idle, None))
        pos = way[0][1]
        click = None
        for i in range(1, len(way)):
            ta, pa, _ = way[i - 1]
            tb, pb, kind = way[i]
            if t < tb - 0.5:
                pos = pa if t >= ta else pos
                break
            u = inout3((t - (tb - 0.5)) / 0.5)
            pos = (lerp(pa[0], pb[0], u), lerp(pa[1], pb[1], u))
            if kind and tb <= t < tb + 0.3:
                click = (t - tb) / 0.3
        # the razor tool is lit from its pick to its cut
        razor_on = any(tr - 0.85 <= t <= tr + 0.2 for tr in self.razors)
        icon(v, "razor", tool[0] - 13, tool[1] - 13, 26, self.plan.accent if razor_on else ED["dim"])
        icon(v, "cursor", T["x"] + 16, T["y"] + 10, 24, ED["txt"] if not razor_on else ED["dim"])
        icon(v, "hand", T["x"] + 110, T["y"] + 9, 26, ED["dim"])
        if click is not None:
            r = 10 + 26 * out3(click)
            v.circle(pos[0], pos[1], r, outline=self.plan.accent, width=3, alpha=1 - click)
        if razor_on and any(tr - 0.4 <= t <= tr + 0.2 for tr in self.razors):
            icon(v, "razor", pos[0] - 4, pos[1] - 4, 30, "#FFFFFF")
        else:
            icon(v, "cursor", pos[0], pos[1], 30, "#FFFFFF")


# ---- phone ----------------------------------------------------------------------------------------------------------
class Phone(Stage):
    def setup(self):
        WW, WH, P = self.WW, self.WH, self.P
        ph = WH * (0.8 if self.plan.portrait else 0.86)
        pw = ph * 0.487
        cx = float(P.get("x", 0.5)) * WW
        self.body = (cx - pw / 2, (WH - ph) / 2, pw, ph)
        bx, by, bw, bh = self.body
        self.scr = (bx + 13, by + 13, bw - 26, bh - 26)
        self.screen = self.scr
        self.sprite = Sprite(bw, bh, self._body, shadow=(28, 0.28, 22))
        # the free side of the page (for props.content)
        if self.plan.portrait:
            self.slot = None
        elif cx < WW * 0.45:
            self.slot = (bx + bw + 110, 160, WW - (bx + bw + 110) - 110, WH - 320)
        elif cx > WW * 0.55:
            self.slot = (110, 160, bx - 220, WH - 320)
        else:
            self.slot = None

    def _body(self, k):
        bw, bh = self.body[2], self.body[3]
        k.rect(0, 0, bw, bh, fill="#1B1C1F", r=bw * 0.15)
        k.rect(2, 2, bw - 4, bh - 4, fill="#0A0A0B", r=bw * 0.145, outline="#3A3B40", width=2)
        k.rect(-3, bh * 0.22, 5, 60, fill="#2A2B2F", r=2)
        k.rect(-3, bh * 0.31, 5, 90, fill="#2A2B2F", r=2)
        k.rect(bw - 2, bh * 0.27, 5, 120, fill="#2A2B2F", r=2)

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        self.page(v)
        bx, by, bw, bh = self.body
        self.sprite.draw(v, bx, by)
        sx, sy, sw, sh = self.scr
        r = bw * 0.12
        ctx.him(v, sx, sy, sw, sh, r=r)
        P, plan, t = self.P, self.plan, ctx.t
        ui = P.get("ui", "reels")
        sc = sw / 420
        # top fade + island
        v.rect(sx + sw / 2 - 58 * sc, sy + 12 * sc, 116 * sc, 32 * sc, fill="#000000", r=16 * sc)
        if ui == "reels":
            W = "#FFFFFF"
            v.text(sx + 22 * sc, sy + 76 * sc, P.get("tab", "Reels"), "heavy", 26 * sc, W, "lm", stroke=1,
                   stroke_fill=(0, 0, 0, 90))
            icon(v, "camera", sx + sw - 50 * sc, sy + 62 * sc, 28 * sc, W)
            likes = P.get("likes", "48.2K")
            if isinstance(likes, list):
                u = clamp(ctx.tl / max(0.5, ctx.dur * 0.8))
                likes = count_text(likes[1], u, likes[0])
            col = [("heart", likes), ("comment", P.get("comments", "1,204")), ("share", P.get("shares", "3.1K"))]
            liked = P.get("like") is not None and t >= plan.T(P["like"])
            for i, (nm, cnt) in enumerate(col):
                iy = sy + sh - 400 * sc + i * 86 * sc
                c = plan.accent if (nm == "heart" and liked) else W
                icon(v, nm, sx + sw - 54 * sc, iy, 34 * sc, c, fill=nm == "heart" and liked)
                v.text(sx + sw - 37 * sc, iy + 48 * sc, str(cnt), "bold", 15 * sc, W, "mm", stroke=1,
                       stroke_fill=(0, 0, 0, 120))
            icon(v, "vdots", sx + sw - 50 * sc, sy + sh - 140 * sc, 26 * sc, W)
            # bottom: handle + caption
            ay = sy + sh - 132 * sc
            v.circle(sx + 38 * sc, ay, 19 * sc, fill=plan.accent, outline="#FFFFFF", width=2)
            v.text(sx + 66 * sc, ay, P.get("handle", plan.handle), "bold", 18 * sc, W, "lm", stroke=1,
                   stroke_fill=(0, 0, 0, 120))
            hw = font("bold", 18).getlength(P.get("handle", plan.handle)) * sc
            v.rect(sx + 76 * sc + hw, ay - 14 * sc, 70 * sc, 28 * sc, outline="#FFFFFF", width=1.5, r=8 * sc)
            v.text(sx + 111 * sc + hw, ay, "Follow", "bold", 14 * sc, W, "mm")
            if P.get("caption"):
                v.text(sx + 22 * sc, ay + 40 * sc, P["caption"], "body", 16 * sc, W, "lm", stroke=1,
                       stroke_fill=(0, 0, 0, 120))
            icon(v, "note", sx + 22 * sc, ay + 62 * sc, 16 * sc, W)
            v.text(sx + 46 * sc, ay + 70 * sc, P.get("audio", "Original audio"), "body", 14 * sc, W, "lm")
            # progress
            prog = clamp(ctx.tl / max(0.1, ctx.dur))
            v.rect(sx + 14 * sc, sy + sh - 22 * sc, (sw - 28 * sc), 3 * sc, fill=(255, 255, 255, 70), r=2)
            v.rect(sx + 14 * sc, sy + sh - 22 * sc, (sw - 28 * sc) * prog, 3 * sc, fill="#FFFFFF", r=2)
            if liked:
                u = t - plan.T(P["like"])
                if u < 0.9:
                    k = back_out(u / 0.35, 2.2) if u < 0.35 else 1.0
                    al = 1 - out3((u - 0.5) / 0.4) if u > 0.5 else 1
                    s_ = 150 * sc * k
                    icon(v, "heart", sx + sw / 2 - s_ / 2, sy + sh * 0.42 - s_ / 2, s_, "#FFFFFF", alpha=al)
        n = P.get("notif")
        if n:
            a = plan.T(n.get("at", self.beat["t0"] + 0.6))
            b = plan.T(n.get("until", a + 2.6))
            if a <= t <= b + 0.5:
                u = out5((t - a) / 0.45) * (1 - in_(t, b))
                ny = sy + lerp(-150 * sc, 52 * sc, u)
                nx, nw, nh = sx + 10 * sc, sw - 20 * sc, 128 * sc
                v.shadow(nx, ny, nw, nh, r=24 * sc, blur=16, alpha=0.22, dy=8)
                v.rect(nx, ny, nw, nh, fill=(246, 246, 248, 245), r=24 * sc)
                v.rect(nx + 14 * sc, ny + 22 * sc, 56 * sc, 56 * sc, fill=n.get("color", plan.accent), r=13 * sc)
                v.text(nx + 42 * sc, ny + 50 * sc, n.get("app", "A")[:1].upper(), "heavy", 28 * sc, "#FFFFFF", "mm")
                v.text(nx + 84 * sc, ny + 32 * sc, n.get("title", n.get("app", "")), "bold", 22 * sc, "#111111", "lm")
                v.text(nx + nw - 16 * sc, ny + 32 * sc, "now", "body", 16 * sc, "#8A8A8F", "rm")
                from .core import wrap as _wrap
                lines = _wrap(n.get("text", ""), "body", 20, (nw / sc - 104))[:3]
                for li, ln in enumerate(lines):
                    v.text(nx + 84 * sc, ny + (62 + li * 25) * sc, ln, "body", 20 * sc, "#222222", "lm")
        if self.slot and P.get("content"):
            block(v, ctx, P["content"], *self.slot, plan)


def in_(t, b, d=0.3):
    return out3((t - b) / d) if t > b else 0.0


# ---- tv -------------------------------------------------------------------------------------------------------------
class TV(Stage):
    def setup(self):
        WW, WH = self.WW, self.WH
        self.retro = self.P.get("style") == "retro"
        pt = self.plan.portrait
        if self.retro:
            if pt:
                self.body = (90, 360, 900, 780)
                self.scr = (150, 420, 620, 465)
            else:
                self.body = (400, 110, 1120, 760)
                self.scr = (470, 170, 800, 600)
        else:
            if pt:
                self.scr = (60, 420, 960, 540)
            else:
                self.scr = (400, 104, 1120, 630)
            sx, sy, sw, sh = self.scr
            self.body = (sx - 16, sy - 16, sw + 32, sh + 32)
        self.screen = self.scr
        self.room = Sprite(WW, WH, self._room)
        self.scan = None

    def _room(self, k):
        WW, WH = self.WW, self.WH
        Lk = self.Lk
        k.rect(0, 0, WW, WH, fill=Lk["wall"])
        fy = self.body[1] + self.body[3] + (150 if not self.retro else 40)
        fy = min(fy, WH * 0.93)
        k.rect(0, fy, WW, WH - fy, fill=Lk["floor"])
        k.rect(0, fy - 3, WW, 3, fill=Lk["hair"])
        wood = "#CDB89B" if self.plan.look_name != "dark" else "#2B2622"
        if not self.retro:
            bx, by, bw, bh = self.body
            cy = by + bh + 34
            cw = bw * 1.42
            cxx = bx + bw / 2 - cw / 2
            k.rect(cxx, cy, cw, fy - cy - 18, fill=wood, r=6)
            k.rect(cxx, cy, cw, 8, fill=(0, 0, 0, 24), r=4)
            for j in range(1, 3):
                k.rect(cxx + cw * j / 3 - 1, cy + 20, 2, fy - cy - 50, fill=(0, 0, 0, 40))
            k.rect(cxx + 30, fy - 20, 14, 20, fill=(0, 0, 0, 60))
            k.rect(cxx + cw - 44, fy - 20, 14, 20, fill=(0, 0, 0, 60))
            # stand
            k.rect(bx + bw / 2 - 26, by + bh, 52, 26, fill="#1A1A1C")
            k.rect(bx + bw / 2 - 140, by + bh + 24, 280, 10, fill="#1A1A1C", r=4)
            # TV body
            k.rect(bx, by, bw, bh, fill="#0B0B0C", r=10)
            k.rect(bx + 3, by + 3, bw - 6, bh - 6, outline="#2A2A2E", width=2, r=9)
            # plant
            if not self.plan.portrait:
                px, py = bx + bw + 46, cy - 150
                k.poly([(px, py + 60), (px + 90, py + 60), (px + 76, py + 150), (px + 14, py + 150)], fill="#C8714A")
                for j, (ax, ay, w, h) in enumerate(((10, -80, 40, 140), (45, -110, 36, 170), (60, -60, 48, 120),
                                                    (-10, -40, 50, 100))):
                    k.ellipse(px + ax, py + ay + 60, w, h, fill=("#4E8B5A", "#3E7A4B", "#5C9B67", "#467F52")[j])
            # wall art
            if not self.plan.portrait:
                k.rect(120, 220, 170, 220, fill="#FFFFFF", outline=Lk["hair"], width=3)
                k.ellipse(160, 270, 90, 90, fill=self.plan.accent)
                k.rect(150, 380, 110, 8, fill=Lk["hair"])
        else:
            bx, by, bw, bh = self.body
            k.rect(bx, by, bw, bh, fill="#6E4A2E", r=40)
            k.rect(bx + 10, by + 10, bw - 20, bh - 20, outline="#8A6040", width=4, r=34)
            sx, sy, sw, sh = self.scr
            k.rect(sx - 20, sy - 20, sw + 40, sh + 40, fill="#1A1714", r=56)
            kx = sx + sw + 50
            for j in range(2):
                k.ellipse(kx, sy + 40 + j * 130, 90, 90, fill="#2A2420", outline="#B89B7A", width=4)
                k.rect(kx + 41, sy + 46 + j * 130, 8, 40, fill="#B89B7A")
            for j in range(6):
                k.rect(kx, sy + 330 + j * 26, 90, 8, fill="#3A2C20", r=4)
            k.rect(bx + 80, by + bh, 40, 60, fill="#3A2C20")
            k.rect(bx + bw - 120, by + bh, 40, 60, fill="#3A2C20")

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        self.room.draw(v, 0, 0)
        sx, sy, sw, sh = self.scr
        r = 46 if self.retro else 2
        tl = ctx.tl
        static_on = self.P.get("static", self.beat["in"] in ("cut", "static", "rise")) and tl < 0.36
        if static_on and tl < 0.22:
            n = np.random.default_rng(int(ctx.t * 1000)).integers(0, 255, (int(sh / 6), int(sw / 6)), dtype=np.uint8)
            noise = Image.fromarray(n, "L").convert("RGB")
            v.image(noise, sx, sy, sw, sh, r=r)
        else:
            if static_on:
                u = out3((tl - 0.22) / 0.14)
                hh = max(4, sh * u)
                v.rect(sx, sy, sw, sh, fill="#000000", r=r)
                ctx.him(v, sx, sy + sh / 2 - hh / 2, sw, hh, r=r)
            else:
                ctx.him(v, sx, sy, sw, sh, r=r)
        if self.retro:
            if self.scan is None:
                self.scan = _scanlines(int(sw), int(sh))
            v.image(self.scan, sx, sy, sw, sh, r=r)
            if tl < 1.4:
                v.text(sx + sw - 40, sy + 50, self.P.get("channel", "CH 07"), "monob", 44, "#7CFF7C", "rm",
                       alpha=1 - out3((tl - 1.1) / 0.3))
        P = self.P
        if P.get("live"):
            blink = 0.55 + 0.45 * math.sin(ctx.t * 6)
            v.rect(sx + 26, sy + 26, 118, 40, fill="#E5322D", r=6)
            v.circle(sx + 46, sy + 46, 7, fill="#FFFFFF", alpha=blink)
            v.text(sx + 60, sy + 46, "LIVE", "heavy", 24, "#FFFFFF", "lm")
        if P.get("ticker"):
            th = 58
            ty = sy + sh - th - 22
            u = out5((tl - 0.35) / 0.4)
            lab = P.get("ticker_label", "BREAKING")
            lw = font("heavy", 26).getlength(lab) + 40
            v.rect(sx + 22, ty + (1 - u) * 80, sw - 44, th, fill=(255, 255, 255, 235), r=4)
            v.rect(sx + 22, ty + (1 - u) * 80, lw, th, fill="#E5322D", r=4)
            v.text(sx + 22 + lw / 2, ty + th / 2 + (1 - u) * 80, lab, "heavy", 26, "#FFFFFF", "mm")
            # the ticker text scrolls inside the white bar (drawn on its own strip, so it clips at the bar)
            x0 = sx + 22 + lw
            bw_ = sx + sw - 22 - x0
            strip = _ticker_strip(P["ticker"], int(bw_), th, tl)
            v.image(strip, x0, ty + (1 - u) * 80, bw_, th)


def _ticker_strip(txt, w, h, tl, speed=150, k=2):
    f = font("heavy", 28 * k)
    img = Image.new("RGB", (w * k, h * k), (255, 255, 255))
    d = ImageDraw.Draw(img)
    unit = f.getlength(txt + "   •   ")
    x = -((tl * speed * k) % unit) + 24 * k
    while x < w * k:
        d.text((x, h * k / 2), txt + "   •   ", font=f, fill=(17, 17, 17), anchor="lm")
        x += unit
    return img


@functools.lru_cache(maxsize=4)
def _scanlines(w, h):
    a = np.zeros((h, w), np.float32)
    a[::4, :] = 0.16
    a[1::4, :] = 0.06
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.hypot((xx - w / 2) / (w / 2), (yy - h / 2) / (h / 2))
    a += np.clip((d - 0.7) * 0.9, 0, 0.55)
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    img.putalpha(Image.fromarray((a * 255).clip(0, 255).astype(np.uint8), "L"))
    return img


# ---- laptop / browser / call -------------------------------------------------------------------------------------------
def window_chrome(v, x, y, w, h, url, title, accent, dark=False):
    bar = 50
    v.shadow(x, y, w, h, r=16, blur=34, alpha=0.2, dy=22)
    v.rect(x, y, w, h, fill="#FFFFFF" if not dark else "#1E1F23", r=16)
    v.rect(x, y, w, bar, fill="#EEEEF0" if not dark else "#26272B", r=16)
    v.rect(x, y + bar - 16, w, 16, fill="#EEEEF0" if not dark else "#26272B")
    for i, c in enumerate(("#FF5F57", "#FEBC2E", "#28C840")):
        v.circle(x + 26 + i * 22, y + bar / 2, 6.5, fill=c)
    if title:
        tw = min(300, font("bold", 15).getlength(title) + 60)
        v.rect(x + 100, y + 8, tw, bar - 8, fill="#FFFFFF" if not dark else "#1E1F23", r=10)
        v.text(x + 120, y + bar / 2 + 4, title[:28], "bold", 15, "#333333" if not dark else "#DDD", "lm")
    uy = y + bar + 10
    v.rect(x + 20, uy, w - 40, 38, fill="#F2F2F4" if not dark else "#2A2B30", r=19)
    icon(v, "lock", x + 38, uy + 11, 16, "#7A7A80")
    v.text(x + 64, uy + 19, url, "body", 17, "#444444" if not dark else "#CCC", "lm")
    return y + bar + 58  # content top


class Browser(Stage):
    def setup(self):
        WW, WH = self.WW, self.WH
        pt = self.plan.portrait
        self.win = (60, 160, WW - 120, WH - 520) if pt else (110, 70, WW - 220, WH - 140)
        x, y, w, h = self.win
        self.player = self.P.get("player", not self.P.get("image"))
        if self.player:
            pw = w * 0.74
            self.vid = (x + (w - pw) / 2, y + 150, pw, pw * 9 / 16)
            self.screen = self.vid
        d = 300 if not pt else 340
        self.pip = (x + w - d - 50, y + h - d - 50, d) if not pt else (WW / 2 - d / 2, y + h + 40, d)

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        self.page(v)
        x, y, w, h = self.win
        P, plan, t = self.P, self.plan, ctx.t
        top = window_chrome(v, x, y, w, h, P.get("url", "github.com"), P.get("title", ""), plan.accent)
        ch = y + h - top - 2
        if P.get("image"):
            im = ctx.res.image(P["image"])
            s = (w - 4) / im.width
            vis_h = ch / s
            sc0, sc1 = P.get("scroll", [0, 0.6])
            u = inout3(clamp((ctx.tl - 0.4) / max(0.5, ctx.dur - 0.8)))
            maxoff = max(0, im.height - vis_h)
            off = lerp(sc0, sc1, u) * maxoff
            v.image(im, x + 2, top, w - 4, min(ch, im.height * s), sbox=(0, off, im.width, off + min(vis_h, im.height)))
            if P.get("mark"):
                mx, my, mw, mh = P["mark"]
                ma = plan.T(P.get("mark_at", self.beat["t0"] + 0.8))
                k = out3((t - ma) / 0.45)
                yy = top + (my - off) * s
                if k > 0 and top <= yy <= y + h:
                    v.rect(x + 2 + mx * s, yy, mw * s * k, mh * s, fill=rgba(plan.accent, 0.3), r=4)
            v.rect(x, y + h - 16, w, 16, fill="#FFFFFF")
        if self.player:
            vx, vy, vw, vh = self.vid
            ctx.him(v, vx, vy, vw, vh, r=14)
            v.text(vx, vy + vh + 44, P.get("video_title", "How I edit my videos with AI"), "heavy", 34,
                   plan.look["ink"] if plan.look_name != "dark" else "#111", "la")
            v.circle(vx + 26, vy + vh + 120, 24, fill=plan.accent)
            v.text(vx + 64, vy + vh + 112, P.get("channel", "Your channel"), "bold", 22, "#111111", "lm")
            v.text(vx + 64, vy + vh + 138, P.get("views", "12K views · 2 days ago"), "body", 18, "#777777", "lm")
            v.rect(vx, vy + vh - 6, vw * clamp(ctx.tl / max(0.1, ctx.dur)), 6, fill=plan.accent)
        elif P.get("pip", True):
            px, py, d = self.pip
            u = back_out((ctx.tl - 0.25) / 0.5, 1.4)
            if u > 0:
                dd = d * u
                cx, cy = px + d / 2, py + d / 2
                v.shadow(cx - dd / 2, cy - dd / 2, dd, dd, r=dd / 2, blur=22, alpha=0.25, dy=12)
                v.circle(cx, cy, dd / 2 + 7, fill="#FFFFFF")
                ctx.him(v, cx - dd / 2, cy - dd / 2, dd, dd, r=dd / 2)


class Laptop(Stage):
    def setup(self):
        WW, WH = self.WW, self.WH
        pt = self.plan.portrait
        if pt:
            self.lid = (40, 560, 1000, 640)
        else:
            self.lid = (300, 64, 1320, 830)
        lx, ly, lw, lh = self.lid
        self.scr = (lx + 20, ly + 20, lw - 40, lh - 46)
        sx, sy, sw, sh = self.scr
        self.winr = (sx + 34, sy + 30, sw - 68, sh - 60)
        wx, wy, ww, wh = self.winr
        self.content = (wx + 2, wy + 108, ww - 4, wh - 110)
        self.app = self.P.get("app", "player")
        if self.app == "player":
            cx, cy, cw, ch = self.content
            vw = min(cw - 80, (ch - 40) * 16 / 9)
            self.vid = (cx + (cw - vw) / 2, cy + 20, vw, vw * 9 / 16)
            self.screen = self.vid
        self.sprite = Sprite(WW, WH, self._body)

    def _body(self, k):
        lx, ly, lw, lh = self.lid
        k.rect(lx, ly, lw, lh, fill="#1C1C1F", r=26)
        k.rect(lx + 2, ly + 2, lw - 4, lh - 4, outline="#38383C", width=2, r=24)
        k.ellipse(lx + lw / 2 - 5, ly + 7, 10, 10, fill="#3A3A3E")
        sx, sy, sw, sh = self.scr
        # wallpaper: a soft wash of the accent
        steps = 24
        for i in range(steps):
            u = i / steps
            c = tuple(int(lerp(a, b, u)) for a, b in zip((236, 238, 244), (252, 228, 222)))
            k.rect(sx, sy + sh * u, sw, sh / steps + 1, fill=c)
        by = ly + lh
        k.poly([(lx - 120, by), (lx + lw + 120, by), (lx + lw + 90, by + 34), (lx - 90, by + 34)], fill="#C7C7CC")
        k.rect(lx - 120, by, lw + 240, 6, fill="#E3E3E7")
        k.rect(lx + lw / 2 - 110, by, 220, 12, fill="#A9A9AF", r=6)

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        self.page(v)
        self.sprite.draw(v, 0, 0)
        P, plan = self.P, self.plan
        wx, wy, ww, wh = self.winr
        window_chrome(v, wx, wy, ww, wh, P.get("url", "youtube.com"), P.get("title", ""), plan.accent)
        cx, cy, cw, ch = self.content
        if self.app == "player":
            vx, vy, vw, vh = self.vid
            ctx.him(v, vx, vy, vw, vh, r=10)
        elif self.app == "call":
            call_grid(v, ctx, (cx + 14, cy + 10, cw - 28, ch - 20), P, plan, small=True)
        elif self.app == "page" and P.get("image"):
            im = ctx.res.image(P["image"])
            s = cw / im.width
            off = lerp(*P.get("scroll", [0, 0.5]), inout3(clamp(ctx.tl / max(0.5, ctx.dur)))) * max(
                0, im.height - ch / s)
            v.image(im, cx, cy, cw, min(ch, im.height * s), sbox=(0, off, im.width, off + min(ch / s, im.height)))
            d = 230
            ctx_x, ctx_y = cx + cw - d - 30, cy + ch - d - 30
            v.circle(ctx_x + d / 2, ctx_y + d / 2, d / 2 + 6, fill="#FFFFFF")
            ctx.him(v, ctx_x, ctx_y, d, d, r=d / 2)


def call_grid(v, ctx, box, P, plan, small=False):
    x, y, w, h = box
    others = P.get("others", [{"name": "AI interviewer", "kind": "orb"}])
    n = 1 + len(others)
    g = 16
    if h > w * 1.1:
        # portrait: tiles stacked, each as wide as the frame
        th = min((h - g * (n - 1)) / n, w * 1.0)
        y0 = y + (h - (th * n + g * (n - 1))) / 2
        tiles = [(x, y0 + i * (th + g), w, th) for i in range(min(3, n))]
    elif n == 2:
        tw = (w - g) / 2
        th = min(h, tw * 9 / 16)
        tiles = [(x, y + (h - th) / 2, tw, th), (x + tw + g, y + (h - th) / 2, tw, th)]
    else:
        tw, th = (w - g) / 2, (h - g) / 2
        tiles = [(x + (i % 2) * (tw + g), y + (i // 2) * (th + g), tw, th) for i in range(min(4, n))]
    fs = 15 if small else 20
    me = P.get("me", "You")
    for i, (tx, ty, tw_, th_) in enumerate(tiles):
        v.rect(tx, ty, tw_, th_, fill="#2B2C30", r=14)
        if i == 0:
            ctx.him(v, tx, ty, tw_, th_, r=14)
            lvl = ctx.env
            if lvl > 0.45:
                v.rect(tx, ty, tw_, th_, outline="#34C759", width=4, r=14, alpha=min(1, (lvl - 0.45) * 3))
            name = me
        else:
            o = others[i - 1]
            name = o.get("name", "Guest")
            cx, cy = tx + tw_ / 2, ty + th_ / 2
            if o.get("kind", "orb") == "orb":
                pulse = 1 + 0.06 * math.sin(ctx.t * 5.2) + 0.04 * math.sin(ctx.t * 8.3)
                rr = min(tw_, th_) * 0.2 * pulse
                for j in range(5, 0, -1):
                    v.circle(cx, cy, rr * (1 + j * 0.16), fill=rgba(o.get("color", "#7C5CFF"), 0.07 * (6 - j)))
                v.circle(cx, cy, rr, fill=o.get("color", "#7C5CFF"))
                v.circle(cx - rr * 0.25, cy - rr * 0.3, rr * 0.35, fill=(255, 255, 255, 70))
            else:
                rr = min(tw_, th_) * 0.2
                v.circle(cx, cy, rr, fill=o.get("color", "#E07A3B"))
                ini = "".join(p[0] for p in name.split()[:2]).upper()
                v.text(cx, cy, ini, "heavy", rr * 0.8, "#FFFFFF", "mm")
        nw = font("bold", fs).getlength(name) + 28
        v.rect(tx + 14, ty + th_ - 44, nw, 32, fill=(0, 0, 0, 150), r=8)
        v.text(tx + 28, ty + th_ - 28, name, "bold", fs, "#FFFFFF", "lm")


class Call(Stage):
    def setup(self):
        WW, WH = self.WW, self.WH
        self.grid = (60, 110, WW - 120, WH - 270) if not self.plan.portrait else (40, 220, WW - 80, WH - 520)

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        v.fill("#1F2023")
        P, plan = self.P, self.plan
        pt = self.plan.portrait
        ty, fs = (130, 40) if pt else (56, 26)
        v.text(60, ty, P.get("title", "Interview"), "bold", fs, "#E8E8EA", "lm")
        secs = int(float(P.get("clock_from", 754)) + ctx.tl)
        v.text(self.WW - 60, ty, f"{secs // 60:02d}:{secs % 60:02d}", "mono", fs - 2, "#9A9CA3", "rm")
        call_grid(v, ctx, self.grid, P, plan)
        by = self.WH - 110 if not pt else self.WH - 250
        k = 1.0 if not pt else 1.5
        for i, (nm, col) in enumerate((("mic", "#3C4043"), ("cam", "#3C4043"), ("hangup", "#EA4335"))):
            cx = self.WW / 2 + (i - 1) * 96 * k
            v.circle(cx, by + 30 * k, 30 * k, fill=col)
            icon(v, nm, cx - 15 * k, by + 15 * k, 30 * k, "#FFFFFF")


# ---- cinema / polaroid / post -------------------------------------------------------------------------------------------
class Cinema(Stage):
    def setup(self):
        WW, WH = self.WW, self.WH
        self.scr = (210, 70, 1500, 844) if not self.plan.portrait else (40, 380, 1000, 562)
        self.screen = self.scr
        self.seats = Sprite(WW, WH, self._seats)

    def _seats(self, k):
        WW, WH = self.WW, self.WH
        base = WH * (0.86 if not self.plan.portrait else 0.75)
        for row in range(3):
            y = base + row * 70
            n = 13 - row
            sw = WW / (n - 0.5)
            for i in range(n):
                x = i * sw - (sw / 2 if row % 2 else 0)
                k.rect(x + 6, y, sw - 12, 140, fill=(14 + row * 4, 14 + row * 4, 17 + row * 4, 255), r=26)
                if row == 0 and i % 3 == 1:
                    k.ellipse(x + sw / 2 - 34, y - 70, 68, 78, fill="#0A0A0C")
                    k.rect(x + sw / 2 - 60, y - 16, 120, 50, fill="#0A0A0C", r=24)

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        v.fill("#050506")
        sx, sy, sw, sh = self.scr
        # the room lit by the picture
        small = ctx.frame.resize((16, 9), Image.BILINEAR)
        glow = small.resize((self.WW // 8, self.WH // 8), Image.BILINEAR).filter(ImageFilter.GaussianBlur(6))
        v.image(glow, -100, -60, self.WW + 200, self.WH + 120, alpha=0.2)
        v.rect(sx - 6, sy - 6, sw + 12, sh + 12, fill="#000000")
        ctx.him(v, sx, sy, sw, sh)
        self.seats.draw(v, 0, 0)
        if self.beat["in"] in ("cut", "rise") and ctx.tl < 0.9:
            v.rect(-200, -200, self.WW + 400, self.WH + 400, fill=(60, 52, 40, int(200 * (1 - out3(ctx.tl / 0.9)))))


class Polaroid(Stage):
    def setup(self):
        WW, WH = self.WW, self.WH
        self.tw, self.th = (640, 760)
        self.photo = (34, 34, 572, 572)
        self.cx = float(self.P.get("x", 0.36 if not self.plan.portrait else 0.5)) * WW
        self.cy = WH * (0.5 if not self.plan.portrait else 0.36)
        self.angle = float(self.P.get("angle", -3.5))
        self.base = Sprite(self.tw, self.th, self._card)

    def _card(self, k):
        k.rect(0, 0, self.tw, self.th, fill="#FFFEFB", r=6)
        px, py, pw, ph = self.photo
        k.rect(px, py, pw, ph, fill="#222222")

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        paper = self.plan.look["page"] if self.plan.look_name == "paper" else "#F1E9DA"
        self.page(v, paper, grid=False)
        # build the card at screen scale, then rotate it
        z = v.z
        tw, th = int(self.tw * z), int(self.th * z)
        card = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
        cv = View(card, self.tw / 2, self.th / 2, z)
        self.base.draw(cv, 0, 0)
        px, py, pw, ph = self.photo
        ctx.him(cv, px, py, pw, ph)
        if self.P.get("caption"):
            cv.text(self.tw / 2, py + ph + 80, self.P["caption"], "hand", 64, "#1E1E1E", "mm")
        for (x, y, ang) in ((40, -18, -8), (self.tw - 170, -14, 7)):
            tape = Image.new("RGBA", (int(150 * z), int(44 * z)), (236, 224, 190, 190))
            tape = tape.rotate(ang, expand=True, resample=Image.BICUBIC)
            card.alpha_composite(tape, (max(0, int(x * z)), max(0, int(y * z))))
        rot = card.rotate(self.angle, expand=True, resample=Image.BICUBIC)
        u = out5(ctx.tl / 0.5) if self.beat["in"] in ("cut",) else 1.0
        sx, sy = v.p(self.cx, self.cy)
        sh = rot.getchannel("A").filter(ImageFilter.GaussianBlur(18 * z)).point(lambda q: int(q * 0.3))
        ox, oy = int(sx - rot.width / 2), int(sy - rot.height / 2 + (1 - u) * 60 * z)
        v.img.paste((0, 0, 0), (ox + int(10 * z), oy + int(22 * z)), sh)
        v.img.paste(rot, (ox, oy), rot.getchannel("A").point(lambda q: int(q * u)))


class Post(Stage):
    def setup(self):
        WW, WH = self.WW, self.WH
        self.cw = 700
        cx = float(self.P.get("x", 0.36 if not self.plan.portrait else 0.5)) * WW
        self.card = (cx - self.cw / 2, (WH - 960) / 2 if not self.plan.portrait else 190, self.cw, 960)
        x, y, w, h = self.card
        self.media = (x, y + 84, w, w)
        self.screen = None
        self.sprite = Sprite(w, h, self._card, shadow=(26, 0.16, 18))

    def _card(self, k):
        w, h = self.card[2], self.card[3]
        k.rect(0, 0, w, h, fill="#FFFFFF", r=22, outline="#E6E6E6", width=1.5)
        k.ellipse(22, 20, 46, 46, fill=self.plan.accent)
        k.text(84, 34, self.P.get("handle", self.plan.handle).lstrip("@"), "bold", 20, "#111111", "lm")
        k.text(84, 58, self.P.get("place", "Original audio"), "body", 15, "#777777", "lm")

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        self.page(v)
        x, y, w, h = self.card
        self.sprite.draw(v, x, y)
        icon(v, "dots", x + w - 56, y + 30, 26, "#111111")
        mx, my, mw, mh = self.media
        ctx.him(v, mx, my, mw, mh)
        P, plan, t = self.P, self.plan, ctx.t
        liked = P.get("like") is not None and t >= plan.T(P["like"])
        ay = my + mh + 18
        icon(v, "heart", x + 22, ay, 36, plan.accent if liked else "#111111", fill=liked)
        icon(v, "comment", x + 76, ay, 36, "#111111")
        icon(v, "share", x + 130, ay, 34, "#111111")
        icon(v, "bookmark", x + w - 58, ay, 36, "#111111")
        lk = P.get("likes", [1200, 48213])
        u = clamp(ctx.tl / max(0.4, ctx.dur * 0.85))
        n = int(lerp(float(lk[0]), float(lk[1]), out5(u))) if isinstance(lk, list) else lk
        v.text(x + 24, ay + 66, f"{n:,} likes" if isinstance(n, int) else str(n), "bold", 20, "#111111", "lm")
        if P.get("caption"):
            hd = P.get("handle", plan.handle).lstrip("@")
            v.text(x + 24, ay + 100, hd, "bold", 18, "#111111", "lm")
            v.text(x + 34 + font("bold", 18).getlength(hd), ay + 100, P["caption"][:48], "body", 18, "#222222", "lm")
        if liked:
            uu = t - plan.T(P["like"])
            if uu < 0.9:
                k = back_out(uu / 0.35, 2.2) if uu < 0.35 else 1.0
                al = 1 - out3((uu - 0.5) / 0.4) if uu > 0.5 else 1
                s_ = 200 * k
                icon(v, "heart", mx + mw / 2 - s_ / 2, my + mh / 2 - s_ / 2, s_, "#FFFFFF", alpha=al)


# ---- takeover / broll -------------------------------------------------------------------------------------------------
class Takeover(Stage):
    def setup(self):
        self.kind = self.P.get("kind", "statement")

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        P, plan, t = self.P, self.plan, ctx.t
        dark = P.get("dark", False)
        if dark:
            v.fill("#0E0F12")
        else:
            self.page(v)
        WW, WH = self.WW, self.WH
        pt = plan.portrait
        k = self.kind
        a0 = plan.T(P.get("at", self.beat["t0"]))
        if k == "statement":
            size = float(P.get("size", 136 if not pt else 116))
            mw = WW * (0.78 if not pt else 0.84)
            bh = text_height(P["text"], P.get("font", "display"), size, mw, int(P.get("lines", 3)))
            if P.get("kicker"):
                u = out5((t - a0) / 0.3)
                v.text(WW / 2, WH / 2 - bh / 2 - 56, P["kicker"].upper(), "monob", 28, plan.accent, "mm",
                       alpha=u, tracking=3)
            draw_rich(v, plan, WW / 2, WH * 0.5, P["text"], t, a0, self.beat["t1"], name=P.get("font", "display"),
                      size=size, max_w=mw, color="#F4F4F2" if dark else None, max_lines=int(P.get("lines", 3)))
            if P.get("sub"):
                sa = plan.T(P.get("sub_at", a0 + 0.6))
                u = out5((t - sa) / 0.35)
                v.text(WW / 2, WH / 2 + bh / 2 + 70, P["sub"], "body", 40, plan.look["muted"], "mm", alpha=u)
        elif k in ("number", "list", "image", "points"):
            c = dict(P)
            c["kind"] = {"list": "points"}.get(k, k)
            if k == "number":
                block(v, ctx, c, 0, WH * 0.1, WW, WH * 0.8, plan)
            elif k in ("list", "points"):
                bw = 1100 if not pt else 900
                block(v, ctx, c, (WW - bw) / 2, WH * (0.18 if not pt else 0.25), bw, WH * 0.7, plan)
            else:
                block(v, ctx, c, WW * 0.08, WH * 0.08, WW * 0.84, WH * 0.8, plan)
        elif k == "compare":
            self._compare(v, ctx, a0)
        elif k == "chapter":
            u = out5((t - a0) / 0.35)
            v.text(WW / 2, WH * 0.4, P.get("num", "01"), "monob", 40, plan.accent, "mm", alpha=u, tracking=4)
            lw = 220 * out3((t - a0 - 0.1) / 0.5)
            v.rect(WW / 2 - lw / 2, WH * 0.45, lw, 4, fill=plan.accent)
            draw_rich(v, plan, WW / 2, WH * 0.56, P.get("title", ""), t, a0 + 0.12, a0 + 1.2, name="display",
                      size=110 if not pt else 96, max_w=WW * 0.8, underline=False)
        if P.get("pip"):
            d = 250
            cx, cy = (WW - d / 2 - 70, WH - d / 2 - 70) if not pt else (WW / 2, WH - d / 2 - 300)
            u = back_out((ctx.tl - 0.2) / 0.45, 1.3)
            if u > 0:
                dd = d * u
                v.shadow(cx - dd / 2, cy - dd / 2, dd, dd, r=dd / 2, blur=20, alpha=0.25, dy=10)
                v.circle(cx, cy, dd / 2 + 6, fill="#FFFFFF")
                ctx.him(v, cx - dd / 2, cy - dd / 2, dd, dd, r=dd / 2, force_him=True)

    def _compare(self, v, ctx, a0):
        P, plan, t = self.P, self.plan, ctx.t
        WW, WH = self.WW, self.WH
        pt = plan.portrait
        sides = [P.get("left", {}), P.get("right", {})]
        for i, sd in enumerate(sides):
            n_items = max(1, len(sd.get("items", [])))
            if pt:
                h = 210 + n_items * 110
                x, y, w = 90, 300 + i * (h + 70), WW - 180
            else:
                x, y, w, h = 150 + i * (WW / 2 - 90), 170, WW / 2 - 240, 740
            sa = plan.T(sd.get("at", a0 + i * 0.6))
            u = out5((t - sa) / 0.4)
            if u <= 0:
                continue
            good = sd.get("good", i == 1)
            v.shadow(x, y + (1 - u) * 30, w, h, r=28, blur=26, alpha=0.12 * u, dy=16)
            v.rect(x, y + (1 - u) * 30, w, h, fill=plan.look["card"], r=28, outline=plan.look["hair"], width=1.5,
                   alpha=u)
            v.text(x + 50, y + 80 + (1 - u) * 30, sd.get("title", ""), "display", 64,
                   plan.accent if good else plan.look["muted"], "lm", alpha=u)
            for j, it in enumerate(sd.get("items", [])):
                txt, at = (it, None) if isinstance(it, str) else (it[0], it[1] if len(it) > 1 else None)
                ti = plan.T(at) if at is not None else sa + 0.3 * (j + 1)
                uu = out5((t - ti) / 0.3)
                if uu <= 0:
                    continue
                iy = y + 190 + j * 110 + (1 - uu) * 16
                col = "#22A35A" if good else "#D2463C"
                v.circle(x + 70, iy, 24, fill=rgba(col, 0.14), alpha=uu)
                icon(v, "check" if good else "cross", x + 54, iy - 16, 32, col, alpha=uu)
                v.text(x + 116, iy, txt, "bold", 40, plan.look["ink"], "lm", alpha=uu)


class Broll(Stage):
    def setup(self):
        self.screen = (0, 0, self.WW, self.WH)

    def base_cam(self, ctx):
        return self.WW / 2, self.WH / 2, 1.0 + 0.04 * smooth(ctx.tl / max(0.01, ctx.dur))

    def draw(self, img, ctx):
        v = self.view(img, ctx)
        v.fill("#000000")
        ctx.him(v, 0, 0, self.WW, self.WH)
        if self.P.get("label"):
            u = out5((ctx.tl - 0.2) / 0.35)
            v.text(60, self.WH - 70, self.P["label"].upper(), "monob", 24, "#FFFFFF", "lm", alpha=u * 0.9,
                   stroke=2, stroke_fill=(0, 0, 0, 160))


STAGE_CLASSES = dict(full=Full, beside=Beside, editor=Editor, phone=Phone, tv=TV, laptop=Laptop, browser=Browser,
                     call=Call, cinema=Cinema, polaroid=Polaroid, post=Post, takeover=Takeover, broll=Broll)
