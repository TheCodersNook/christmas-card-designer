"""Static artwork drawn once and supersampled: device bodies, UI chrome, icons.

K wraps an ImageDraw at scale k so sprite code is written in world px. A Sprite keeps a 2x copy (sharp when the camera
pushes in) and a 1x copy (pasted directly when the camera is at rest).
"""
from __future__ import annotations

import functools
import math

from PIL import Image, ImageDraw, ImageFilter

from .core import View, font, rgba


class K:
    def __init__(self, d: ImageDraw.ImageDraw, k: float, im=None):
        self.d, self.k, self.im = d, k, im

    def paste(self, src, x, y, w, h, r=0):
        """Paste an image (a thumbnail, a logo) into the sprite at world box (x, y, w, h)."""
        k = self.k
        piece = src.convert("RGBA").resize((max(1, int(w * k)), max(1, int(h * k))), Image.LANCZOS)
        m = piece.getchannel("A")
        if r:
            rm = Image.new("L", piece.size, 0)
            ImageDraw.Draw(rm).rounded_rectangle((0, 0, piece.width - 1, piece.height - 1), r * k, fill=255)
            from PIL import ImageChops
            m = ImageChops.multiply(m, rm)
        self.im.paste(piece, (int(x * k), int(y * k)), m)

    def rect(self, x, y, w, h, fill=None, r=0, outline=None, width=1, alpha=1.0):
        k = self.k
        b = (x * k, y * k, (x + w) * k, (y + h) * k)
        self.d.rounded_rectangle(b, r * k, fill=rgba(fill, alpha) if fill else None,
                                 outline=rgba(outline, alpha) if outline else None, width=max(1, int(width * k)))

    def ellipse(self, x, y, w, h, fill=None, outline=None, width=1, alpha=1.0):
        k = self.k
        self.d.ellipse((x * k, y * k, (x + w) * k, (y + h) * k), fill=rgba(fill, alpha) if fill else None,
                       outline=rgba(outline, alpha) if outline else None, width=max(1, int(width * k)))

    def poly(self, pts, fill=None, outline=None, width=1, alpha=1.0):
        k = self.k
        self.d.polygon([(x * k, y * k) for x, y in pts], fill=rgba(fill, alpha) if fill else None,
                       outline=rgba(outline, alpha) if outline else None, width=max(1, int(width * k)))

    def line(self, pts, fill, width=2, alpha=1.0):
        k = self.k
        self.d.line([(x * k, y * k) for x, y in pts], fill=rgba(fill, alpha), width=max(1, int(width * k)),
                    joint="curve")

    def text(self, x, y, s, name="bold", size=20, fill="#111", anchor="la", alpha=1.0):
        self.d.text((x * self.k, y * self.k), s, font=font(name, size * self.k), fill=rgba(fill, alpha), anchor=anchor)

    def arc(self, x, y, w, h, a0, a1, fill, width=2):
        k = self.k
        self.d.arc((x * k, y * k, (x + w) * k, (y + h) * k), a0, a1, fill=rgba(fill), width=max(1, int(width * k)))


class Sprite:
    def __init__(self, w, h, fn, ss=2, shadow=None):
        """fn(K) draws in world px inside (0, 0, w, h). shadow = (blur, alpha, dy) adds a soft drop shadow under the
        art's own alpha (the sprite grows by a margin; x, y still address the art's top-left)."""
        self.w, self.h, self.ss = w, h, ss
        self.m = 0
        if shadow:
            blur, alpha, dy = shadow
            self.m = int(blur * 3 + abs(dy))
        W, H = w + 2 * self.m, h + 2 * self.m
        k = ss * 2
        art = Image.new("RGBA", (int(W * k), int(H * k)), (0, 0, 0, 0))
        kk = K(ImageDraw.Draw(art), k, art)
        if self.m:
            # draw into an offset canvas
            inner = Image.new("RGBA", (int(w * k), int(h * k)), (0, 0, 0, 0))
            fn(K(ImageDraw.Draw(inner), k, inner))
            a = inner.getchannel("A").point(lambda v, al=shadow[1]: int(v * al))
            sh = Image.new("RGBA", art.size, (0, 0, 0, 0))
            blk = Image.new("RGBA", inner.size, (0, 0, 0, 255))
            sh.paste(blk, (int(self.m * k), int((self.m + shadow[2]) * k)), a)
            sh = sh.filter(ImageFilter.GaussianBlur(shadow[0] * k / 2))
            art = Image.alpha_composite(sh, Image.new("RGBA", art.size, (0, 0, 0, 0)))
            art.alpha_composite(inner, (int(self.m * k), int(self.m * k)))
        else:
            fn(kk)
        self.hi = art.resize((int(W * ss), int(H * ss)), Image.LANCZOS)
        self.lo = art.resize((int(W), int(H)), Image.LANCZOS)

    def draw(self, v: View, x, y, alpha=1.0, scale=1.0):
        """Top-left of the art at world (x, y); scale about the art's centre."""
        m = self.m
        if scale != 1.0:
            cx, cy = x + self.w / 2, y + self.h / 2
            w, h = (self.w + 2 * m) * scale, (self.h + 2 * m) * scale
            x0, y0 = cx - w / 2, cy - h / 2
        else:
            x0, y0, w, h = x - m, y - m, self.w + 2 * m, self.h + 2 * m
        b = v.box(x0, y0, w, h)
        if abs(b[2] - b[0] - self.lo.width) < 0.01 and abs(b[0] - round(b[0])) < 0.01 and abs(b[1] - round(b[1])) < 0.01:
            if alpha >= 0.997:
                v.img.paste(self.lo, (int(round(b[0])), int(round(b[1]))), self.lo)
            else:
                a = self.lo.getchannel("A").point(lambda q, al=alpha: int(q * al))
                v.img.paste(self.lo, (int(round(b[0])), int(round(b[1]))), a)
            return
        src = self.hi if (b[2] - b[0]) > self.lo.width * 1.02 else self.lo
        v.place(src, b, alpha=alpha)


# ---- icons (unit box 0..1, drawn by K at size s) --------------------------------------------------------------------
def _heart(k: K, s, c, fill=True, width=0.09):
    pts = []
    for i in range(64):
        t = 2 * math.pi * i / 64
        x = 16 * math.sin(t) ** 3
        y = 13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t)
        pts.append((s * (0.5 + x / 36), s * (0.47 - y / 36)))
    if fill:
        k.poly(pts, fill=c)
    else:
        k.line(pts + [pts[0]], c, width=s * width)


def _comment(k, s, c, fill=False):
    k.ellipse(s * 0.08, s * 0.1, s * 0.84, s * 0.72, outline=c, width=s * 0.09)
    k.poly([(s * 0.22, s * 0.7), (s * 0.12, s * 0.95), (s * 0.42, s * 0.79)], fill=c)


def _share(k, s, c, fill=False):
    k.line([(s * 0.08, s * 0.45), (s * 0.92, s * 0.1), (s * 0.62, s * 0.92), (s * 0.45, s * 0.58), (s * 0.08, s * 0.45)],
           c, width=s * 0.085)
    k.line([(s * 0.45, s * 0.58), (s * 0.92, s * 0.1)], c, width=s * 0.07)


def _bookmark(k, s, c, fill=False):
    k.line([(s * 0.22, s * 0.08), (s * 0.78, s * 0.08), (s * 0.78, s * 0.92), (s * 0.5, s * 0.7), (s * 0.22, s * 0.92),
            (s * 0.22, s * 0.08)], c, width=s * 0.085)


def _dots(k, s, c, fill=True):
    for i in range(3):
        k.ellipse(s * (0.12 + i * 0.3), s * 0.42, s * 0.16, s * 0.16, fill=c)


def _vdots(k, s, c, fill=True):
    for i in range(3):
        k.ellipse(s * 0.42, s * (0.12 + i * 0.3), s * 0.16, s * 0.16, fill=c)


def _play(k, s, c, fill=True):
    k.poly([(s * 0.22, s * 0.1), (s * 0.88, s * 0.5), (s * 0.22, s * 0.9)], fill=c)


def _pause(k, s, c, fill=True):
    k.rect(s * 0.2, s * 0.12, s * 0.2, s * 0.76, fill=c, r=s * 0.03)
    k.rect(s * 0.6, s * 0.12, s * 0.2, s * 0.76, fill=c, r=s * 0.03)


def _razor(k, s, c, fill=True):
    k.poly([(s * 0.18, s * 0.08), (s * 0.82, s * 0.08), (s * 0.82, s * 0.52), (s * 0.5, s * 0.92), (s * 0.18, s * 0.52)],
           outline=c, width=s * 0.08)
    k.line([(s * 0.5, s * 0.22), (s * 0.5, s * 0.62)], c, width=s * 0.08)


def _cursor(k, s, c="#FFFFFF", fill=True):
    pts = [(0.05, 0.02), (0.05, 0.82), (0.26, 0.64), (0.42, 0.98), (0.56, 0.92), (0.4, 0.58), (0.68, 0.58)]
    k.poly([(s * x, s * y) for x, y in pts], fill=c, outline="#111111", width=s * 0.05)


def _hand(k, s, c, fill=False):
    k.rect(s * 0.22, s * 0.3, s * 0.56, s * 0.62, outline=c, width=s * 0.08, r=s * 0.2)
    for i in range(4):
        k.line([(s * (0.3 + i * 0.13), s * 0.32), (s * (0.3 + i * 0.13), s * 0.08)], c, width=s * 0.08)


def _mic(k, s, c, fill=False):
    k.rect(s * 0.36, s * 0.06, s * 0.28, s * 0.52, outline=c, width=s * 0.08, r=s * 0.14)
    k.arc(s * 0.2, s * 0.22, s * 0.6, s * 0.52, 0, 180, c, width=s * 0.08)
    k.line([(s * 0.5, s * 0.74), (s * 0.5, s * 0.92)], c, width=s * 0.08)


def _cam(k, s, c, fill=False):
    k.rect(s * 0.06, s * 0.26, s * 0.6, s * 0.48, outline=c, width=s * 0.08, r=s * 0.08)
    k.poly([(s * 0.7, s * 0.42), (s * 0.94, s * 0.28), (s * 0.94, s * 0.72), (s * 0.7, s * 0.58)], fill=c)


def _hangup(k, s, c, fill=True):
    k.rect(s * 0.08, s * 0.38, s * 0.84, s * 0.26, fill=c, r=s * 0.13)


def _lock(k, s, c, fill=True):
    k.arc(s * 0.27, s * 0.06, s * 0.46, s * 0.56, 180, 360, c, width=s * 0.09)
    k.line([(s * 0.27, s * 0.33), (s * 0.27, s * 0.45)], c, width=s * 0.09)
    k.line([(s * 0.73, s * 0.33), (s * 0.73, s * 0.45)], c, width=s * 0.09)
    k.rect(s * 0.16, s * 0.44, s * 0.68, s * 0.5, fill=c, r=s * 0.08)


def _check(k, s, c, fill=True):
    k.line([(s * 0.14, s * 0.52), (s * 0.4, s * 0.78), (s * 0.88, s * 0.24)], c, width=s * 0.14)


def _cross(k, s, c, fill=True):
    k.line([(s * 0.2, s * 0.2), (s * 0.8, s * 0.8)], c, width=s * 0.14)
    k.line([(s * 0.8, s * 0.2), (s * 0.2, s * 0.8)], c, width=s * 0.14)


def _note(k, s, c, fill=True):
    k.ellipse(s * 0.1, s * 0.62, s * 0.32, s * 0.28, fill=c)
    k.line([(s * 0.4, s * 0.76), (s * 0.4, s * 0.1), (s * 0.85, s * 0.22)], c, width=s * 0.09)


def _search(k, s, c, fill=False):
    k.ellipse(s * 0.1, s * 0.1, s * 0.56, s * 0.56, outline=c, width=s * 0.09)
    k.line([(s * 0.6, s * 0.6), (s * 0.9, s * 0.9)], c, width=s * 0.11)


def _plus(k, s, c, fill=True):
    k.line([(s * 0.5, s * 0.14), (s * 0.5, s * 0.86)], c, width=s * 0.12)
    k.line([(s * 0.14, s * 0.5), (s * 0.86, s * 0.5)], c, width=s * 0.12)


def _camera_outline(k, s, c, fill=False):
    k.rect(s * 0.08, s * 0.24, s * 0.84, s * 0.62, outline=c, width=s * 0.08, r=s * 0.14)
    k.ellipse(s * 0.32, s * 0.36, s * 0.36, s * 0.36, outline=c, width=s * 0.08)


ICONS = dict(heart=_heart, comment=_comment, share=_share, bookmark=_bookmark, dots=_dots, vdots=_vdots, play=_play,
             pause=_pause, razor=_razor, cursor=_cursor, hand=_hand, mic=_mic, cam=_cam, hangup=_hangup, lock=_lock,
             check=_check, cross=_cross, note=_note, search=_search, plus=_plus, camera=_camera_outline)


@functools.lru_cache(maxsize=256)
def icon_sprite(name, size, color, fill=True):
    def fn(k):
        f = ICONS[name]
        try:
            f(k, size, color, fill)
        except TypeError:
            f(k, size, color)
    return Sprite(size, size, fn, ss=2)


def icon(v: View, name, x, y, size, color="#FFFFFF", alpha=1.0, scale=1.0, fill=True):
    """Draw an icon with its top-left at world (x, y)."""
    icon_sprite(name, int(round(size)), color if isinstance(color, str) else "#%02x%02x%02x" % tuple(color[:3]),
                fill).draw(v, x, y, alpha=alpha, scale=scale)
