"""Drawing core: fonts, easing, colours and the View (a camera from world px to screen px).

Every stage draws in world px (the output size: 1920x1080 or 1080x1920). The View maps world to screen through a camera
(centre cx, cy and zoom z), so a stage can push, pull, reveal and dive and stay sharp: shapes and text are drawn at
screen scale, and images (his video, sprites, screenshots) are resampled once, with sub-pixel placement.
"""
from __future__ import annotations

import functools
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parents[2]
FONTS = ROOT / "assets" / "fonts"
FONT = {"body": "Inter-500.ttf", "bold": "Inter-700.ttf", "heavy": "Inter-800.ttf",
        "display": "SchibstedGrotesk-900.ttf", "display8": "SchibstedGrotesk-800.ttf",
        "mono": "JetBrainsMono-500.ttf", "monob": "JetBrainsMono-700.ttf", "hand": "Caveat-700.ttf",
        "poster": "Anton-400.ttf", "serif": "InstrumentSerif-Italic.ttf"}


@functools.lru_cache(maxsize=2048)
def font(name: str, size: float) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(FONTS / FONT.get(name, name)), max(1.0, round(size * 4) / 4))


# ---- easing (all clamp to 0..1) -------------------------------------------------------------------------------------
def clamp(x, a=0.0, b=1.0):
    return a if x < a else b if x > b else x


def lerp(a, b, u):
    return a + (b - a) * u


def smooth(x):
    x = clamp(x)
    return x * x * (3 - 2 * x)


def out3(x):
    x = clamp(x)
    return 1 - (1 - x) ** 3


def out5(x):
    x = clamp(x)
    return 1 - (1 - x) ** 5


def in3(x):
    return clamp(x) ** 3


def inout3(x):
    x = clamp(x)
    return 4 * x ** 3 if x < 0.5 else 1 - (-2 * x + 2) ** 3 / 2


def expo_out(x):
    x = clamp(x)
    return 1.0 if x >= 1 else 1 - 2 ** (-10 * x)


def expo_in(x):
    x = clamp(x)
    return 0.0 if x <= 0 else 2 ** (10 * x - 10)


def expo_inout(x):
    x = clamp(x)
    if x <= 0 or x >= 1:
        return x
    return 2 ** (20 * x - 10) / 2 if x < 0.5 else (2 - 2 ** (-20 * x + 10)) / 2


def back_out(x, s=1.5):
    x = clamp(x) - 1
    return 1 + (s + 1) * x ** 3 + s * x ** 2


def win(t, a, b):
    """0..1 progress of t through [a, b]."""
    return clamp((t - a) / (b - a)) if b > a else float(t >= a)


# ---- colour ---------------------------------------------------------------------------------------------------------
@functools.lru_cache(maxsize=256)
def rgb(c) -> tuple:
    if isinstance(c, (tuple, list)):
        v = tuple(int(x) for x in c)
        return v if len(v) == 4 else v + (255,)
    c = c.lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    v = tuple(int(c[i:i + 2], 16) for i in range(0, len(c), 2))
    return v if len(v) == 4 else v + (255,)


def rgba(c, a=1.0):
    r = rgb(c)
    return (r[0], r[1], r[2], int(round(r[3] * clamp(a))))


def mix(c1, c2, u):
    a, b = rgb(c1), rgb(c2)
    return tuple(int(round(lerp(a[i], b[i], clamp(u)))) for i in range(4))


# ---- masks ----------------------------------------------------------------------------------------------------------
@functools.lru_cache(maxsize=96)
def _rr_mask(w, h, ox8, oy8, fw8, fh8, r8):
    """Anti-aliased rounded-rect coverage (from its signed distance) on a w x h canvas; the rect sits at (ox, oy) with
    size (fw, fh) and radius r, all in 1/8 px."""
    ox, oy, fw, fh, r = ox8 / 8, oy8 / 8, fw8 / 8, fh8 / 8, r8 / 8
    r = max(0.0, min(r, fw / 2, fh / 2))
    hx, hy = fw / 2, fh / 2
    px = np.abs(np.arange(w, dtype=np.float32) + 0.5 - ox - hx)[None, :]
    py = np.abs(np.arange(h, dtype=np.float32) + 0.5 - oy - hy)[:, None]
    qx, qy = px - (hx - r), py - (hy - r)
    d = np.hypot(np.maximum(qx, 0), np.maximum(qy, 0)) + np.minimum(np.maximum(qx, qy), 0) - r
    return Image.fromarray((np.clip(0.5 - d, 0, 1) * 255).astype(np.uint8), "L")


def rr_mask(w, h, ox, oy, fw, fh, r):
    q = lambda v: int(round(v * 8))
    return _rr_mask(int(w), int(h), q(ox), q(oy), q(fw), q(fh), q(r))


@functools.lru_cache(maxsize=64)
def _shadow(w, h, r, blur, alpha):
    pad = blur * 3
    m = Image.new("L", (w + 2 * pad, h + 2 * pad), 0)
    ImageDraw.Draw(m).rounded_rectangle((pad, pad, pad + w, pad + h), r, fill=int(255 * alpha))
    return m.filter(ImageFilter.GaussianBlur(blur)), pad


class View:
    """A camera over the world: screen = (world - (cx, cy)) * z + (W/2, H/2)."""

    def __init__(self, img: Image.Image, cx=None, cy=None, z=1.0):
        self.img = img
        self.W, self.H = img.size
        self.cx = self.W / 2 if cx is None else cx
        self.cy = self.H / 2 if cy is None else cy
        self.z = z
        self.d = ImageDraw.Draw(img, "RGBA")

    # mapping
    def p(self, x, y):
        return ((x - self.cx) * self.z + self.W / 2, (y - self.cy) * self.z + self.H / 2)

    def box(self, x, y, w, h):
        x0, y0 = self.p(x, y)
        return (x0, y0, x0 + w * self.z, y0 + h * self.z)

    def visible(self, b):
        return b[2] > 0 and b[3] > 0 and b[0] < self.W and b[1] < self.H

    # shapes
    def fill(self, color):
        self.d.rectangle((0, 0, self.W, self.H), fill=rgba(color))

    def rect(self, x, y, w, h, fill=None, r=0, outline=None, width=1.0, alpha=1.0):
        b = self.box(x, y, w, h)
        if not self.visible(b):
            return
        rz, wz = r * self.z, max(1.0, width * self.z)
        if rz < 1.5:
            if fill is not None:
                self.d.rectangle(b, fill=rgba(fill, alpha))
            if outline is not None:
                self.d.rectangle(b, outline=rgba(outline, alpha), width=int(round(wz)))
            return
        if fill is not None:
            self._paste_rr(b, rz, rgba(fill, alpha))
        if outline is not None:
            self._ring_rr(b, rz, wz, rgba(outline, alpha))

    def _paste_rr(self, b, rz, color):
        x0, y0 = max(0, math.floor(b[0])), max(0, math.floor(b[1]))
        x1, y1 = min(self.W, math.ceil(b[2])), min(self.H, math.ceil(b[3]))
        if x1 <= x0 or y1 <= y0:
            return
        m = rr_mask(x1 - x0, y1 - y0, b[0] - x0, b[1] - y0, b[2] - b[0], b[3] - b[1], rz)
        if color[3] < 255:
            m = m.point(lambda v, a=color[3]: v * a // 255)
        self.img.paste(color[:3], (x0, y0, x1, y1), m)

    def _ring_rr(self, b, rz, wz, color):
        x0, y0 = max(0, math.floor(b[0])), max(0, math.floor(b[1]))
        x1, y1 = min(self.W, math.ceil(b[2])), min(self.H, math.ceil(b[3]))
        if x1 <= x0 or y1 <= y0:
            return
        outer = np.asarray(rr_mask(x1 - x0, y1 - y0, b[0] - x0, b[1] - y0, b[2] - b[0], b[3] - b[1], rz), np.int16)
        inner = np.asarray(rr_mask(x1 - x0, y1 - y0, b[0] - x0 + wz, b[1] - y0 + wz, b[2] - b[0] - 2 * wz,
                                   b[3] - b[1] - 2 * wz, max(0, rz - wz)), np.int16)
        m = np.clip(outer - inner, 0, 255) * color[3] // 255
        self.img.paste(color[:3], (x0, y0, x1, y1), Image.fromarray(m.astype(np.uint8), "L"))

    def circle(self, x, y, rad, fill=None, outline=None, width=1.0, alpha=1.0):
        self.rect(x - rad, y - rad, 2 * rad, 2 * rad, fill=fill, r=rad, outline=outline, width=width, alpha=alpha)

    def shadow(self, x, y, w, h, r=24, blur=28, alpha=0.16, dy=18, color=(0, 0, 0)):
        b = self.box(x, y + dy, w, h)
        if not self.visible((b[0] - 200, b[1] - 200, b[2] + 200, b[3] + 200)):
            return
        bw, bh = max(2, int(round(b[2] - b[0]))), max(2, int(round(b[3] - b[1])))
        m, pad = _shadow(bw, bh, max(0, int(r * self.z)), max(2, int(blur * self.z)), round(alpha, 3))
        self.img.paste(color, (int(round(b[0])) - pad, int(round(b[1])) - pad), m)

    def line(self, pts, fill, width=2.0, alpha=1.0):
        sp = [self.p(x, y) for x, y in pts]
        self.d.line(sp, fill=rgba(fill, alpha), width=max(1, int(round(width * self.z))), joint="curve")

    def poly(self, pts, fill, alpha=1.0):
        self.d.polygon([self.p(x, y) for x, y in pts], fill=rgba(fill, alpha))

    # text
    def text(self, x, y, s, name="bold", size=40, fill="#111111", anchor="la", alpha=1.0, stroke=0, stroke_fill=None,
             tracking=0.0):
        if alpha <= 0.003 or not s:
            return
        f = font(name, size * self.z)
        px, py = self.p(x, y)
        kw = dict(font=f, fill=rgba(fill, alpha), anchor=anchor)
        if stroke:
            kw.update(stroke_width=max(1, int(round(stroke * self.z))), stroke_fill=rgba(stroke_fill or "#000", alpha))
        if tracking:
            self._tracked(px, py, s, f, tracking * self.z, kw)
        else:
            self.d.text((px, py), s, **kw)

    def _tracked(self, px, py, s, f, tr, kw):
        widths = [f.getlength(ch) + tr for ch in s]
        total = sum(widths) - tr
        a = kw.pop("anchor", "la")
        x = px - (total / 2 if a[0] == "m" else total if a[0] == "r" else 0)
        for ch, w in zip(s, widths):
            self.d.text((x, py), ch, anchor="l" + a[1], **kw)
            x += w

    def measure(self, s, name="bold", size=40):
        """Width in world px."""
        return font(name, size).getlength(s)

    # images
    def place(self, src: Image.Image, dst, sbox=None, r=0.0, alpha=1.0, resample=Image.BICUBIC):
        """Resample src (or its sbox region) into the float screen box dst with a rounded mask of radius r (screen px)."""
        X0, Y0, X1, Y1 = dst
        if X1 - X0 < 1 or Y1 - Y0 < 1 or alpha <= 0.003:
            return
        sw, sh = src.size
        sb = sbox or (0, 0, sw, sh)
        sx, sy = (sb[2] - sb[0]) / (X1 - X0), (sb[3] - sb[1]) / (Y1 - Y0)
        ix0, iy0 = max(0, math.floor(X0)), max(0, math.floor(Y0))
        ix1, iy1 = min(self.W, math.ceil(X1)), min(self.H, math.ceil(Y1))
        if ix1 <= ix0 or iy1 <= iy0:
            return
        bx0, by0 = sb[0] + (ix0 - X0) * sx, sb[1] + (iy0 - Y0) * sy
        bx1, by1 = sb[0] + (ix1 - X0) * sx, sb[1] + (iy1 - Y0) * sy
        # keep the box inside the source: trim whole screen pixels that would sample outside it
        while bx0 < -0.01 and ix0 < ix1 - 1:
            ix0 += 1; bx0 += sx
        while by0 < -0.01 and iy0 < iy1 - 1:
            iy0 += 1; by0 += sy
        while bx1 > sw + 0.01 and ix1 > ix0 + 1:
            ix1 -= 1; bx1 -= sx
        while by1 > sh + 0.01 and iy1 > iy0 + 1:
            iy1 -= 1; by1 -= sy
        box = (max(0.0, bx0), max(0.0, by0), min(float(sw), bx1), min(float(sh), by1))
        piece = src.resize((ix1 - ix0, iy1 - iy0), resample, box=box)
        mask = None
        if piece.mode == "RGBA":
            mask = piece.getchannel("A")
            piece = piece.convert("RGB")
        if r > 0.5:
            rm = rr_mask(ix1 - ix0, iy1 - iy0, X0 - ix0, Y0 - iy0, X1 - X0, Y1 - Y0, r)
            mask = rm if mask is None else Image.fromarray(
                (np.asarray(mask, np.uint16) * np.asarray(rm, np.uint16) // 255).astype(np.uint8), "L")
        if alpha < 0.997:
            base = mask if mask is not None else Image.new("L", piece.size, 255)
            mask = base.point(lambda v, a=alpha: int(v * a))
        self.img.paste(piece, (ix0, iy0), mask)

    def image(self, src, x, y, w, h, sbox=None, r=0.0, alpha=1.0):
        self.place(src, self.box(x, y, w, h), sbox, r * self.z, alpha)


def wrap(s, name, size, max_w):
    """Greedy word wrap in world px; keeps *accent* markers attached to their words."""
    words, lines, cur = s.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if cur and font(name, size).getlength(t.replace("*", "")) > max_w:
            lines.append(cur)
            cur = w
        else:
            cur = t
    if cur:
        lines.append(cur)
    return lines


def fit_size(lines_text, name, size, max_w, max_lines=3, min_size=40):
    """The largest size <= size at which s wraps into max_lines within max_w."""
    while size > min_size:
        if len(wrap(lines_text, name, size, max_w)) <= max_lines:
            return size
        size *= 0.92
    return min_size


def sprite(w, h, draw_fn, ss=2):
    """An RGBA sprite of world size (w, h) drawn at ss x scale (with 2x supersampling for clean curves)."""
    k = ss * 2
    img = Image.new("RGBA", (int(w * k), int(h * k)), (0, 0, 0, 0))
    draw_fn(ImageDraw.Draw(img), k)
    return img.resize((int(w * ss), int(h * ss)), Image.LANCZOS)
