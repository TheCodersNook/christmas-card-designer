"""The sound: his voice cut on the frame grid, synthesized SFX (no licences needed), a music bed that ducks under his
voice and lifts in his pauses, and a two-pass loudness master (-14 LUFS, -1.5 dBTP).
"""
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

import numpy as np

from .media import ffmpeg, load_audio, write_wav

SR = 48000


def voice(plan) -> np.ndarray:
    """His voice on the output timeline: every segment cut on the frame grid with 6 ms fades at each edge."""
    cache = {}
    parts = []
    fade = int(0.006 * SR)
    ramp = np.linspace(0, 1, fade, dtype=np.float32)[:, None]
    for s in plan.segs:
        if s["src"] not in cache:
            cache[s["src"]] = load_audio(plan.sources[s["src"]], SR)
        a = cache[s["src"]]
        n_out = int(round(s["n"] / plan.fps * SR))
        n_src = int(round(n_out * plan.speed))
        i0 = int(round(s["a"] * SR))
        seg = a[i0:i0 + n_src]
        if len(seg) < n_src:
            seg = np.concatenate([seg, np.zeros((n_src - len(seg), 2), np.float32)])
        seg = seg.copy()
        if len(seg) > 2 * fade:
            seg[:fade] *= ramp
            seg[-fade:] *= ramp[::-1]
        parts.append((seg, n_out))
    if abs(plan.speed - 1) < 1e-6:
        return np.concatenate([p for p, _ in parts]) if parts else np.zeros((0, 2), np.float32)
    # a tempo change keeps his pitch: ffmpeg atempo on the joined voice, then fit to the frame count
    raw = np.concatenate([p for p, _ in parts])
    tmp = plan.work / "voice_raw.wav"
    write_wav(tmp, raw, SR)
    r = subprocess.run([ffmpeg(), "-v", "error", "-i", str(tmp), "-af", f"atempo={plan.speed}", "-f", "f32le", "-ac",
                        "2", "-ar", str(SR), "-"], capture_output=True)
    out = np.frombuffer(r.stdout, np.float32).reshape(-1, 2).copy()
    need = sum(n for _, n in parts)
    if len(out) < need:
        out = np.concatenate([out, np.zeros((need - len(out), 2), np.float32)])
    return out[:need]


def frame_env(a: np.ndarray, fps, nframes) -> np.ndarray:
    """0..1 loudness per output frame (for waveforms, the active-speaker ring and ducking)."""
    mono = np.abs(a.mean(axis=1)) if len(a) else np.zeros(1)
    hop = SR / fps
    out = np.zeros(nframes, np.float32)
    for f in range(nframes):
        seg = mono[int(f * hop):int((f + 1) * hop)]
        out[f] = np.sqrt((seg ** 2).mean()) if len(seg) else 0
    db = 20 * np.log10(out + 1e-6)
    lo, hi = np.percentile(db, 8), np.percentile(db, 97)
    return np.clip((db - lo) / max(1e-3, hi - lo), 0, 1)


# ---- synthesized SFX ------------------------------------------------------------------------------------------------
def _rng(seed):
    return np.random.default_rng(seed)


def _bandsweep(noise, f0, f1, q=1.2):
    """Noise through a band-pass whose centre sweeps f0 -> f1 (FFT blocks with overlap-add)."""
    n = len(noise)
    blk = 1024
    hop = blk // 2
    win = np.hanning(blk)
    out = np.zeros(n + blk)
    freqs = np.fft.rfftfreq(blk, 1 / SR)
    nb = max(1, (n - blk) // hop + 1)
    for b in range(nb + 1):
        i = b * hop
        x = noise[i:i + blk]
        if len(x) < blk:
            x = np.pad(x, (0, blk - len(x)))
        u = min(1.0, i / max(1, n))
        fc = f0 * (f1 / f0) ** u
        bw = fc / q
        g = np.exp(-0.5 * ((freqs - fc) / bw) ** 2)
        X = np.fft.rfft(x * win) * g
        out[i:i + blk] += np.fft.irfft(X, blk)
    return out[:n]


def sfx_whoosh(d=0.42, f0=500, f1=3200, seed=1, peak=0.62):
    n = int(d * SR)
    x = _bandsweep(_rng(seed).standard_normal(n), f0, f1, q=1.0)
    t = np.linspace(0, 1, n)
    env = np.sin(np.pi * np.clip(t / peak, 0, 1) * 0.5) ** 2 * np.where(t < peak, 1, np.exp(-(t - peak) * 9))
    y = x * env
    return y / (np.abs(y).max() + 1e-9)


def sfx_hit(d=0.6, seed=2):
    n = int(d * SR)
    t = np.arange(n) / SR
    f = 46 + 70 * np.exp(-t * 28)
    ph = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(ph) * np.exp(-t * 6.5)
    click = _rng(seed).standard_normal(n) * np.exp(-t * 90) * 0.35
    y = body + _bandsweep(click, 2500, 1800, q=0.8)
    return y / (np.abs(y).max() + 1e-9)


def sfx_pop(d=0.11, seed=3):
    n = int(d * SR)
    t = np.arange(n) / SR
    f = 1250 * np.exp(-t * 9) + 520
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 38)
    y[: int(0.002 * SR)] *= np.linspace(0, 1, int(0.002 * SR))
    return y / (np.abs(y).max() + 1e-9)


def sfx_click(d=0.035, seed=4):
    n = int(d * SR)
    t = np.arange(n) / SR
    y = _rng(seed).standard_normal(n) * np.exp(-t * 400) + np.sin(2 * np.pi * 3100 * t) * np.exp(-t * 220) * 0.6
    return y / (np.abs(y).max() + 1e-9)


def sfx_static(d=0.3, seed=5):
    n = int(d * SR)
    x = _bandsweep(_rng(seed).standard_normal(n), 2600, 2200, q=0.5)
    crackle = (_rng(seed + 1).random(n) > 0.997) * _rng(seed + 2).standard_normal(n) * 3
    t = np.linspace(0, 1, n)
    y = (x + crackle) * (np.minimum(1, t * 30)) * np.minimum(1, (1 - t) * 8)
    return y / (np.abs(y).max() + 1e-9)


def sfx_tick(d=0.03, seed=6):
    n = int(d * SR)
    t = np.arange(n) / SR
    y = np.sin(2 * np.pi * 2200 * t) * np.exp(-t * 300)
    return y / (np.abs(y).max() + 1e-9)


SFX = dict(whoosh=lambda: sfx_whoosh(), whoosh_deep=lambda: sfx_whoosh(0.5, 260, 1400, seed=7),
           swish=lambda: sfx_whoosh(0.3, 900, 4200, seed=8, peak=0.5), hit=sfx_hit, pop=sfx_pop, click=sfx_click,
           static=sfx_static, tick=sfx_tick)
# level under his voice (dB relative to the voice's speech level), and where the sound's attack sits (s)
LEVEL = dict(whoosh=-17, whoosh_deep=-16, swish=-19, hit=-13, pop=-21, click=-22, static=-20, tick=-27)
ATTACK = dict(whoosh=0.26, whoosh_deep=0.3, swish=0.15, hit=0.0, pop=0.0, click=0.0, static=0.0, tick=0.0)
PRIORITY = dict(hit=0, whoosh_deep=1, whoosh=1, static=1, swish=2, click=3, pop=4, tick=5)


def thin(cues, minutes, per_min):
    """Keep the budget: at most per_min small cues a minute; the least important go first."""
    budget = max(4, int(per_min * max(minutes, 0.25)))
    if len(cues) <= budget:
        return cues
    ranked = sorted(cues, key=lambda c: (PRIORITY.get(c[1], 9), c[0]))
    return sorted(ranked[:budget])


def music_bed(path, n, sr=SR):
    """Loop a track to n samples with 1.5 s crossfades."""
    a = load_audio(path, sr)
    if len(a) == 0:
        return np.zeros((n, 2), np.float32)
    xf = int(1.5 * sr)
    out = a.copy()
    while len(out) < n:
        r = np.linspace(0, 1, xf, dtype=np.float32)[:, None]
        if len(out) > xf and len(a) > xf:
            out[-xf:] = out[-xf:] * (1 - r) + a[:xf] * r
            out = np.concatenate([out, a[xf:]])
        else:
            out = np.concatenate([out, a])
    return out[:n]


def mix(plan, v: np.ndarray, cues, music=None, out_wav=None):
    """v: the voice; cues: [(t, name)]; music: {file, db, duck, lift_db, quiet: [[a, b]], start}."""
    n = len(v)
    mono = v.mean(axis=1)
    hop = int(SR * 0.02)
    k = n // hop
    rms = np.sqrt((mono[: k * hop].reshape(k, hop) ** 2).mean(axis=1) + 1e-12) if k else np.zeros(1)
    db = 20 * np.log10(rms)
    speech_db = np.percentile(db, 90) if k else -20
    out = v.copy()
    for t, name in cues:
        s = SFX[name]()
        g = 10 ** ((speech_db + LEVEL[name]) / 20) / max(1e-6, np.abs(s).max())
        i0 = int((t - ATTACK.get(name, 0)) * SR)
        if i0 < 0:
            s = s[-i0:]
            i0 = 0
        j = min(n, i0 + len(s))
        if j > i0:
            out[i0:j] += (s[: j - i0] * g)[:, None]
    if music and music.get("file"):
        bed = music_bed(plan._p(music["file"]), n)
        # level: the bed's own speech-band loudness set `db` under his voice
        bdb = 20 * np.log10(np.sqrt((bed.mean(axis=1) ** 2).mean() + 1e-12))
        base = speech_db + float(music.get("db", -18 if plan.long else -12)) - bdb
        gain_db = np.full(k, base)
        if music.get("duck", True):
            # talking -> base; a pause of min_pause s or more -> base + lift (ramped), so the bed never pumps
            thr = np.percentile(db, 30) + 0.4 * (speech_db - np.percentile(db, 30))
            talk = db > thr
            min_pause = 0.8 if plan.long else 0.4
            lift = float(music.get("lift_db", 5 if plan.long else 4))
            i = 0
            while i < k:
                if not talk[i]:
                    j = i
                    while j < k and not talk[j]:
                        j += 1
                    if (j - i) * 0.02 >= min_pause:
                        gain_db[i + 5:max(i + 5, j - 3)] += lift
                    i = j
                else:
                    i += 1
        for a_, b_ in music.get("quiet", []):
            a_, b_ = int(plan.T(a_) / 0.02), int(plan.T(b_) / 0.02)
            gain_db[max(0, a_):min(k, b_)] = -80
        # smooth 0.25 s
        w = 12
        g = np.convolve(np.pad(gain_db, (w, w), mode="edge"), np.ones(2 * w + 1) / (2 * w + 1), mode="same")[w:-w]
        g = np.repeat(10 ** (g / 20), hop)
        g = np.pad(g, (0, max(0, n - len(g))), mode="edge")[:n]
        fi = int(0.4 * SR)
        g[:fi] *= np.linspace(0, 1, fi)
        fo = int(1.2 * SR)
        g[-fo:] *= np.linspace(1, 0, fo)
        out += bed * g[:, None]
    tmp = plan.work / "mix_raw.wav"
    write_wav(tmp, out / max(1.0, np.abs(out).max()), SR)
    return loudnorm(tmp, out_wav or plan.work / "mix.wav")


def loudnorm(src, dst, I=-14.0, TP=-2.0, LRA=11):
    r = subprocess.run([ffmpeg(), "-hide_banner", "-i", str(src), "-af", f"loudnorm=I={I}:TP={TP}:LRA={LRA}:"
                        "print_format=json", "-f", "null", "-"], capture_output=True, text=True)
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr, re.S)
    if not m:
        subprocess.run([ffmpeg(), "-v", "error", "-y", "-i", str(src), "-af", f"loudnorm=I={I}:TP={TP}", "-ar",
                        str(SR), str(dst)], check=True)
        return Path(dst)
    j = json.loads(m.group(0))
    af = (f"loudnorm=I={I}:TP={TP}:LRA={LRA}:measured_I={j['input_i']}:measured_TP={j['input_tp']}:"
          f"measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true")
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-i", str(src), "-af", af, "-ar", str(SR), str(dst)], check=True)
    return Path(dst)
