"""Type: rich text synced to his words, the type events (slam, pop, words, kicker, marker, sub, count) and captions.

Text marks one accent with *stars*: "Stop editing *manually.*" Each word lands when he says it (matched against the
transcript inside the event's window); unmatched words follow the previous one by 0.12 s.
"""
from __future__ import annotations

import functools
import re

from PIL import Image, ImageDraw, ImageFilter

from .core import View, back_out, clamp, font, lerp, out3, out5, rgba, wrap


def norm(s):
    return re.sub(r"[^\w']+", "", s.lower().replace("*", ""))


def tokens(text):
    """[(display, accent)] from a *starred* string; the stars may wrap several words."""
    out, acc = [], False
    for raw in text.split():
        a = raw.startswith("*")
        if a:
            acc = True
        disp = raw.replace("*", "")
        out.append((disp, acc))
        if raw.endswith("*") or (raw.count("*") >= 2):
            acc = False
        if raw.endswith("*.") or raw.endswith("*,") or raw.endswith("*?") or raw.endswith("*!"):
            acc = False
    return out


def sync(plan, toks, t_from, t_to, stagger=0.09):
    """A start time per token: his spoken word when it matches, else the previous + stagger."""
    ws = [w for w in plan.wlist if t_from - 0.4 <= w["s"] <= t_to + 0.6]
    times, j, last = [], 0, None
    for disp, _ in toks:
        n = norm(disp)
        hit = None
        for k in range(j, min(len(ws), j + 8)):
            if norm(ws[k]["w"]) == n and n:
                hit = k
                break
        if hit is not None:
            last = max(ws[hit]["s"] - 0.03, t_from)
            j = hit + 1
        else:
            last = t_from if last is None else last + stagger
        times.append(last)
    # keep the order monotonic
    for i in range(1, len(times)):
        times[i] = max(times[i], times[i - 1])
    return times


def layout(toks, name, size, max_w, gap=0.26):
    """Lines of (disp, accent, x, width) with widths at `size`; x from the line's left."""
    f = font(name, size)
    space = f.getlength(" ") * (1 + gap)
    lines, cur, x = [], [], 0.0
    for disp, acc in toks:
        w = f.getlength(disp)
        if cur and x + w > max_w:
            lines.append(cur)
            cur, x = [], 0.0
        cur.append([disp, acc, x, w])
        x += w + space
    if cur:
        lines.append(cur)
    return lines


def fit(toks, name, size, max_w, max_lines=3, min_size=36):
    while size > min_size and len(layout(toks, name, size, max_w)) > max_lines:
        size *= 0.93
    return size


def draw_rich(v: View, plan, x, y, text, t, t_from, t_to=None, name="display", size=110, color=None, accent=None,
              max_w=1500, align="center", times=None, lh=1.08, max_lines=3, underline=True, alpha=1.0,
              stroke=0, stroke_fill=None, rise=0.35):
    """Draw text whose words land on his words. (x, y) is the anchor of the block (centre/left top)."""
    toks = tokens(text)
    size = fit(toks, name, size, max_w, max_lines)
    lines = layout(toks, name, size, max_w)
    times = times or sync(plan, toks, t_from, t_to if t_to is not None else t_from + 4)
    if times and times[0] > t_from + 0.15:
        # never an empty frame: the first word is up as the block arrives, the rest land on his words
        times = [t_from + 0.08] + list(times[1:])
    color = color or plan.look["ink"]
    accent = accent or plan.accent
    total_h = len(lines) * size * lh
    k = 0
    y0 = y - (total_h / 2 if align in ("center", "middle") else 0)
    for li, line in enumerate(lines):
        lw = line[-1][2] + line[-1][3]
        lx = x - lw / 2 if align in ("center", "middle") else x - lw if align == "right" else x
        ly = y0 + li * size * lh
        for disp, acc, ox, w in line:
            ti = times[k]
            k += 1
            u = out3((t - ti) / 0.22)
            if u <= 0:
                continue
            dy = (1 - out5((t - ti) / 0.3)) * size * rise
            c = accent if acc else color
            if acc and underline:
                uw = out3((t - ti - 0.08) / 0.32)
                if uw > 0:
                    v.rect(lx + ox, ly + size * 0.98 + dy, w * uw, max(4, size * 0.085), fill=accent, alpha=alpha * u)
            v.text(lx + ox, ly + dy, disp, name, size, c, "la", alpha=alpha * u, stroke=stroke, stroke_fill=stroke_fill)
    return total_h


# ---- type events ----------------------------------------------------------------------------------------------------
@functools.lru_cache(maxsize=128)
def _slam_sprite(text, name, size, color, accent, shadow, max_w):
    """Text (one or two lines, *accent* allowed) with a soft dark shadow, at 2x, as RGBA."""
    k = 2
    toks = tokens(text)
    lines = layout(toks, name, size, max_w)
    f = font(name, size * k)
    lh = size * 1.04
    W = int(max(l[-1][2] + l[-1][3] for l in lines) + size * 0.6)
    H = int(len(lines) * lh + size * 0.5)
    img = Image.new("RGBA", (W * k, H * k), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for li, line in enumerate(lines):
        lw = line[-1][2] + line[-1][3]
        lx = (W - lw) / 2
        for disp, acc, ox, w in line:
            d.text(((lx + ox) * k, (size * 0.2 + li * lh) * k), disp, font=f, fill=rgba(accent if acc else color))
    if shadow:
        a = img.getchannel("A").filter(ImageFilter.GaussianBlur(size * 0.12 * k)).point(lambda q: int(q * 0.55))
        sh = Image.new("RGBA", img.size, (0, 0, 0, 0))
        sh.putalpha(a)
        out = Image.new("RGBA", img.size, (0, 0, 0, 0))
        out.alpha_composite(sh, (0, int(size * 0.06 * k)))
        out.alpha_composite(img)
        img = out
    return img, W, H


@functools.lru_cache(maxsize=128)
def _pill_sprite(text, name, size, fg, bg, pad):
    k = 2
    f = font(name, size * k)
    w = f.getlength(text) / k
    W, H = int(w + pad * 2), int(size * 1.5)
    img = Image.new("RGBA", (W * k, H * k), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, W * k - 1, H * k - 1), H * k / 2, fill=rgba(bg))
    d.text((W * k / 2, H * k / 2), text, font=f, fill=rgba(fg), anchor="mm")
    return img, W, H


POS = {"center": (0.5, 0.5), "top": (0.5, 0.16), "bottom": (0.5, 0.8), "left": (0.27, 0.46), "right": (0.73, 0.46),
       "upper": (0.5, 0.3), "lower": (0.5, 0.7)}


def resolve_pos(plan, ev, beat, faces_at=None):
    p = ev.get("pos", "auto")
    WW, WH = plan.WW, plan.WH
    if isinstance(p, (list, tuple)):
        return p[0] * WW, p[1] * WH
    if p == "auto":
        if plan.portrait:
            return WW * 0.5, WH * 0.22
        if beat["stage"] in ("full",) and faces_at:
            fx = faces_at[0]
            return (WW * 0.74 if fx < 0.5 else WW * 0.26), WH * 0.42
        return WW * 0.5, WH * 0.16
    fx, fy = POS.get(p, POS["center"])
    if plan.portrait and p in ("top",):
        fy = 0.2
    return fx * WW, fy * WH


def on_video(beat):
    """White type with a shadow over footage and the dark stages; ink on the page."""
    return beat["stage"] in ("full", "broll", "editor", "call", "cinema")


def draw_event(v: View, plan, ev, t, beat, faces_at=None):
    a, b = ev["_t0"], ev["_t1"]
    if not (a - 0.05 <= t <= b + 0.35):
        return False
    style = ev.get("style", "pop")
    x, y = resolve_pos(plan, ev, beat, faces_at)
    vid = on_video(beat)
    ink = "#FFFFFF" if vid else plan.look["ink"]
    out = 1 - out3((t - b) / 0.22) if t > b else 1.0
    size = float(ev.get("size", {"slam": 128, "pop": 54, "words": 84, "kicker": 30, "marker": 70, "sub": 40,
                                 "count": 200}.get(style, 60)))
    if plan.portrait and "size" not in ev:
        size *= 0.92
    beside_face = not plan.portrait and ev.get("pos", "auto") in ("auto", "left", "right") and beat["stage"] == "full"
    max_w = float(ev.get("max_w", plan.WW * (0.78 if plan.portrait else 0.38 if beside_face else 0.6)))
    if style == "slam":
        img, W, H = _slam_sprite(ev["text"], ev.get("font", "display"), size, ink, plan.accent, vid, max_w)
        u = (t - a) / 0.16
        sc = lerp(1.5, 1.0, out3(u)) if u < 1 else 1.0
        shake = (1 - clamp((t - a) / 0.28)) * size * 0.05
        import math
        sx = math.sin(t * 90) * shake
        al = clamp(u * 2) * out
        v.place(img, v.box(x - W * sc / 2 + sx, y - H * sc / 2, W * sc, H * sc), alpha=al)
    elif style == "pop":
        bg = ev.get("bg", plan.accent if ev.get("accent") else ("#FFFFFF" if vid else plan.look["ink"]))
        fg = ev.get("fg", "#FFFFFF" if bg != "#FFFFFF" else "#111111")
        img, W, H = _pill_sprite(ev["text"], ev.get("font", "heavy"), size, fg, bg, size * 0.6)
        sc = back_out((t - a) / 0.3, 2.0) if t < a + 0.3 else 1.0
        sc = max(0.0, sc)
        v.place(img, v.box(x - W * sc / 2, y - H * sc / 2, W * sc, H * sc), alpha=clamp((t - a) / 0.08) * out)
    elif style == "kicker":
        img, W, H = _pill_sprite(ev["text"].upper(), "monob", size, "#FFFFFF" if not vid else "#111111",
                                 plan.accent if not vid else "#FFFFFF", size * 0.7)
        u = out5((t - a) / 0.3)
        v.place(img, v.box(x - W / 2, y - H / 2 + (1 - u) * 20, W, H), alpha=u * out)
    elif style in ("words", "marker"):
        draw_rich(v, plan, x, y, ev["text"], t, a, b, name=ev.get("font", "display"), size=size,
                  color=ink, max_w=max_w, alpha=out, stroke=size * 0.06 if vid else 0, stroke_fill="#000000",
                  underline=True)
    elif style == "sub":
        f = font("bold", size)
        lines = wrap(ev["text"], "bold", size, plan.WW * 0.7)
        lh = size * 1.3
        bw = max(f.getlength(l) for l in lines) + size * 1.2
        bh = len(lines) * lh + size * 0.5
        yb = plan.WH * (0.86 if not plan.portrait else 0.7) - bh / 2
        al = clamp((t - a) / 0.12) * out
        v.rect(plan.WW / 2 - bw / 2, yb, bw, bh, fill=(0, 0, 0, 165), r=size * 0.4, alpha=al)
        for i, l in enumerate(lines):
            v.text(plan.WW / 2, yb + size * 0.25 + i * lh + lh / 2, l, "bold", size, "#FFFFFF", "mm", alpha=al)
    elif style == "count":
        txt = count_text(ev["text"], (t - a) / float(ev.get("dur", 0.9)), ev.get("from"))
        u = out5((t - a) / 0.25)
        v.text(x, y, txt, ev.get("font", "display"), size, ev.get("color", ink), "mm", alpha=u * out,
               stroke=size * 0.04 if vid else 0, stroke_fill="#000")
        if ev.get("label"):
            v.text(x, y + size * 0.62, ev["label"], "bold", size * 0.22, plan.look["muted"] if not vid else "#FFFFFF",
                   "mm", alpha=u * out)
    return True


NUM = re.compile(r"[-+]?\d[\d,]*\.?\d*")


def count_text(text, u, start=None):
    """Count the first number in text up to its value (thousands separators and decimals kept)."""
    m = NUM.search(text)
    if not m:
        return text
    raw = m.group(0)
    val = float(raw.replace(",", ""))
    dec = len(raw.split(".")[1]) if "." in raw else 0
    s0 = float(start) if start is not None else 0.0
    cur = lerp(s0, val, out5(clamp(u)))
    s = f"{cur:,.{dec}f}" if "," in raw else f"{cur:.{dec}f}"
    return text[: m.start()] + s + text[m.end():]


# ---- captions ---------------------------------------------------------------------------------------------------------
def caption_groups(plan, max_words=4, max_len=1.3):
    groups, cur = [], []
    for w in plan.wlist:
        if cur and (len(cur) >= max_words or w["s"] - cur[0]["s"] > max_len or w["s"] - cur[-1]["e"] > 0.35):
            groups.append(cur)
            cur = []
        cur.append(w)
        if re.search(r"[.?!,]$", w["w"]):
            groups.append(cur)
            cur = []
    if cur:
        groups.append(cur)
    out = []
    for i, g in enumerate(groups):
        end = groups[i + 1][0]["s"] if i + 1 < len(groups) else g[-1]["e"] + 0.4
        out.append(dict(a=g[0]["s"], b=min(end, g[-1]["e"] + 0.6), words=g))
    return out


def draw_captions(v: View, plan, groups, t, beat):
    g = next((g for g in groups if g["a"] <= t < g["b"]), None)
    if not g:
        return
    size = 74 if plan.portrait else 62
    y = plan.WH * (0.69 if plan.portrait else 0.865)
    words = [w["w"].upper() if plan.portrait else w["w"] for w in g["words"]]
    max_w = plan.WW * 0.88
    # fit: shrink to the line (not below 80 %), else two lines
    total = lambda ws, sz: sum(font("heavy", sz).getlength(w) for w in ws) + font("heavy", sz).getlength(" ") * (len(ws) - 1)
    if total(words, size) > max_w:
        size = max(size * 0.8, size * max_w / total(words, size))
    lines = [list(zip(g["words"], words))]
    if total(words, size) > max_w and len(words) > 1:
        k = len(words) // 2
        lines = [lines[0][:k], lines[0][k:]]
    u = out5((t - g["a"]) / 0.12)
    f = font("heavy", size)
    sp = f.getlength(" ")
    lh = size * 1.12
    y0 = y - (len(lines) - 1) * lh / 2
    for li, line in enumerate(lines):
        tw = total([ww for _, ww in line], size)
        x = plan.WW / 2 - tw / 2
        for w, ww in line:
            active = w["s"] <= t < w["e"] + 0.05
            c = plan.accent if active else "#FFFFFF"
            v.text(x, y0 + li * lh + (1 - u) * 14, ww, "heavy", size, c, "lm", stroke=size * 0.1,
                   stroke_fill="#000000", alpha=u)
            x += f.getlength(ww) + sp
