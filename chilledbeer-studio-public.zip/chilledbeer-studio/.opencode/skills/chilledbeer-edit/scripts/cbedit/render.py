"""The renderer: prepare (voice, envelope, thumbnails, faces), draw frames with bounded workers, mix, mux.

Each worker owns a slice of output frames: it streams his frames segment by segment, draws the beat's stage (two
stages and a blend inside a transition window), then the type and captions, and pipes RGB into its own x264 encode.
The slices join by stream copy; the frame count is checked.
"""
from __future__ import annotations

import json
import multiprocessing as mp
import subprocess
import time
from pathlib import Path

import numpy as np
from PIL import Image

from . import audio as A
from . import motion as M
from .core import View
from .lens import Faces
from .media import Reader, decode_size, ffmpeg, probe, still
from .plan import Plan
from .resources import choose_render_workers, ffmpeg_threads, render_workers
from .stages import STAGE_CLASSES, Ctx, Res
from .typeset import caption_groups, draw_captions, draw_event


def prepare_events(plan):
    """Resolve type events' times into _t0/_t1 on the plan's json (shared by the editor's V2 track)."""
    evs = plan.j.get("type", [])
    for i, ev in enumerate(evs):
        ev["_t0"] = plan.T(ev.get("at", 0))
        if ev.get("until") is not None:
            ev["_t1"] = plan.T(ev["until"])
        else:
            ev["_t1"] = ev["_t0"] + float(ev.get("dur", 1.6))
    return evs


def thumbs(plan):
    d = plan.work / "thumbs"
    d.mkdir(exist_ok=True)
    for k, s in enumerate(plan.segs):
        p = d / f"seg{k:04d}.jpg"
        if p.exists():
            continue
        info = plan.info[s["src"]]
        img = still(plan.sources[s["src"]], s["a"] + min(0.4, (s["b"] - s["a"]) / 2), (320, int(320 * info["h"] / info["w"])),
                    grade=plan.grade, transfer=info["transfer"])
        img.save(p, quality=88)


def prepare(plan, log=print):
    t0 = time.time()
    v = A.voice(plan)
    np.save(plan.work / "voice.npy", v)
    env = A.frame_env(v, plan.fps, plan.nframes)
    np.save(plan.work / "env.npy", env)
    m = plan.j.get("music") or {}
    if m.get("file"):
        bed = A.music_bed(plan._p(m["file"]), len(v))
        np.save(plan.work / "menv.npy", A.frame_env(bed, plan.fps, plan.nframes))
    thumbs(plan)
    log(f"prepare: voice {len(v) / A.SR:.2f}s, {len(plan.segs)} segments, thumbnails  ({time.time() - t0:.1f}s)")


# ---- the frame loop -----------------------------------------------------------------------------------------------------
class FrameSource:
    """His frames, streamed in order across segments."""

    def __init__(self, plan):
        self.plan = plan
        self.rd = None
        self.key = None
        self.next_f = None
        self.size = {}
        for k, i in plan.info.items():
            self.size[k] = decode_size(i["w"], i["h"], plan.H)

    def get(self, f):
        plan = self.plan
        k = plan.seg_at(f / plan.fps)
        s = plan.segs[k]
        if self.rd is None or self.key != k or self.next_f != f:
            if self.rd:
                self.rd.close()
            off = (f - s["f0"]) / plan.fps * plan.speed
            info = plan.info[s["src"]]
            self.rd = Reader(plan.sources[s["src"]], s["a"] + off, s["f0"] + s["n"] - f, plan.rate,
                             self.size[s["src"]], speed=plan.speed, grade=plan.grade, transfer=info["transfer"])
            self.key = k
        self.next_f = f + 1
        return self.rd.read(), s["src"], s["a"] + (f - s["f0"]) / plan.fps * plan.speed

    def close(self):
        if self.rd:
            self.rd.close()


class ClipSource:
    """B-roll clips named by beats (props.clip = file or {file, from})."""

    def __init__(self, plan):
        self.plan = plan
        self.open = {}

    def get(self, beat, t):
        c = beat["props"].get("clip")
        if not c:
            return None
        if isinstance(c, str):
            c = {"file": c}
        path = str(self.plan._p(c["file"]))
        f = int(round((t - beat["t0"]) * self.plan.fps))
        st = self.open.get(beat["k"])
        if st is None or st[1] != f:
            if st:
                st[0].close()
            info = probe(path)
            n = int(beat["dur"] * self.plan.fps) + 30
            size = decode_size(info["w"], info["h"], self.plan.H)
            rd = Reader(path, float(c.get("from", 0)) + f / self.plan.fps, n, self.plan.rate, size,
                        grade=c.get("grade", "none"), transfer=info["transfer"])
            st = [rd, f]
            self.open[beat["k"]] = st
        st[1] = f + 1
        return st[0].read()


class Painter:
    def __init__(self, plan):
        self.plan = plan
        self.faces = Faces(plan.work / "faces.json")
        self.res = Res(plan)
        self.ctx = Ctx(plan, self.faces, self.res)
        self.stages = {}
        prepare_events(plan)
        cap = plan.j.get("captions", "full" if plan.portrait else "off")
        cap = cap.get("mode", "off") if isinstance(cap, dict) else cap
        self.cap = caption_groups(plan) if cap == "full" else []
        self.clips = ClipSource(plan)

    def stage(self, b):
        if b["k"] not in self.stages:
            self.stages[b["k"]] = STAGE_CLASSES[b["stage"]](self.plan, b, self.res)
        return self.stages[b["k"]]

    def draw_beat(self, b, t, frame, src, src_t):
        img = Image.new("RGB", (self.plan.W, self.plan.H))
        clip = self.clips.get(b, t)
        ctx = self.ctx.set(b, t, frame, src, src_t, self.res.env_at(t), clip)
        self.stage(b).draw(img, ctx)
        return img

    def frame(self, f, frame, src, src_t):
        plan = self.plan
        t = f / plan.fps
        b = plan.beat_at(t)
        img = None
        # a transition window around a boundary?
        for nb in (b, plan.beats[b["k"] + 1] if b["k"] + 1 < len(plan.beats) else None):
            if nb is None or nb["k"] == 0:
                continue
            d = M.DUR.get(nb["in"], 0)
            if d and nb["t0"] - d / 2 <= t < nb["t0"] + d / 2:
                pb = plan.beats[nb["k"] - 1]
                Aimg = self.draw_beat(pb, t, frame, src, src_t)
                Bimg = self.draw_beat(nb, max(t, nb["t0"]), frame, src, src_t)
                img = M.apply(nb["in"], Aimg, Bimg, (t - (nb["t0"] - d / 2)) / d, nb)
                b = nb if t >= nb["t0"] else pb
                break
        if img is None:
            img = self.draw_beat(b, t, frame, src, src_t)
        v = View(img, plan.WW / 2, plan.WH / 2, plan.scale)
        fa = self.faces.at(src, src_t) if b["stage"] == "full" else None
        shown = False
        for ev in plan.j.get("type", []):
            shown |= draw_event(v, plan, ev, t, b, fa)
        # captions step aside where the words are already on screen (a card, a takeover)
        if self.cap and not shown and b["stage"] not in ("takeover", "beside"):
            draw_captions(v, plan, self.cap, t, b)
        return img


def _encoder(plan, out, final):
    crf, preset = (str(plan.j.get("crf", 16)), plan.j.get("preset", "medium")) if final else ("23", "veryfast")
    g = str(int(round(plan.fps * 2)))
    return [ffmpeg(), "-v", "error", "-y", "-filter_threads", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{plan.W}x{plan.H}",
            "-r", plan.rate, "-i", "-", "-vf", "scale=out_color_matrix=bt709:out_range=tv,format=yuv420p",
            "-c:v", "libx264", "-threads:v", str(ffmpeg_threads()), "-preset", preset, "-crf", crf, "-g", g, "-bf", "2", "-colorspace", "bt709",
            "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv", "-movflags", "+faststart",
            str(out)]


def _worker(args):
    path, draft, f0, f1, out = args
    plan = Plan(path, draft=draft)
    P = Painter(plan)
    fs = FrameSource(plan)
    enc = subprocess.Popen(_encoder(plan, out, not draft), stdin=subprocess.PIPE)
    for f in range(f0, f1):
        frame, src, st = fs.get(f)
        img = P.frame(f, frame, src, st)
        enc.stdin.write(img.tobytes())
    enc.stdin.close()
    enc.wait()
    fs.close()
    return out


def cues(plan):
    """The SFX list [(t, name)] from transitions, type events and stage events, thinned to the budget."""
    if plan.j.get("sfx", "auto") == "off":
        return []
    out = []
    for b in plan.beats[1:]:
        n = M.SFX.get(b["in"])
        if n:
            out.append((b["t0"], n))
        if b["stage"] == "tv" and b["props"].get("static", b["in"] in ("cut", "static", "rise")):
            out.append((b["t0"] + 0.01, "static"))
        if b.get("out") == "dive":
            out.append((b["t1"] - 0.12, "swish"))
    for b in plan.beats:
        if b["stage"] == "editor":
            for tr in editor_razors(plan, b):
                out.append((tr, "click"))
        if b["stage"] in ("phone", "post") and b["props"].get("like") is not None:
            out.append((plan.T(b["props"]["like"]), "pop"))
    for ev in plan.j.get("type", []):
        st = ev.get("style", "pop")
        if st == "slam":
            out.append((ev["_t0"], "hit"))
        elif st in ("pop", "kicker") and ev.get("sfx", True):
            out.append((ev["_t0"], "pop"))
        elif st == "count":
            out.append((ev["_t0"] + float(ev.get("dur", 0.9)), "pop"))
    for x in plan.j.get("sfx_add", []):
        out.append((plan.T(x[0]), x[1]))
    out.sort()
    # no two cues within 0.12 s
    keep = []
    for c in out:
        if keep and c[0] - keep[-1][0] < 0.12:
            continue
        keep.append(c)
    per_min = 12 if plan.portrait or not plan.long else 8
    return A.thin(keep, plan.duration / 60, per_min)


def editor_razors(plan, b):
    r = b["props"].get("razor", "auto")
    if r == "auto":
        return [tp for tp, _, _ in plan.punches if b["t0"] + 0.9 < tp < b["t1"] - 0.2]
    return [plan.T(x) for x in (r or [])]


def render(path, draft=False, out=None, workers=None, log=print):
    plan = Plan(path, draft=draft)
    prepare_events(plan)
    t_start = time.time()
    prepare(plan, log)
    final_dir = plan.dir / plan.j.get("out_dir", "out")
    final_dir.mkdir(exist_ok=True)
    name = plan.j.get("name", plan.path.stem)
    out = Path(out) if out else final_dir / f"{name}{'_draft' if draft else ''}.mp4"
    # sound first: it is cheap and the editor's waveform reads it
    cs = cues(plan)
    v = np.load(plan.work / "voice.npy")
    mixwav = A.mix(plan, v, cs, plan.j.get("music"), plan.work / ("mix_draft.wav" if draft else "mix.wav"))
    log(f"sound: {len(cs)} sfx cues, mix at -14 LUFS")
    n = plan.nframes
    # Each painter has a decoder and encoder of its own. Cap *combined* CPU
    # and memory pressure, but use safe parallelism instead of serializing all
    # renders. A requested lower worker count is still honoured.
    safe_limit = render_workers(plan.H)
    requested = workers if workers is not None else plan.j.get("workers")
    workers = choose_render_workers(plan.H, requested)
    if requested is not None and int(requested) > safe_limit:
        log(f"resource guard: requested {requested} workers; using safe limit {safe_limit}")
    log(f"resource guard: {workers} render workers, {ffmpeg_threads()} FFmpeg threads per decoder/encoder")
    chunk = max(int(plan.fps * 2), -(-n // workers))
    parts = []
    tmpdir = plan.work / ("chunks_draft" if draft else "chunks")
    tmpdir.mkdir(exist_ok=True)
    for i, f0 in enumerate(range(0, n, chunk)):
        parts.append((str(plan.path), draft, f0, min(n, f0 + chunk), str(tmpdir / f"c{i:03d}.mp4")))
    log(f"render: {n} frames at {plan.W}x{plan.H} {plan.fps:g} fps in {len(parts)} chunks")
    ctxm = mp.get_context("spawn")
    with ctxm.Pool(len(parts)) as pool:
        for i, _ in enumerate(pool.imap_unordered(_worker, parts)):
            log(f"  chunk {i + 1}/{len(parts)} done  ({time.time() - t_start:.0f}s)")
    lst = tmpdir / "list.txt"
    lst.write_text("".join(f"file '{p[4]}'\n" for p in parts))
    video = tmpdir / "video.mp4"
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(video)],
                   check=True)
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-i", str(video), "-i", str(mixwav), "-map", "0:v", "-map", "1:a",
                    "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", "-shortest", "-movflags", "+faststart", str(out)],
                   check=True)
    if not draft:
        try:
            mids = [round((b["t0"] + b["t1"]) / 2, 2) for b in plan.beats][:30]
            stills(path, mids, final_dir / "stills.jpg")
        except Exception as e:      # the sheet is a convenience; it never fails a render
            log(f"stills skipped: {e}")
    got = count_frames(out)
    log(f"done: {out}  ({got} frames, want {n}; {time.time() - t_start:.0f}s)")
    if abs(got - n) > 1:
        log("WARNING: frame count differs from the plan")
    return out


def count_frames(path):
    import shutil
    fp = shutil.which("ffprobe")
    if not fp:
        return -1
    r = subprocess.run([fp, "-v", "error", "-count_packets", "-select_streams", "v:0", "-show_entries",
                        "stream=nb_read_packets", "-of", "csv=p=0", str(path)], capture_output=True, text=True)
    try:
        return int(r.stdout.strip().strip(","))
    except ValueError:
        return -1


def stills(path, times, out, draft=True, cols=3):
    """Frames at the given output times, drawn exactly as the render would, on one contact sheet."""
    plan = Plan(path, draft=draft)
    prepare_events(plan)
    if not (plan.work / "env.npy").exists() or not (plan.work / "thumbs").exists():
        prepare(plan)
    P = Painter(plan)
    imgs = []
    for t in times:
        t = plan.T(t)
        f = min(plan.nframes - 1, int(t * plan.fps))
        src, src_t, k = plan.src_time(f / plan.fps)
        info = plan.info[src]
        size = decode_size(info["w"], info["h"], plan.H)
        fr = still(plan.sources[src], src_t, size, plan.grade, info["transfer"])
        img = P.frame(f, fr, src, src_t)
        View(img).text(14, 14, f"{t:.2f}s  {plan.beat_at(t)['stage']}", "monob", 18, "#FFFFFF", stroke=3,
                       stroke_fill="#000")
        imgs.append(img)
    w, h = imgs[0].size
    rows = -(-len(imgs) // cols)
    sheet = Image.new("RGB", (w * min(cols, len(imgs)), h * rows), (20, 20, 20))
    for i, im in enumerate(imgs):
        sheet.paste(im, ((i % cols) * w, (i // cols) * h))
    sheet.save(out, quality=90)
    return out
