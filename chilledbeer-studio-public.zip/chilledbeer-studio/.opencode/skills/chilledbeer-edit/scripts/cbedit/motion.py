"""Transitions between beats, on finished frames (A = outgoing beat, B = incoming, u = 0..1 across the window).

Each kind means something (pick by meaning, never the same kind twice in a row; cuts may repeat):
  cut     keeps the thought going                     rise    a device enters from below (the stage's own camera)
  whip    on to the next thing, fast                  push    the next scene slides in beside this one
  zoom    dive into the detail (zoom-through)         flash   a hit: the reveal, the number, the punchline
  glitch  a screen/TV/phone world switching           iris    a circle opens on the next scene
  fade    a soft return (after a takeover)            reveal  pull out from his full frame into the device
  static  a TV channel change
"""
from __future__ import annotations

import math

import numpy as np
from PIL import Image

from .core import clamp, expo_in, expo_inout, expo_out, inout3, out3

# window length (s), centred on the beat boundary
DUR = dict(cut=0.0, rise=0.0, reveal=0.0, whip=0.34, push=0.5, zoom=0.4, flash=0.22, glitch=0.24, iris=0.5,
           fade=0.4, static=0.0)
SFX = dict(whip="whoosh", push="swish", zoom="whoosh_deep", flash="hit", glitch="static", iris="swish",
           reveal="swish", static="static", rise="swish")


def _hblur(arr: np.ndarray, r: int) -> np.ndarray:
    """Horizontal box blur of radius r (motion blur along a whip)."""
    if r < 1:
        return arr
    a = arr.astype(np.float32)
    pad = np.pad(a, ((0, 0), (r + 1, r), (0, 0)), mode="edge")
    c = np.cumsum(pad, axis=1)
    out = (c[:, 2 * r + 1:] - c[:, :-2 * r - 1]) / (2 * r + 1)
    return out[:, : arr.shape[1]].astype(np.uint8)


def whip(A, B, u, direction=1):
    W, H = A.size
    k = expo_inout(u)
    off = k * W * direction
    out = Image.new("RGB", (W, H))
    out.paste(A, (int(round(-off)), 0))
    out.paste(B, (int(round(W * direction - off)), 0))
    speed = math.sin(math.pi * clamp(u)) ** 2
    r = int(speed * W * 0.045)
    if r > 0:
        out = Image.fromarray(_hblur(np.asarray(out), r))
    return out


def push(A, B, u, direction=1):
    W, H = A.size
    k = inout3(u)
    off = k * W * direction
    out = Image.new("RGB", (W, H))
    out.paste(A, (int(round(-off)), 0))
    out.paste(B, (int(round(W * direction - off)), 0))
    return out


def _zoomed(img, s, fx, fy):
    W, H = img.size
    cw, ch = W / s, H / s
    x0 = min(max(fx * W - cw / 2, 0), W - cw)
    y0 = min(max(fy * H - ch / 2, 0), H - ch)
    return img.resize((W, H), Image.BILINEAR, box=(x0, y0, x0 + cw, y0 + ch))


def zoom(A, B, u, fx=0.5, fy=0.45):
    """Zoom-through: A rushes in toward (fx, fy), B lands from a push-in; a short radial smear on both sides."""
    if u < 0.5:
        k = expo_in(u * 2)
        s = 1 + 2.2 * k
        imgs = [_zoomed(A, s * m, fx, fy) for m in (1.0, 1.04, 1.08)] if k > 0.15 else [_zoomed(A, s, fx, fy)]
    else:
        k = 1 - expo_out((u - 0.5) * 2)
        s = 1 + 0.9 * k
        imgs = [_zoomed(B, s * m, 0.5, 0.5) for m in (1.0, 1.03, 1.06)] if k > 0.15 else [_zoomed(B, s, 0.5, 0.5)]
    if len(imgs) == 1:
        return imgs[0]
    arr = sum(np.asarray(i, np.float32) for i in imgs) / len(imgs)
    return Image.fromarray(arr.astype(np.uint8))


def flash(A, B, u):
    W, H = A.size
    white = Image.new("RGB", (W, H), (255, 255, 255))
    if u < 0.5:
        return Image.blend(A, white, clamp(u * 2) ** 2 * 0.9)
    return Image.blend(B, white, (1 - clamp((u - 0.5) * 2)) ** 1.5 * 0.9)


def glitch(A, B, u, seed=0):
    src = A if u < 0.5 else B
    a = np.asarray(src).copy()
    s = math.sin(math.pi * clamp(u))
    H, W = a.shape[:2]
    rng = np.random.default_rng(int(u * 1000) + seed)
    sh = int(W * 0.02 * s)
    if sh:
        a[:, :, 0] = np.roll(a[:, :, 0], sh, axis=1)
        a[:, :, 2] = np.roll(a[:, :, 2], -sh, axis=1)
    for _ in range(int(10 * s)):
        y = rng.integers(0, H - 10)
        h = rng.integers(4, max(5, H // 14))
        a[y:y + h] = np.roll(a[y:y + h], rng.integers(-W // 10, W // 10), axis=1)
    return Image.fromarray(a)


def iris(A, B, u, fx=0.5, fy=0.5):
    W, H = A.size
    r = expo_inout(u) * math.hypot(W, H) * 0.6
    yy, xx = np.ogrid[0:H, 0:W]
    d = np.hypot(xx - fx * W, yy - fy * H)
    m = np.clip(r - d + 1, 0, 1)
    mask = Image.fromarray((m * 255).astype(np.uint8), "L")
    out = A.copy()
    out.paste(B, (0, 0), mask)
    return out


def fade(A, B, u):
    return Image.blend(A, B, inout3(u))


def apply(kind, A, B, u, beat=None):
    d = (beat or {}).get("props", {}).get("dir", 1)
    if kind == "whip":
        return whip(A, B, u, d)
    if kind == "push":
        return push(A, B, u, d)
    if kind == "zoom":
        f = (beat or {}).get("props", {}).get("focus", [0.5, 0.45])
        return zoom(A, B, u, *f)
    if kind == "flash":
        return flash(A, B, u)
    if kind == "glitch":
        return glitch(A, B, u)
    if kind == "iris":
        return iris(A, B, u)
    if kind == "fade":
        return fade(A, B, u)
    return B if u >= 0.5 else A
