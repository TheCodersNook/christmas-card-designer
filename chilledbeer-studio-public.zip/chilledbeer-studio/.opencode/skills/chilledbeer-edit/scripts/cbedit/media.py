"""ffmpeg plumbing: find the binaries, probe a take, stream frames, load audio, grab stills.

Works with a system ffmpeg, or with the static binary from `pip install imageio-ffmpeg` (then probing parses ffmpeg's
own banner, since that package ships no ffprobe).
"""
from __future__ import annotations

import functools
import json
import re
import shutil
import subprocess
from fractions import Fraction
from pathlib import Path

import numpy as np
from .resources import ffmpeg_threads
from PIL import Image


@functools.lru_cache(maxsize=1)
def ffmpeg() -> str:
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        raise SystemExit("ffmpeg not found. Install it (brew install ffmpeg / apt install ffmpeg) "
                         "or run: pip install imageio-ffmpeg")


@functools.lru_cache(maxsize=64)
def probe(path: str) -> dict:
    """{w, h, fps (float), rate ('60000/1001'), duration, transfer ('sdr' | 'hlg' | 'pq'), audio (bool), rotation}."""
    path = str(path)
    fp = shutil.which("ffprobe")
    info = {}
    if fp:
        r = subprocess.run([fp, "-v", "error", "-show_streams", "-show_format", "-of", "json", path],
                           capture_output=True, text=True)
        j = json.loads(r.stdout or "{}")
        v = next((s for s in j.get("streams", []) if s.get("codec_type") == "video"), None)
        if v is None:
            raise SystemExit(f"no video stream in {path}")
        rot = 0
        for sd in v.get("side_data_list", []) or []:
            if "rotation" in sd:
                rot = int(sd["rotation"])
        rot = int(v.get("tags", {}).get("rotate", rot))
        rate = v.get("avg_frame_rate") or v.get("r_frame_rate") or "30/1"
        if rate in ("0/0", "0/1"):
            rate = v.get("r_frame_rate", "30/1")
        info = dict(w=int(v["width"]), h=int(v["height"]), rate=rate, rotation=rot,
                    duration=float(j.get("format", {}).get("duration") or v.get("duration") or 0),
                    trc=v.get("color_transfer", ""),
                    audio=any(s.get("codec_type") == "audio" for s in j.get("streams", [])))
    else:
        r = subprocess.run([ffmpeg(), "-hide_banner", "-i", path], capture_output=True, text=True)
        e = r.stderr
        m = re.search(r"Video: .*?(\d{2,5})x(\d{2,5})", e)
        if not m:
            raise SystemExit(f"no video stream in {path}")
        fr = re.search(r"([\d.]+) fps", e)
        d = re.search(r"Duration: (\d+):(\d+):([\d.]+)", e)
        rot = re.search(r"rotat(?:e|ion)\s*[:=]\s*(-?\d+)", e)
        info = dict(w=int(m.group(1)), h=int(m.group(2)), rate=str(Fraction(fr.group(1)).limit_denominator(1001))
                    if fr else "30/1", rotation=int(rot.group(1)) if rot else 0,
                    duration=(int(d.group(1)) * 3600 + int(d.group(2)) * 60 + float(d.group(3))) if d else 0.0,
                    trc="arib-std-b67" if "arib-std-b67" in e else "smpte2084" if "smpte2084" in e else "",
                    audio="Audio:" in e)
    if abs(info["rotation"]) % 180 == 90:
        info["w"], info["h"] = info["h"], info["w"]
    info["fps"] = float(Fraction(info["rate"]))
    info["transfer"] = "hlg" if "b67" in info["trc"] else "pq" if "2084" in info["trc"] else "sdr"
    return info


GRADES = {
    "none": "",
    # his room as shot: a touch of contrast and colour, no vignette, no skin shift
    "clean": "eq=contrast=1.05:saturation=1.07:gamma=0.99",
    "warm": "eq=contrast=1.05:saturation=1.08,colorbalance=rs=0.03:gs=0.0:bs=-0.03:rm=0.02:bm=-0.02",
    "punchy": "eq=contrast=1.09:saturation=1.12:gamma=0.98",
}


def tonemap_chain(transfer: str) -> str:
    if transfer == "sdr":
        return ""
    # HLG / PQ to SDR BT.709 (needs an ffmpeg with zimg; Homebrew's has it)
    return ("zscale=t=linear:npl=203,format=gbrpf32le,zscale=p=bt709,tonemap=hable:desat=0,"
            "zscale=t=bt709:m=bt709:r=tv,format=yuv420p,")


@functools.lru_cache(maxsize=1)
def has_zscale() -> bool:
    r = subprocess.run([ffmpeg(), "-hide_banner", "-filters"], capture_output=True, text=True)
    return " zscale " in r.stdout


def to_rgb() -> str:
    """The YUV -> RGB step. swscale's auto-conversion falls back to BT.601 and darkens HD footage (Y -2 on a bright
    room); zscale reads BT.709 correctly."""
    if has_zscale():
        return ",zscale=matrixin=709:rangein=limited:range=full,format=gbrp,format=rgb24"
    # swscale honours the input matrix only from a 4:4:4 source (measured: Y exact through yuv444p, -2.1 without)
    return ",format=yuv444p,scale=in_color_matrix=bt709:in_range=tv:out_range=pc,format=rgb24"


def decode_size(src_w, src_h, need_h):
    """Decode no bigger than needed: 1.5x the output height covers a x1.3 zoom with room to spare."""
    h = min(src_h, int(need_h * 1.5))
    h -= h % 2
    w = int(round(src_w * h / src_h))
    w -= w % 2
    return w, h


class Reader:
    """Streams n RGB frames of a file from source time t0, at fps, sped up by speed (1.0 = as shot)."""

    def __init__(self, path, t0, n, fps, size, speed=1.0, grade="clean", transfer="sdr"):
        self.size, self.n, self.i = size, n, 0
        vf = (tonemap_chain(transfer) +
              (f"setpts=(PTS-STARTPTS)/{speed}," if abs(speed - 1) > 1e-6 else "setpts=PTS-STARTPTS,") +
              f"fps={fps}:round=near,scale={size[0]}:{size[1]}:flags=bicubic")
        g = GRADES.get(grade, grade or "")
        if g:
            vf += "," + g
        vf += to_rgb()
        cmd = [ffmpeg(), "-v", "error", "-threads:v", str(ffmpeg_threads()), "-ss", f"{max(0.0, t0):.4f}", "-i", str(path),
               "-filter_threads", "1", "-an", "-vf", vf,
               "-frames:v", str(n), "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
        self.p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=size[0] * size[1] * 3)
        self.last = None

    def read(self) -> Image.Image:
        nb = self.size[0] * self.size[1] * 3
        if self.i < self.n:
            buf = self.p.stdout.read(nb)
            if len(buf) == nb:
                self.last = Image.frombuffer("RGB", self.size, buf, "raw", "RGB", 0, 1)
            self.i += 1
        if self.last is None:
            self.last = Image.new("RGB", self.size, (0, 0, 0))
        return self.last

    def close(self):
        try:
            self.p.stdout.close()
            self.p.kill()
            self.p.wait(timeout=2)
        except Exception:
            pass


def still(path, t, size=None, grade="clean", transfer="sdr") -> Image.Image:
    vf = tonemap_chain(transfer) + (f"scale={size[0]}:{size[1]}:flags=bicubic" if size else "null")
    g = GRADES.get(grade, grade or "")
    if g:
        vf += "," + g
    vf += to_rgb()
    r = subprocess.run([ffmpeg(), "-v", "error", "-threads:v", str(ffmpeg_threads()), "-ss", f"{max(0, t):.3f}",
                        "-i", str(path), "-filter_threads", "1", "-frames:v", "1",
                        "-vf", vf, "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True)
    if not r.stdout:
        info = probe(str(path))
        return Image.new("RGB", size or (info["w"], info["h"]), (0, 0, 0))
    import io
    return Image.open(io.BytesIO(r.stdout)).convert("RGB")


def load_audio(path, sr=48000, t0=0.0, dur=None) -> np.ndarray:
    """Float32 stereo (n, 2); zeros when the file has no audio."""
    cmd = [ffmpeg(), "-v", "error", "-ss", f"{t0:.4f}"]
    if dur is not None:
        cmd += ["-t", f"{dur:.4f}"]
    cmd += ["-i", str(path), "-vn", "-ac", "2", "-ar", str(sr), "-f", "f32le", "-"]
    r = subprocess.run(cmd, capture_output=True)
    a = np.frombuffer(r.stdout, np.float32)
    return a.reshape(-1, 2).copy() if a.size else np.zeros((0, 2), np.float32)


def write_wav(path, a: np.ndarray, sr=48000):
    import wave
    a = np.clip(a, -1, 1)
    pcm = (a * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(a.shape[1] if a.ndim == 2 else 1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def run(cmd, **kw):
    r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, **kw)
    if r.returncode != 0:
        raise SystemExit(f"command failed: {' '.join(map(str, cmd[:6]))} ...\n{r.stderr[-2000:]}")
    return r


def load_image(path) -> Image.Image:
    img = Image.open(Path(path))
    return img.convert("RGBA") if img.mode in ("RGBA", "LA", "P") else img.convert("RGB")
