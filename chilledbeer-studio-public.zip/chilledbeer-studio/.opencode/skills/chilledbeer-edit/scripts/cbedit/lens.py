"""The lens: where the picture of him is cropped, frame by frame.

It moves while he talks (the plan's per-beat `cam`), punches on stressed words, alternates the framing on every jump
cut (his liked punch-in jump cuts), keeps his face in the upper middle, and never magnifies the source past x1.3.
Face centres come from faces.json (`cbedit faces`); without it the centre is (0.5, 0.42).
"""
from __future__ import annotations

import bisect
import json
import math

from .core import clamp, expo_out, inout3, lerp, out3, smooth

CAM = {  # (start zoom, end zoom, x drift as a fraction of the crop width)
    "hold": (1.0, 1.0, 0.0), "push": (1.0, 1.09, 0.0), "pull": (1.09, 1.0, 0.0), "drift": (1.04, 1.06, 0.025),
    "arc": (1.03, 1.07, -0.03), "tight": (1.18, 1.22, 0.0), "punch": (1.0, 1.0, 0.0),
}
JUMP = 1.1          # the alternate framing on a jump cut
MAX_MAG = 1.3       # never magnify source pixels past this


class Faces:
    def __init__(self, path=None):
        self.d = {}
        if path and path.exists():
            j = json.loads(path.read_text())
            for k, rows in j.items():
                rows.sort()
                self.d[k] = ([r[0] for r in rows], rows)

    def view(self, src, t):
        """'cam' when his face is big in the frame, 'screen' for a screen recording (a webcam corner is small)."""
        if src not in self.d:
            return "cam"
        return "cam" if self.at(src, t)[2] >= 0.14 else "screen"

    def at(self, src, t):
        if src not in self.d:
            return 0.5, 0.42, 0.25
        ts, rows = self.d[src]
        i = bisect.bisect_left(ts, t)
        if i <= 0:
            return tuple(rows[0][1:4])
        if i >= len(ts):
            return tuple(rows[-1][1:4])
        a, b = rows[i - 1], rows[i]
        u = (t - a[0]) / max(1e-6, b[0] - a[0])
        return tuple(lerp(a[j], b[j], u) for j in (1, 2, 3))


def zoom_at(plan, beat, t, depth=0):
    """The lens zoom for him at output time t inside beat."""
    tl = t - beat["t0"]
    dur = max(0.01, beat["dur"])
    screen = beat["props"].get("view") == "screen"
    cam = beat.get("cam", ("push" if not screen else "hold") if beat["stage"] == "full" else "hold")
    z0, z1, _ = CAM.get(cam, CAM["hold"])
    z = lerp(z0, z1, inout3(tl / dur))
    # jump-cut framing: alternate on every join inside a beat that keeps him on screen
    if plan.j.get("jumpcut", True) and not screen and beat["stage"] not in ("takeover", "broll", "call"):
        k = plan.seg_at(t)
        first = plan.seg_at(beat["t0"] + 1e-3)
        if (k - first) % 2 == 1:
            z *= JUMP
    # jumps inside the beat: zoom steps on words ("Claude, Claude, Claude")
    jz = prev = 1.0
    for tj, zj in sorted((plan.T(j["at"]), float(j.get("z", 1.12))) for j in beat.get("jumps", [])):
        if t < tj:
            break
        jz, prev = lerp(prev, zj, expo_out((t - tj) / 0.05)), zj
    z *= jz
    # punches: eased in fast (0.09 s), held, eased out (0.45 s)
    for (tp, zp, hold) in ([] if screen else plan.punches):
        if tp - 0.1 <= t <= tp + hold + 0.5:
            if beat["t0"] - 0.01 <= tp < beat["t1"]:
                u = expo_out((t - tp + 0.03) / 0.09) if t < tp + hold else 1 - inout3((t - tp - hold) / 0.45)
                z *= lerp(1.0, zp, clamp(u))
    # continuity: a reveal starts on the framing the previous beat ended on; a dive lands on the next beat's
    if depth == 0:
        k = beat["k"]
        if beat["in"] == "reveal" and k > 0:
            zp = zoom_at(plan, plan.beats[k - 1], beat["t0"] - 1e-3, 1)
            z = lerp(zp, z, inout3(clamp((tl - 0.12) / 0.9)))
        if beat.get("out") == "dive" and k + 1 < len(plan.beats):
            zn = zoom_at(plan, plan.beats[k + 1], beat["t1"] + 1e-3, 1)
            z = lerp(z, zn, inout3(clamp((tl - (dur - 0.55)) / 0.55)))
    return z


def crop(plan, faces, beat, t, frame_size, rect_wh, src=None, src_t=None, zoom=None):
    """The crop box (l, t, r, b) in decoded-frame px for a screen rect of rect_wh (screen px)."""
    fw, fh = frame_size
    rw, rh = rect_wh
    A = rw / max(1e-6, rh)
    if A >= fw / fh:
        cw, ch = fw, fw / A
    else:
        cw, ch = fh * A, fh
    z = zoom if zoom is not None else zoom_at(plan, beat, t)
    # quality cap: source px may not be magnified past MAX_MAG
    if src is not None:
        src_h = plan.info[src]["h"]
        min_ch = rh * (fh / src_h) / MAX_MAG
        z = min(z, max(1.0, ch / max(1e-6, min_ch)))
    cw, ch = cw / z, ch / z
    fx, fy, fs = faces.at(src, src_t) if src is not None else (0.5, 0.42, 0.25)
    if beat["props"].get("view") == "screen":
        fx, fy = beat["props"].get("focus", [0.5, 0.38])
    cam = beat.get("cam", "push")
    drift = CAM.get(cam, CAM["hold"])[2] * cw * (smooth((t - beat["t0"]) / max(0.01, beat["dur"])) - 0.5)
    cx = clamp(fx * fw + drift, cw / 2, fw - cw / 2)
    cy = clamp(fy * fh + 0.12 * ch, ch / 2, fh - ch / 2)
    return (cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2), z


def detect_faces(plan, every=0.5):
    """faces.json: [t, cx, cy, size] per source (normalised), from OpenCV's frontal-face cascade when it is here."""
    try:
        import cv2
    except ImportError:
        print("faces: OpenCV not installed (pip install opencv-python-headless); using the default centre")
        return None
    cv2.setNumThreads(1)
    import numpy as np
    from .core import ROOT
    from .media import Reader
    yunet = ROOT / "assets" / "models" / "face_detection_yunet_2023mar.onnx"
    det = casc = None
    if hasattr(cv2, "FaceDetectorYN") and yunet.exists():
        det = cv2.FaceDetectorYN.create(str(yunet), "", (320, 320), 0.7, 0.3, 50)
    elif hasattr(cv2, "CascadeClassifier"):
        casc = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    else:
        print("faces: this OpenCV has no face detector; using the default centre")
        return None
    out = {}
    used = {}
    for s in plan.segs:
        used.setdefault(s["src"], []).append((s["a"], s["b"]))
    for src, spans in used.items():
        info = plan.info[src]
        w = 640
        h = int(round(info["h"] * w / info["w"])) // 2 * 2
        rows = []
        lo, hi = min(a for a, _ in spans), max(b for _, b in spans)
        n = int((hi - lo) / every) + 1
        rd = Reader(plan.sources[src], lo, n, 1 / every, (w, h), grade="none", transfer=info["transfer"])
        if det is not None:
            det.setInputSize((w, h))
        for i in range(n):
            frame = rd.read()
            if det is not None:
                _, fs = det.detect(cv2.cvtColor(np.asarray(frame), cv2.COLOR_RGB2BGR))
                fs = [] if fs is None else [tuple(r[:4]) for r in fs]
            else:
                fs = casc.detectMultiScale(np.asarray(frame.convert("L")), 1.1, 5, minSize=(w // 14, w // 14))
            if len(fs):
                x, y, fw_, fh_ = max(fs, key=lambda r: r[2] * r[3])
                rows.append([round(lo + i * every, 3), (x + fw_ / 2) / w, (y + fh_ / 2) / h, fh_ / h])
        rd.close()
        # median-smooth over 5 samples so the lens never chases a jittery box
        if rows:
            arr = np.array(rows)
            for c in (1, 2, 3):
                col = arr[:, c].copy()
                for i in range(len(col)):
                    arr[i, c] = np.median(col[max(0, i - 2):i + 3])
            out[src] = [[round(float(v), 4) for v in r] for r in arr]
        print(f"faces: {src}: {len(rows)} of {n} samples found a face")
    (plan.work / "faces.json").write_text(json.dumps(out))
    return out
