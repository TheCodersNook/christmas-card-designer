"""The edit plan (edit.json) and its timeline.

Times anywhere in the plan can be seconds on the OUTPUT timeline (12.4), a word id ("w123": when that word starts in
the cut), "w123.end" (when it ends), with an offset ("w123+0.2", "w123.end-0.1"), or "b:w12" for a word of source b.
Word ids survive a re-cut, so the plan never has to be re-timed by hand.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .media import probe

STAGES = {"full", "beside", "editor", "phone", "tv", "laptop", "browser", "call", "cinema", "polaroid", "post",
          "takeover", "broll"}
FACE = {"full": "on", "beside": "on", "editor": "on", "phone": "on", "tv": "on", "laptop": "on", "browser": "corner",
        "call": "on", "cinema": "on", "polaroid": "on", "post": "on", "takeover": "off", "broll": "off"}
TRANSITIONS = {"cut", "rise", "whip", "push", "zoom", "flash", "glitch", "iris", "fade", "reveal", "static"}
LOOKS = {
    "white": dict(page="#FFFFFF", grid="#F0F0EE", ink="#111111", muted="#6B6B6B", hair="#E4E4E1", card="#FFFFFF",
                  wall="#F2F1EE", floor="#E7E5E0"),
    "dark": dict(page="#0E0F12", grid="#181A1E", ink="#F4F4F2", muted="#9A9CA3", hair="#2A2C31", card="#17181C",
                 wall="#15161A", floor="#101114"),
    "paper": dict(page="#F2EBDD", grid="#E8DFCC", ink="#1B1A17", muted="#6E675B", hair="#DACDB5", card="#FFFDF8",
                  wall="#EFE6D6", floor="#E3D7C2"),
}


class Plan:
    def __init__(self, path, draft=False):
        self.path = Path(path).resolve()
        self.dir = self.path.parent
        self.j = json.loads(self.path.read_text())
        j = self.j
        self.work = self.dir / (j.get("work") or ".cbedit")
        self.work.mkdir(exist_ok=True)
        self.sources = {k: str(self._p(v)) for k, v in j["sources"].items()}
        self.main = next(iter(self.sources))
        self.info = {k: probe(v) for k, v in self.sources.items()}
        mi = self.info[self.main]
        fmt = j.get("format", "16:9")
        self.portrait = fmt in ("9:16", "portrait", "reel", "short")
        short = int(j.get("res", 1080))           # the short side: 1080 = 1920x1080 or 1080x1920; 2160 = 4K
        if draft:
            short = int(j.get("draft_res", 540))
        long_ = int(round(short * 16 / 9))
        self.W, self.H = (short, long_) if self.portrait else (long_, short)
        self.W -= self.W % 2
        self.H -= self.H % 2
        # the world every stage draws in is 1920x1080 (or 1080x1920); draft renders scale the world down
        self.WW, self.WH = (1080, 1920) if self.portrait else (1920, 1080)
        self.scale = self.W / self.WW
        self.rate = str(j.get("fps") or mi["rate"])
        from fractions import Fraction
        self.fps = float(Fraction(self.rate))
        if draft and self.fps > 31:
            self.rate, self.fps = "30", 30.0
        self.speed = float(j.get("speed", 1.0))
        self.look = LOOKS[j.get("look", "white")]
        self.look_name = j.get("look", "white")
        self.accent = j.get("accent", "#F0412B")
        self.grade = j.get("grade", "clean")
        self.handle = j.get("handle", "@yourhandle")
        self.long = not self.portrait and j.get("kind", "long") != "reel"
        self._load_words()
        self._load_cut()
        self._beats()

    def _p(self, v):
        p = Path(v).expanduser()
        return p if p.is_absolute() else (self.dir / p)

    # ---- words and cut ----------------------------------------------------------------------------------------------
    def _load_words(self):
        self.words = {}
        w = self.j.get("words")
        if isinstance(w, str):
            w = {self.main: w}
        for k, f in (w or {}).items():
            self.words[k] = json.loads(self._p(f).read_text())["words"]

    def _load_cut(self):
        c = self.j.get("cut")
        if isinstance(c, str):
            c = json.loads(self._p(c).read_text())
        segs = c["segments"] if isinstance(c, dict) else c
        if not segs:
            raise SystemExit("the plan has no cut: run `cbedit cut` or give segments")
        self.segs = []
        f = 0
        for s in segs:
            src = s.get("src", self.main)
            n = int(round((s["out"] - s["in"]) / self.speed * self.fps))
            if n <= 0:
                continue
            self.segs.append(dict(src=src, a=float(s["in"]), b=float(s["out"]), f0=f, n=n, w0=s.get("w0"),
                                  w1=s.get("w1")))
            f += n
        self.nframes = f
        self.duration = f / self.fps
        # word times on the output timeline
        self.wout = {}
        self.wlist = []
        for k, s in enumerate(self.segs):
            ws = self.words.get(s["src"])
            if not ws:
                continue
            t0 = s["f0"] / self.fps
            for w in ws:
                if w["s"] >= s["a"] - 0.02 and w["e"] <= s["b"] + 0.15 and w["s"] < s["b"]:
                    ts = t0 + (w["s"] - s["a"]) / self.speed
                    te = min(t0 + (w["e"] - s["a"]) / self.speed, (s["f0"] + s["n"]) / self.fps)
                    key = f"w{w['i']}" if s["src"] == self.main else f"{s['src']}:w{w['i']}"
                    if key not in self.wout:
                        self.wout[key] = (max(t0, ts), te)
                        self.wlist.append(dict(id=key, w=w["w"], s=max(t0, ts), e=te, seg=k))
        self.wlist.sort(key=lambda x: x["s"])
        # respellings: {"w59": "Claude"} fixes what whisper misheard (captions, type sync, the editor's labels)
        fix = self.j.get("respell", {})
        for w in self.wlist:
            if w["id"] in fix:
                w["w"] = fix[w["id"]]
        self.joins = [s["f0"] / self.fps for s in self.segs[1:]]

    def T(self, ref, default=None) -> float:
        if ref is None:
            return default
        if isinstance(ref, (int, float)):
            return float(ref)
        m = re.fullmatch(r"\s*((?:\w+:)?w\d+)(\.end)?\s*([+-]\s*[\d.]+)?\s*", str(ref))
        if not m:
            s = str(ref).strip().rstrip("s")
            return float(s)
        key, end, off = m.groups()
        if key not in self.wout:
            # a dropped word: the nearest kept word after it
            num = int(re.search(r"\d+", key).group())
            pre = key[: key.index("w")]
            cands = [k for k in self.wout if k.startswith(pre + "w") and int(k[len(pre) + 1:]) >= num]
            if not cands:
                raise SystemExit(f"word {key} is not in the cut")
            key = min(cands, key=lambda k: int(k[len(pre) + 1:]))
        t = self.wout[key][1 if end else 0]
        if off:
            t += float(off.replace(" ", ""))
        return t

    def seg_at(self, t):
        f = int(t * self.fps + 1e-6)
        lo, hi = 0, len(self.segs) - 1
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if self.segs[mid]["f0"] <= f:
                lo = mid
            else:
                hi = mid - 1
        return lo

    def src_time(self, t):
        k = self.seg_at(t)
        s = self.segs[k]
        return s["src"], s["a"] + (t - s["f0"] / self.fps) * self.speed, k

    def words_between(self, a, b):
        return [w for w in self.wlist if a - 0.01 <= w["s"] < b]

    # ---- beats -------------------------------------------------------------------------------------------------------
    def _beats(self):
        bs = []
        for i, b in enumerate(self.j.get("beats", [])):
            st = b.get("stage", "full")
            if st not in STAGES:
                raise SystemExit(f"beat {i}: unknown stage '{st}' (stages: {', '.join(sorted(STAGES))})")
            tin = b.get("in", "cut")
            if tin not in TRANSITIONS:
                raise SystemExit(f"beat {i}: unknown transition '{tin}' (kinds: {', '.join(sorted(TRANSITIONS))})")
            bs.append(dict(b, i=i, stage=st, t0=self.T(b.get("at", 0.0)), props=b.get("props", {}), **{"in": tin}))
        if not bs:
            bs = [dict(i=0, stage="full", t0=0.0, props={}, **{"in": "cut"})]
        bs.sort(key=lambda b: b["t0"])
        bs[0]["t0"] = 0.0
        for k, b in enumerate(bs):
            b["k"] = k
        for a, b in zip(bs, bs[1:] + [None]):
            a["t1"] = b["t0"] if b else self.duration
            a["dur"] = a["t1"] - a["t0"]
        self.beats = bs
        self.punches = sorted(self._punches())

    def _punches(self):
        out = []
        for p in self.j.get("punch", []):
            if isinstance(p, dict):
                out.append((self.T(p["at"]), float(p.get("z", 1.15)), float(p.get("hold", 0.9))))
            else:
                out.append((self.T(p), 1.15, 0.9))
        return out

    def beat_at(self, t):
        for b in self.beats:
            if b["t0"] <= t < b["t1"]:
                return b
        return self.beats[-1]

    def face_kind(self, b):
        if b.get("props", {}).get("view") == "screen":
            return "screen"
        if b["stage"] == "takeover" and b["props"].get("pip"):
            return "corner"
        if b.get("props", {}).get("clip"):
            return "off"
        return FACE[b["stage"]]
