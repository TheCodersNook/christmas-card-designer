"""Conservative resource limits for a responsive editing machine.

These limits bound the work this engine schedules. They leave headroom below
75% of the logical CPUs; macOS does not offer an exact per-process GPU-percent
limit, so transcription and rendering use CPU paths by default.
"""
from __future__ import annotations

import os


def apply_cpu_affinity() -> None:
    """On Linux/WSL, reserve at least a quarter of available CPUs for other apps.

    Child processes inherit this affinity. macOS has no equivalent affinity API,
    so its worker and thread budgets remain best-effort limits.
    """
    if not hasattr(os, "sched_getaffinity"):
        return
    available = sorted(os.sched_getaffinity(0))
    if len(available) <= 1:
        return
    count = max(1, int(len(available) * 0.75))
    try:
        os.sched_setaffinity(0, available[:count])
    except OSError:
        # Some restricted Linux environments disallow affinity changes.
        # The worker and thread budgets still apply.
        pass


def cpu_budget() -> int:
    """Maximum logical CPUs the engine may plan to occupy (75% of total)."""
    available = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else (os.cpu_count() or 1)
    return max(1, min(available, int((os.cpu_count() or 1) * 0.75)))


def ffmpeg_threads() -> int:
    """One decoder or encoder thread per render worker."""
    return 1


def render_workers(height: int) -> int:
    """Fast parallelism with CPU and RAM headroom for other applications.

    A seven-worker 1080p render on this 15-core Mac measured about 14 cores and
    10 GiB RSS. Budget two busy logical CPUs and 1.5 GiB per 1080p worker,
    reserve one CPU within the 75% budget, and estimate more RAM at higher
    resolutions. These are scheduling estimates, not an OS utilization quota.
    """
    cpu_limit = max(1, (cpu_budget() - 1) // 2)
    try:
        ram_gib = os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE") / 2**30
    except (ValueError, OSError, AttributeError):
        ram_gib = 8.0  # conservative fallback
    if height >= 2160:
        per_worker_gib, hard_limit = 4.5, 2
    elif height >= 1440:
        per_worker_gib, hard_limit = 2.5, 3
    else:
        per_worker_gib, hard_limit = 1.5, 5
    memory_limit = max(1, int((ram_gib * 0.40) / per_worker_gib))
    return min(cpu_limit, memory_limit, hard_limit)


def choose_render_workers(height: int, requested: int | None = None) -> int:
    """Honour a smaller request while clamping old plans with excessive workers."""
    safe_limit = render_workers(height)
    return safe_limit if requested is None else max(1, min(int(requested), safe_limit))


def whisper_threads() -> int:
    """CPU threads for the single transcription job."""
    return max(1, min(4, cpu_budget() - 1))
