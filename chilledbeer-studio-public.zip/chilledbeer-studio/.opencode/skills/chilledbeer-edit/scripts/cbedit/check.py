"""The plan gate: the style rules as numbers, checked before anything renders.

ERRORS stop the render; WARNINGS are fixed or answered. It also lists CONTEXT OPPORTUNITIES: lines where he names a
thing (an editor, a phone, a TV, a website, a call, a film, a photo, a post) and the beat on that line does not put him
inside it.
"""
from __future__ import annotations

import re
from collections import defaultdict

from .motion import DUR
from .typeset import norm

CONTEXT = {
    "editor": r"edit|editing|editor|premiere|final cut|davinci|capcut|timeline|cut(ting)? (my|the|your) video|footage",
    "phone": r"phone|mobile|instagram|reel|reels|whatsapp|app\b|apps\b|notification|scroll|swipe|story|stories",
    "tv": r"\btv\b|television|news|channel|breaking|netflix series|cricket match|ipl",
    "laptop": r"laptop|computer|macbook|desktop|code|coding|vs ?code|terminal|claude code|cursor",
    "browser": r"website|site\b|github|repo\b|web ?page|browser|search|link|blog",
    "call": r"interview|calls?\b|meeting|zoom call|google meet|recruiter|hr\b|interviewer",
    "cinema": r"movie|film|cinema|theatre|theater|bollywood|trailer|netflix",
    "polaroid": r"photo|picture|memory|memories|childhood|old days|college days|throwback|years ago",
    "post": r"viral|views|likes|followers|subscribers|post(ed)?|comment(s)?|tweet",
}
CONTEXT_RX = {k: re.compile(r"\b(?:%s)" % v) for k, v in CONTEXT.items()}
FACE_STAGES = {"full", "beside", "editor", "phone", "tv", "laptop", "call", "cinema", "polaroid", "post"}


def check(plan):
    E, W, I = [], [], []
    bs = plan.beats
    reel = plan.portrait or not plan.long
    dur = plan.duration
    fmt = lambda t: f"{int(t // 60)}:{t % 60:05.2f}"

    # ---- the hook: his face from frame 1, movement by 0.5 s (Reels) ---------------------------------------------------
    b0 = bs[0]
    on = 0.0
    for b in bs:
        if plan.face_kind(b) not in ("on", "screen") or (b["k"] == 0 and plan.face_kind(b) == "screen"):
            break
        on = b["t1"]
    if b0["stage"] not in ("full", "beside") or on < min(3.0, dur):
        E.append(f"hook: the first 3 s must be on his face, opening full or beside (beat 0 is '{b0['stage']}', "
                 f"face on until {on:.1f}s)")
    early = [p for p, _, _ in plan.punches if p < 1.0] + [e["_t0"] for e in plan.j.get("type", []) if e["_t0"] < 1.0]
    early += [t for t in plan.joins if t < 1.0]
    early += [plan.T(j["at"]) for b in bs for j in b.get("jumps", []) if plan.T(j["at"]) < 1.0]
    if reel and not early:
        W.append("hook: nothing moves in the first second (a punch, a slam or a jump cut by ~0.5 s)")

    # ---- cadence: a visible change every 1.5-3 s (Reels) / 3-6 s (long-form) -------------------------------------------
    moves = [(b["t0"] + b["t1"]) / 2 for b in bs if b.get("cam") in ("push", "pull", "drift", "arc", "tight")
             and b["dur"] > 4]
    ev = sorted(set([b["t0"] for b in bs] + moves + [p for p, _, _ in plan.punches] + list(plan.joins)
                    + [e["_t0"] for e in plan.j.get("type", [])]
                    + [plan.T(j["at"]) for b in bs for j in b.get("jumps", [])]))
    ev = [0.0] + [t for t in ev if 0 < t < dur] + [dur]
    lim_w, lim_e = (3.0, 4.5) if reel else (6.0, 10.0)
    for a, b in zip(ev, ev[1:]):
        if b - a > lim_e:
            E.append(f"still: nothing changes for {b - a:.1f}s at {fmt(a)} (limit {lim_e:g}s)")
        elif b - a > lim_w:
            W.append(f"still: {b - a:.1f}s with no change at {fmt(a)} (aim under {lim_w:g}s)")

    # ---- layout share and rhythm ---------------------------------------------------------------------------------------
    share = defaultdict(float)
    for b in bs:
        share["screen" if plan.face_kind(b) == "screen" else b["stage"]] += b["dur"]
    for st, s in sorted(share.items(), key=lambda x: -x[1]):
        I.append(f"layout {st:9s} {100 * s / dur:5.1f}%")
        if s / dur > 0.35 and len(bs) > 2 and st != "screen":     # a screen demo may run long: it is the evidence
            (E if s / dur > 0.5 else W).append(f"layout: '{st}' covers {100 * s / dur:.0f}% (max 35%)")
    lay = lambda b: b["stage"] + ("/" + str(b["props"].get("focus")) if plan.face_kind(b) == "screen" else "")
    for i in range(2, len(bs)):
        if lay(bs[i]) == lay(bs[i - 1]) == lay(bs[i - 2]):
            W.append(f"rhythm: '{bs[i]['stage']}' three beats in a row at {fmt(bs[i - 2]['t0'])}")
    kinds = {b["stage"] for b in bs}
    need = 4 if reel else min(6, max(3, int(dur / 60 * 1.5)))
    if len(kinds) < need:
        W.append(f"variety: {len(kinds)} distinct stages; aim for {need}+ ({', '.join(sorted(kinds))})")
    if not any(s in kinds for s in ("editor", "phone", "tv", "laptop", "browser", "call", "cinema", "polaroid", "post")):
        W.append("context: no context stage at all; put him inside the thing he talks about at least once")

    # ---- time away from his face -------------------------------------------------------------------------------------
    away, run = 0.0, 0.0
    for b in bs:
        if plan.face_kind(b) == "screen":
            run = 0.0
            continue
        if plan.face_kind(b) == "off":
            run += b["dur"]
            away += b["dur"]
            if run > 12:
                E.append(f"away: off his face for {run:.1f}s at {fmt(b['t0'])} (max 12s)")
            if b["stage"] == "takeover" and not 2.0 <= b["dur"] <= 12:
                W.append(f"takeover at {fmt(b['t0'])} is {b['dur']:.1f}s (4-12s on long-form, 2-8s on Reels)")
        else:
            run = 0.0
    if not reel and dur > 90 and not 0.12 <= away / dur <= 0.32:
        W.append(f"away: takeovers/B-roll are {100 * away / dur:.0f}% of the film (aim 15-30%)")

    # ---- transitions -------------------------------------------------------------------------------------------------
    ins = [b["in"] for b in bs[1:]]
    for i in range(1, len(ins)):
        if ins[i] == ins[i - 1] and ins[i] not in ("cut",):
            W.append(f"transition: '{ins[i]}' twice in a row at {fmt(bs[i + 1]['t0'])}")
    if ins and ins.count("whip") / len(ins) > 0.4:
        W.append(f"transition: whips are {100 * ins.count('whip') / len(ins):.0f}% (max 40%)")
    for b in bs:
        if b["in"] == "reveal":
            prev = bs[b["k"] - 1] if b["k"] else None
            if not b.get("_screen_ok", True) or (prev and prev["stage"] not in ("full", "broll")):
                W.append(f"reveal at {fmt(b['t0'])}: reveal works best straight out of a full-frame beat")
        if b.get("out") == "dive":
            nxt = bs[b["k"] + 1] if b["k"] + 1 < len(bs) else None
            if nxt and (nxt["stage"] != "full" or nxt["in"] != "cut"):
                W.append(f"dive at {fmt(b['t1'])}: the next beat should be 'full' with in 'cut' (seamless)")
        if b["dur"] < max(0.8, DUR.get(b["in"], 0) + 0.3):
            W.append(f"beat at {fmt(b['t0'])} is only {b['dur']:.2f}s")

    # ---- punches -----------------------------------------------------------------------------------------------------
    ps = [p for p, _, _ in plan.punches]
    gap = 3.0 if reel else 5.0
    for a, b in zip(ps, ps[1:]):
        if b - a < gap:
            W.append(f"punch: two punches {b - a:.1f}s apart at {fmt(a)} (keep ~{gap:g}s+)")

    # ---- type --------------------------------------------------------------------------------------------------------
    for e in plan.j.get("type", []):
        n = len(e.get("text", "").replace("*", "").split())
        if e.get("style") in ("slam", "pop", "kicker") and n > 6:
            W.append(f"type at {fmt(e['_t0'])}: '{e['text']}' has {n} words (6 or fewer)")
        b = plan.beat_at(e["_t0"])
        if e.get("style") != "sub" and b["stage"] == "takeover":
            W.append(f"type at {fmt(e['_t0'])} sits on a takeover (one idea per frame)")

    # ---- text over his face on full frame (measured, so a model without eyes can trust it) -----------------------------
    try:
        from .lens import Faces, crop
        from .typeset import resolve_pos
        from .core import font
        faces = Faces(plan.work / "faces.json")
        if faces.d:
            for e in plan.j.get("type", []):
                b = plan.beat_at(e["_t0"] + 0.05)
                if b["stage"] != "full" or e.get("style") == "sub":
                    continue
                src, st, _ = plan.src_time(e["_t0"] + 0.05)
                fx, fy, fs = faces.at(src, st)
                info = plan.info[src]
                fw, fh = info["w"], info["h"]
                box, _ = crop(plan, faces, b, e["_t0"] + 0.05, (fw, fh), (plan.WW, plan.WH), src, st)
                kx, ky = plan.WW / (box[2] - box[0]), plan.WH / (box[3] - box[1])
                cx, cy = (fx * fw - box[0]) * kx, (fy * fh - box[1]) * ky
                half = fs * fh * ky * 0.75
                x, y = resolve_pos(plan, e, b, (fx, fy, fs))
                size = float(e.get("size", {"slam": 128, "pop": 54}.get(e.get("style", "pop"), 70)))
                tw = min(font("display", size).getlength(e.get("text", "")), plan.WW * 0.38) / 2
                th = size * 0.6 * (2 if font("display", size).getlength(e.get("text", "")) > plan.WW * 0.38 else 1)
                if abs(x - cx) < tw + half * 0.8 and abs(y - cy) < th + half:
                    W.append(f"type '{e.get('text')}' at {fmt(e['_t0'])} covers his face: set \"pos\": "
                             f"\"{'right' if cx < plan.WW / 2 else 'left'}\" or \"top\"")
    except Exception as ex:  # the lint never blocks a render
        I.append(f"face lint skipped: {ex}")

    # ---- context: each context stage must sit on a line that names its thing, and the missed ones ----------------------
    for b in bs:
        if b["stage"] in CONTEXT:
            said = " ".join(w["w"] for w in plan.words_between(b["t0"] - 1.0, b["t1"]))
            why = b.get("why", "")
            if not why:
                W.append(f"context: the {b['stage']} beat at {fmt(b['t0'])} has no 'why' (quote his line)")
            elif norm(why.split()[0]) and not any(norm(x) in norm(said) for x in re.findall(r"[\w']+", why)[:3]):
                W.append(f"context: the {b['stage']} beat's why '{why}' is not in what he says there: '{said[:80]}'")
    ops = []
    text_by_t = [(w["s"], w["w"]) for w in plan.wlist]
    for st, rx in CONTEXT.items():
        for s, w in text_by_t:
            window = " ".join(x for t, x in text_by_t if s - 0.01 <= t <= s + 1.2).lower()
            if CONTEXT_RX[st].match(window):
                b = plan.beat_at(s)
                if b["stage"] != st:
                    ops.append((s, st, window[:60]))
    seen = set()
    for s, st, txt in ops:
        key = (st, int(s // 6))
        if key in seen:
            continue
        seen.add(key)
        I.append(f"opportunity {fmt(s)}  {st:8s} \"{txt}\"")
    return E, W, I


def report(plan):
    E, W, I = check(plan)
    for x in I:
        print("  " + x)
    for x in W:
        print("WARN  " + x)
    for x in E:
        print("ERROR " + x)
    print(f"check: {len(E)} errors, {len(W)} warnings  ({plan.duration:.1f}s, {len(plan.beats)} beats)")
    return len(E)
