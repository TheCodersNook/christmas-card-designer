---
name: chilledbeer-edit
description: The ChilledBeer (@ChilledBeer on YouTube) video-editing style as one self-contained skill. It turns his raw talking-head take into a fast, finished YouTube video or Instagram Reel / YouTube Short with fast punch-ins and jump cuts, varied transitions, kinetic type on his words, takeovers, and the signature move of putting him INSIDE what he talks about (a video editor while he talks about editing, a TV for news, a phone for Reels or DMs, a laptop or browser for code and sites, a call grid for interviews, a cinema, a polaroid, a social post). It has its own render engine (Python + ffmpeg, runs anywhere), so it works outside Claude Code too. Use it whenever he gives a video and asks to edit it, cut it, make a reel/short/YouTube video, "make it killer", "fast paced", "my style", "edit like my channel", or names this skill, in any environment. Shared by @ChilledBeer.
---

# chilledbeer-edit: the ChilledBeer style, end to end

> In this skill, "he" and "him" mean the creator on camera: the style is @ChilledBeer's, the footage is yours.

The video is his voice and his face. Everything else is there to make the next second more interesting than leaving.
This skill holds his taste (his rules and what he has said about past edits) and an engine that renders it. With this
skill alone, a raw take becomes a finished, posting-quality video.

**Read before the first edit in a session:** `reference/STYLE.md` (his taste and why), `reference/STAGES.md` (every
stage, its props and when to use it) and `reference/PLAN.md` (the edit.json schema with a worked example).

**Resource ceiling:** keep editing below 75% of CPU and GPU use so other work stays responsive. This engine defaults
to a CPU-, memory- and resolution-aware worker limit (up to five at 1080p, two at 4K on a 15-core, 24 GB Mac), bounded FFmpeg threads and CPU-only
Whisper transcription (`--no-gpu`); never bypass the worker cap or
enable GPU for a routine edit. On macOS these settings reduce scheduled load but are not an exact percentage quota.

## Never break these (his own rules)

1. **Whole sentences only.** Never cut mid-sentence or splice half-sentences. Trim pauses, restarts and asides freely.
   Cut edges sit in real quiet (the engine finds them on the voice envelope, not on whisper's word times).
2. **Him: full frame in his room as shot, or inside a closed shape** (card, circle, a device screen). Never a
   cut-out on a backdrop. No background blur, whitening or replacement of his room. The grade stays light.
3. **The hook opens on his face**: the first 3 s are on him, the stakes said or shown by ~3 s, movement by 0.5 s on
   a Reel. Never a logo, title card or slow fade-in first.
4. **Fast but readable.** A visible change every 1.5-3 s on a Reel and every 3-6 s on long-form: a beat, a jump cut,
   a punch, a type landing. Nothing still for 10 s ever. He is never away from the camera for more than 12 s.
5. **One idea per frame.** At most 3 things on screen beside him. Type has 6 words or fewer and lands on the word he
   says. Captions go only where they help: full captions on Reels; on long-form, only English subtitles for Hinglish
   lines and the punchlines.
6. **Put him inside the thing he talks about** (the context rule below). Each context stage needs a `why` that
   quotes his line.
7. **No invented facts or numbers.** A number on screen is one he said, or it is labelled an illustration. Mock-up
   UIs are generic, with no real logos. When he names a real product, show the real thing: its real page or
   screenshot, which he gives you or you capture.
8. **Quality never drops.** Keep the source frame rate (a 60 fps take renders at 60), keep the zoom at ×1.3 or less
   of the source pixels (the engine caps it), use one encode, and keep the colours exact (BT.709 end to end).
9. **Sound:**
   - his voice first, mastered to -14 LUFS;
   - a music bed about 18 dB under him on long-form (calm lo-fi or piano, no EDM or rock, no drops);
   - about 12 dB under on Reels;
   - the bed ducks on his voice and lifts in his pauses;
   - SFX on transitions and landings that mean something, at most 8 a minute on long-form and 12 on a Reel.
10. **Reels stand alone:** a complete mini-talk with no end screen. The exception is a ~2.5 s "full video on YouTube"
    card when a long video goes with it. On-screen handles come from `"handle"` in edit.json: set your own.

## The context rule (his signature)

When he names a thing, the frame becomes that thing, with him inside it, on that line:

| He talks about | Stage | Typical props |
|---|---|---|
| editing, a timeline, cutting a video, "my edits" | `editor` (in: `reveal` from his full frame) | razor on his punch words (auto), `project`, `files` |
| Reels, Instagram, an app, DMs, notifications, scrolling | `phone` | `notif {at, app, title, text}`, `like`, `content` beside it |
| news, a launch, TV, a channel, "breaking" | `tv` (`style: "retro"` for nostalgia) | `live`, `ticker`, `ticker_label`, `static` |
| code, his computer, a tool on the desktop, a meeting on his laptop | `laptop` | `app: player / call / page`, `url` |
| a website, a repo, a blog, a search, a doc | `browser` (the real screenshot, scrolled, his line marked; him in a corner circle) | `image`, `scroll`, `mark`, `url` |
| an interview, a call, a recruiter, an AI interviewer | `call` | `others [{name, kind: orb / avatar}]`, `title` |
| a movie, a trailer, "cinematic", Netflix | `cinema` | none |
| a memory, a photo, his college days, "years ago" | `polaroid` | `caption` (handwritten) |
| going viral, views, likes, a post, comments | `post` | `likes [from, to]`, `like`, `caption` |

`python -m cbedit check` lists every **opportunity**: a line that names one of these while the beat shows something
else. Take the strong ones (aim for 1 context stage every 15-25 s, never two of the same in a row). Each stage is
generic (no real brand marks); the real product appears as its real screenshot in `browser` or `beside`.

## The rest of the vocabulary

- `full`: his room as shot. The lens moves on him: a push or pull across a thought, an alternate framing on every
  jump cut, punches (×1.12-1.18) on stressed words, `jumps` (zoom steps on repeated words: "Claude, Claude,
  Claude"). With `insert`, a picture sits on a wall or board of his room and stays there as the camera moves.
- `beside`: him in a card or circle beside ONE idea (`content`: a statement, points landing on his words, a number
  counting up, a screenshot with a mark, a logo).
- `takeover`: he is off screen and one idea owns the frame (statement, number, list, compare, image, chapter). Use
  it where a passage shows a thing: a process, a proof, a contrast, a count. A takeover lasts 4-12 s and takes 15-30 %
  of a long-form film; on a Reel, 2-8 s each.
- `broll`: another clip full screen while his voice carries on (2-5 s, motivated by the line).

**Transitions mean something.** Never the same kind twice in a row (cuts may repeat), whips at most 40 %:
- `cut`: the thought continues;
- `whip`: on to the next thing;
- `push`: a side-by-side change;
- `zoom`: a dive into the detail;
- `reveal`: pull out from his face into a device;
- `out: "dive"`: push back into his face;
- `rise`: a device enters;
- `flash`: the reveal or punchline hit;
- `glitch` / `static`: a screen or TV world;
- `iris`: open on a new scene;
- `fade`: the soft return after a takeover.

## The fast path: the automatic director

`python -m cbedit make take.mp4 [--reel] [--music <dir with long/ and reel/>] [--draft]` does the whole edit in one go:
- transcribes the take;
- tidies the cut (it drops restarts, lone "right?" asides and a trailing fragment);
- writes a gate-clean plan with `auto`: hook, context stages from his words, rotating framings within the budgets,
  takeovers, punches, type, transitions and music;
- treats screen-recording stretches calmly (whole screen, tight reads, the laptop);
- draws the stills, renders, and runs QA.

`auto_report.md` lists the decisions and what is left: spellings to `respell`, Hinglish lines to subtitle, real
screenshots to add. To find word ids, run `python -m cbedit words edit.json --find <text>`.

**How to use it:** run `make` (or `auto`), fix the spellings and drops, re-run `auto --no-recut` once, do the report's
to-do list, then refine by hand with the director's eye in the run below. After hand edits, never run `auto` again (it
rewrites `beats`, `type` and `punch`); change the cut with `cut` (word ids keep the plan valid).

The OpenCode project `chilledbeer-studio` (this skill's home folder) wraps this for cheaper models: an `AGENTS.md` workflow,
`/edit` `/reel` `/fix` commands, and `./cb start` / `./cb wait` for jobs longer than a tool timeout.

## The run (gates in order)

Set up once per machine (see "Where it runs"), then from `scripts/` (or with `PYTHONPATH=<skill>/scripts`):

1. **Ingest:** `python -m cbedit init take.mp4 --dir edits/<name> [--reel]`. This transcribes, cuts on the quiet
   (whole sentences) and writes `words.json`, `cut.json`, `edit.json` and `script.txt`. For a Hinglish take, keep
   `--lang en` (it romanises well). If the take is already transcribed, pass `--transcript words.json|subs.srt`.
2. **The cut:** read `script.txt`, one line per sentence with its output time and word ids. Drop whole sentences
   only: restarts (keep the LAST full take of a repeated line), asides, "right?" fillers and dead ends. Run
   `python -m cbedit cut edit.json --drop 1,6 [--drop-words 120,121] [--start s --end s] [--pause 0.3]`. Fix whisper's
   mishearings in `respell` (`{"w59": "Claude"}`). Chatty takes: set `"speed": 1.04-1.06` (his "fast paced me").
   Never trim his intro's substance; drop only restarts.
3. **The director's plan, before any picture** (write it down and show him a summary):
   - **Hook:** write 3 candidate openings, score them (stakes by 3 s, an open loop, movement by 0.5 s) and pick one.
   - **Beats:** one per thought, each with `at` (a word id), `stage`, `in`, `cam` and `why` (his words). Run the
     opportunity list from `check`. Mark the 2-3 **hero moments** (the reveal, the number, the punchline): each gets
     a slam, a flash or a takeover, and a sound.
   - **Rhythm string:** for example `FULL · EDITOR · BESIDE · PHONE · TAKEOVER · FULL · TV · FULL`. No layout over
     35 %, never three in a row, at least 4 kinds in a Reel and 6+ in a long video.
   - **Punches:** stressed words only, 3 s+ apart on a Reel and 5 s+ apart on long-form.
   - **Type:** slams for punchlines, pops for keywords, subtitles for Hinglish, a count for numbers he says.
   - **Music:** the bed file and where it goes quiet (`music.quiet`) for a confession or a punchline.
4. **Gate:** `python -m cbedit faces edit.json` (once), then `python -m cbedit check edit.json` until it shows 0
   errors. Fix each warning, or say why you kept it.
5. **Look before rendering:** `python -m cbedit stills edit.json --at <the middle of every beat, every transition,
   every type event>`. Open the sheet and check:
   - text over his face;
   - text under 32 px at 1080p;
   - empty plates;
   - a stage that doesn't match his line;
   - a cramped layout.

   Fix it, then look again.
6. **Draft:** `python -m cbedit render edit.json --draft` (540p and fast). Pull frames around every transition from
   the draft (`ffmpeg ... select=between(t,a,b)` into a tile) and look at the motion. If he is waiting, send him a
   ~15 s piece of the hook plus one typical middle beat before building the rest.
7. **Final:** `python -m cbedit render edit.json` (1080p at the source fps; set `"res": 2160` for a 4K long-form
   when the take is 4K). Then `python -m cbedit qa out/<name>.mp4 --sheet out/sheet.jpg`: loudness, black and frozen
   stretches, and a contact sheet to look at.
8. **Deliver:** the file, a beat sheet (time, stage, why) and anything still open (a screenshot to capture, a line
   to re-record). For YouTube also give the title, description (chapters, credits, music credits) and tags. Give
   the thumbnail a prompt for him to generate in ChatGPT, with his real face (a big expression, 2-4 words, one
   object).

## Where it runs

- **In the chilledbeer-studio project:** run everything through `./cb` (it brings its own Python environment; see
  its README for Mac and Windows/WSL setup).
- **Claude Code or any terminal:** from this skill's `scripts/` folder, `uv run --with numpy --with pillow --with
  opencv-python-headless python -m cbedit ...` (add `--with faster-whisper` to transcribe without whisper.cpp).
- **claude.ai, Cowork or any other sandbox:** run `pip install numpy pillow imageio-ffmpeg` (plus `faster-whisper`
  for transcription, and `opencv-python-headless` for the face-centred lens). `python -m cbedit doctor` says what is
  missing. With no transcriber, ask him for the captions file (YouTube or CapCut export, `.srt`) and use
  `--transcript`. Uploads are size-limited, so ask for a 1080p export of the take if the original is huge.
- **Speed:** the resource-safe parallel render is slower than the former unconstrained version. Use the draft first,
  and keep heavy renders to one at a time. Do not promise a fixed render time without measuring this configuration.

## When he gives feedback

Fix the edit first. If the note is a lasting preference ("always...", "never..."), add it to `reference/STYLE.md`
under "His notes" with the date, so it holds in every future edit. When a new kind of scene comes up (a context he
names that no stage covers), build it as a new stage in `scripts/cbedit/stages.py` in the same grammar, and add it to
STAGES.md and the context table above.

