# Stages: every scene the engine draws

A beat is `{"at": "<word id or s>", "stage": "<name>", "in": "<transition>", "cam": "<lens move>", "out": "dive"?,
"why": "<his words>", "props": {...}, "jumps": [...]}`. It runs until the next beat's `at`.

These props work on every stage where he appears:
- `clip`: a B-roll file (or `{"file", "from"}`) shown on that stage's screen in place of him. He is then "away".
- `reveal_hold` / `reveal_dur` / `dive_dur`: the timing of the camera moves.

`cam` (the lens on him) takes these values:
- `push` (the default on `full`): +9 % across the beat;
- `pull`;
- `hold` (the default elsewhere);
- `drift`: a slow sideways slide;
- `arc`;
- `tight`: a close framing at ×1.2.

On top of `cam`:
- Jump cuts alternate the framing (1.0 / 1.1) on every join, except on `takeover`, `broll` and `call`.
- Punches come from the plan's top-level `punch`.
- `jumps: [{"at": "w12", "z": 1.13}, {"at": "w13", "z": 1.26}]` are absolute zoom steps.

All sizes below are in world px: 1920x1080 for 16:9, 1080x1920 for 9:16. Each stage has a portrait layout.

## full: his room as shot
- `insert`: `{"image", "quad": [[x, y] x4 as fractions of the SOURCE frame: tl, tr, br, bl], "at", "until",
  "opacity"}`. A picture (a website, a logo, a chart) projected on a wall, a whiteboard or a screen in his room. It
  flips in and rides the lens crop, so it stays on the surface while the camera moves. Find the quad on a still
  (`stills --at`).
- Use it for the hook, opinions, jokes and reactions. Keep it under ~35 % of the runtime and never run it as the
  whole film.

## beside: him in a shape plus one idea
- `shape`: `card` | `circle`.
- `side`: `left` (him on the left, the default) | `right`.
- `content` (one of the following):
  - `{"kind": "text", "text": "My exact workflow, *open-sourced.*", "kicker": "on github", "sub", "size", "at"}`: the
    words land as he says them, and the *starred* words take the accent with an underline.
  - `{"kind": "points", "title", "items": [["text", "w57"], ...]}`: each item lands on its word.
  - `{"kind": "number", "value": "1.9/5", "from": 0, "label", "ring": 0.38, "at", "dur"}`: a count-up, with an
    optional ring.
  - `{"kind": "image", "file", "mark": [x, y, w, h] (image px), "mark_at", "caption"}`: a screenshot with a
    highlighter on the line he means.
  - `{"kind": "logo", "file", "name", "height"}`: a real product's real logo.

## editor: him inside a video editor (dark NLE)
- A program monitor with him (the lens applies).
- An inspector whose **Scale and Position follow the lens live**; the Scale row lights up on a punch.
- A timeline whose V1 clips are the **real cuts** of this edit (thumbnails from his take, labels from his words),
  A1 his **real voice waveform**, A2 the music bed, and V2 the plan's type events as title clips.
- A playhead and timecode in sync.
- A cursor that picks the razor and **splits the clip on his punch words** (`razor: "auto"` | `[word ids]` | `[]`).
- `project`: the title-bar text. `files`: the 6 media-bin names.
- Best entered with `in: "reveal"` straight out of a `full` beat (the camera pulls out from his face into the
  monitor). `out: "dive"` pushes back into his face; the next beat is `full` with `in: "cut"`.

## phone: him on a phone
- A generic Reels UI: the handle (`handle`, default @yourhandle), `likes` (a string, or `[from, to]` to count
  up), `comments`, `shares`, `caption`, `audio` and `tab`.
- `like`: a word id for a double-tap heart, with a pop.
- `notif`: `{"at", "until", "app", "title", "text", "color"}`, a banner that slides down. Write a real-sounding DM:
  his viewers' question, in their words.
- `x`: the phone's centre (0-1). At `x: 0.32`, `content` (any `beside` block) fills the free side.
- `ui`: `none` for a clean screen.

## tv: him on a TV in a room
- The modern TV sits on a cabinet with a plant and a framed print. Its options:
  - `live: true`: a blinking LIVE badge;
  - `ticker`: scrolling news text, with `ticker_label` (default BREAKING);
  - `static`: channel static on entry (the default after a `cut` or `rise`). A `static` transition adds the sound.
- `style: "retro"`: a wooden CRT with knobs, scanlines and the channel OSD (`channel: "CH 07"`).

## laptop: him on a laptop
- `app`:
  - `player`: him in a window;
  - `call`: a call grid in the window (`others`);
  - `page`: `image` scrolled, with him in a corner circle.
- `url`, `title`.

## browser: a page and him
- `image`: the REAL screenshot of what he names, scrolled (`scroll: [from, to]` as fractions).
- `mark` / `mark_at`: a highlighter on his line.
- `url`, `title`.
- `pip`: him in a corner circle (on by default).
- `player: true` (or no `image`) makes him the page's video player instead, with `video_title`, `channel` and
  `views`.

## call: a video call
- `others`: `[{"name": "Chakra (AI)", "kind": "orb", "color"}, {"name": "Recruiter", "kind": "avatar"}]`.
- `title`, `clock_from` (the timer's start, in seconds), `me` (his name tag, default You).
- His tile gets a green speaking ring that follows his real voice level.

## cinema: him on the big screen
- The room is lit by his picture, with seats and heads in silhouette. The lights dim on entry after a `cut` or
  `rise`.

## polaroid: him in a photo on paper
- `caption`: handwritten (Caveat font).
- `angle` (default -3.5), `x`.
- Tape strips, a soft shadow and a drop-in entry.

## post: him in a social post
- `likes: [from, to]` count up across the beat. `like`: a double-tap heart.
- `caption`, `handle`, `place`, `x`.

## takeover: he is off screen, one idea owns the frame
- `kind`:
  - `statement` (`text` with *accent*, `kicker`, `sub`, `size`, `dark: true` for a black plate);
  - `number` (as in beside);
  - `list` (`title`, `items`);
  - `compare` (`left` / `right`: `{"title", "items": [["text", "w12"]], "good": bool}`);
  - `image` (a screenshot with a mark);
  - `chapter` (`num`, `title`).
- `pip: true` keeps him in a small corner circle; that counts as face-on.

## broll: another clip full screen
- `clip` (required), `label` (a small mono caption, e.g. "MEANWHILE").

## Type events (`type`: a list, drawn over any stage)
- `{"at", "until" | "dur", "text", "style", "pos", "size", "font", "max_w"}`.
- `style`:
  - `slam`: big, a scale-in shake, a hit sound. For punchlines; 1-3 words.
  - `pop`: a pill, for keywords. Set `accent: true` for an accent-coloured pill.
  - `words`: a phrase landing word by word.
  - `marker`: as `words`, with the accent underline.
  - `kicker`: a small mono label.
  - `sub`: an English subtitle for a Hinglish line.
  - `count`: a number counting up (`from`, `label`, `dur`).
- `pos`: `auto` (beside his face on `full`, top on others, the upper band on 9:16) | `center` | `top` | `bottom` |
  `left` | `right` | `upper` | `lower` | `[fx, fy]`.

## Adding a stage
Subclass `Stage` in `scripts/cbedit/stages.py`:
- `setup()` sets the layout and, if he sits in a screen rect, `self.screen`, so reveal and dive work.
- `draw(img, ctx)` starts with `v = self.view(img, ctx)`, draws in world px and puts him in with `ctx.him(v, x, y,
  w, h, r)`.
- Static chrome goes in a `Sprite` (drawn once, kept sharp under zoom).

Then register it in `STAGE_CLASSES`, `plan.STAGES`, `plan.FACE` and `check.CONTEXT`, and add it here and to the
SKILL.md table.
