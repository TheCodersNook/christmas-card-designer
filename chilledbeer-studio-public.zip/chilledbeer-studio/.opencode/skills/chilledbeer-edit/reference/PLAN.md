# edit.json: the plan the engine renders

`cbedit init` writes a starter. You fill `beats`, `type`, `punch`, `respell` and `music`. Paths are relative to
edit.json (or absolute). Two full worked plans are in `examples/`:
- `long_44s.edit.json`: 16:9, the hook, a reveal into the editor, a whip to a card, a phone DM, a takeover, a TV
  news ticker, a flash out;
- `reel_42s.edit.json`: 9:16 at 1.06× speed with full captions, covering the call, laptop, browser, polaroid, post,
  compare, cinema, retro TV and B-roll stages.

## Top level

| key | default | meaning |
|---|---|---|
| `name` | file stem | the output name: `out/<name>.mp4` (`_draft` for drafts) |
| `format` | `16:9` | `9:16` for a Reel or Short |
| `kind` | `long` | `reel` turns on the Reel budgets (faster cadence, 12 SFX a minute, captions on) |
| `res` | 1080 | the short side: 1080 = 1920x1080 / 1080x1920; 2160 = 4K. `draft_res` 540 |
| `fps` | the source's | never lower it on a final |
| `sources` | | `{"a": "take.mp4", "b": "take2.mp4"}`; segments name their `src` |
| `words` | | `words.json`, or `{"a": ..., "b": ...}` for several sources |
| `cut` | | `cut.json` (from `cbedit cut`), or an inline list of `{src, in, out}` in source seconds |
| `speed` | 1.0 | 1.04-1.06 for chatty takes; the pitch is kept (atempo) |
| `look` | `white` | `white` (his whitespace page, a faint grid) / `dark` / `paper` |
| `accent` | `#F0412B` | the one accent colour (his red pen) |
| `grade` | `clean` | `none` / `clean` (a touch of contrast and colour, his room as shot) / `warm` / `punchy` |
| `grid` | true | the page grid (it makes camera moves readable on white) |
| `handle` | `@yourhandle` | on the phone and post stages |
| `jumpcut` | true | alternate framing (×1.0 / ×1.1) on every join |
| `captions` | `full` on 9:16, `off` on 16:9 | `full` = 2-4 word groups with the active word in the accent |
| `respell` | `{}` | `{"w59": "Claude", "w145": "Antigravity."}`: fixes whisper's mishearings everywhere |
| `punch` | `[]` | `["w15", {"at": "w61", "z": 1.18, "hold": 1.2}]`: eased punches on stressed words |
| `beats` | one `full` | see STAGES.md |
| `type` | `[]` | see STAGES.md, "Type events" |
| `music` | none | `{"file", "db": -18 long / -12 reel, "duck": true, "lift_db", "quiet": [["w40", "w44"]], "name"}` |
| `sfx` | `auto` | `off` for none; `sfx_add: [["w12", "hit"]]` adds cues (whoosh, whoosh_deep, swish, hit, pop, click, static, tick) |
| `crf` / `preset` | 16 / medium | the final encode |
| `workers` | automatic safe limit | request fewer workers; the engine caps requests above its CPU/memory limit |

## Times

Anywhere a time is asked for:
- `12.4`: seconds on the OUTPUT timeline;
- `"w123"`: when word 123 starts in the cut;
- `"w123.end"`: when it ends;
- `"w123+0.2"` / `"w123.end-0.1"`: with an offset;
- `"b:w12"`: word 12 of source b.

Prefer word ids: they survive every re-cut. A dropped word resolves to the next kept one. `script.txt` lists each
kept sentence with its output time and word range; for single words, print the plan's word list:
`python -c "from cbedit.plan import Plan; p=Plan('edit.json'); print(' '.join(f\"{w['id']}@{w['s']:.2f}:{w['w']}\" for w in p.wlist))"`.

## A beat sheet in words (how to think before writing JSON)

```
0.0  full     push    hook: "If you're a content creator still editing manually..."   punch "stop"   slam STOP.
1.7  editor   reveal  "editing your videos"  -> razor splits on "stop"
5.0  beside   whip    "open-sourced my GitHub repo" -> card + "My exact workflow, *open-sourced.*"
10.8 phone    rise    "people were asking" -> DM banner "Sir, I don't have Claude Pro..."
17.7 takeover zoom    "students have Gemini" -> statement
22.4 full     fade    his question -> pop "In Gemini?"
27.5 beside   push    "can't use it in ChatGPT" -> circle + "Won't get *that level* of output."
35.3 tv       cut     "Gemini recently released Antigravity" -> LIVE + ticker
39.6 full     flash   the promise -> slam "Open source."
rhythm: FULL · EDITOR · BESIDE · PHONE · TAKEOVER · FULL · BESIDE · TV · FULL   (full 26 %, beside 31 %)
```
