# His style: what he wants, and why

Distilled from his feedback on every film so far (Oct 2026: ExpenseWaale, the automation Reels, Instinct, the
mutual-funds Reel, "who gonna hire", not-ai-made, the HackerRank Chakra interview). His words are in quotes.

## The feel

- **"Fast paced me."** He wants momentum: tight trims, his chatty takes at 1.04-1.06× speed, a change on screen
  every few seconds, and punch-in jump cuts (he likes them). It is fast, never frantic: one move per thought, and
  the camera eases, never shakes.
- **"Do dynamic zoom and focus more on my words."** The camera works on his words: punches on stressed words, zoom
  steps on repeated words, a push across a thought. The lens is always alive on him, with a change every 4-8 s.
- **"The video must feel connected."** Use a recurring device through the film: a chapter look, a callback to the
  hook at the end, a plant that pays off. It is one story, not a montage of clips.
- **"Holistic, not heavy."** Keep one idea per frame. Plain was the problem, never text: when a brief says "not much
  text", cut words, not ambition. His first Chakra sample got "trash" for being unedited and flat, and an early cut
  got "too boring, too plain".
- **The edit is the product.** An ungraded, untrimmed, static intro reads as raw footage. Fully edit the intro: grade
  it, set its pace, zoom it and type it. Never trim the intro's meaning away.

## Him on screen

- Show him full frame in his room as shot, or inside a closed shape: a circle, a card, a square or a device screen.
  "Do not just directly put me somewhere in the background, remove the person... Either the whole screen... or any
  closed box." Shapes can morph and move under camera moves.
- Never blur, whiten, mask or replace his room. When he says "bg", he means the background music.
- Captions never sit on his mouth.

## The context rule (why this skill exists)

His ask (2026-11-01): "If I am talking about video editing then put myself in a video editor and edit it, if talking
about TV or mobile then there." When he names a place, a device or an app, the frame becomes it and he is inside it,
on that line. Earlier versions of the same idea that he liked:
- the referenced website shown inside his own shot (on the whiteboard beside him, moving with the camera): the
  `full` stage's `insert`;
- the real product shown as itself (its real logo, its real site scrolled), researched first;
- the editor's timeline showing the real cuts and his real waveform, so the meta joke is true.

## Evidence

- The real thing, big enough to read on a phone: text 32 px or more at 1080p, and a mark on the line that matters.
- No placeholder payoffs (grey lines, "#1 #2 #3"): use real content, or ask him for the screenshot.
- Numbers come only from what he says, or are labelled as illustrations. Facts get a dated source.
- Private details are blurred: other people's data, emails and money figures.

## Sound

- Long-form: a calm bed about 18 dB under him (lo-fi, chill, soft piano), one or two beds for the whole film, ducking
  on his voice and lifting in pauses of 0.8 s or more. No EDM, rock or drops. He called loud NCS beds "too loud, too
  much, distracting... too rocky".
- Reels: music about 12 dB under. A drop on the reveal, or a stop on the punchline, is fine.
- No canned crowd: no cheers, applause or laugh tracks. Whooshes, hits, pops and room sound are fine.
- SFX are sparse and land a frame early, on a landing that means something.

## Reels

- Each one is a complete mini-talk in whole sentences (it may run past 60 s), never a teaser or a montage.
- Frame 1 is a finished composition with the stakes. Movement by 0.5 s, an open loop by 3 s.
- A visible change every 1.5-3 s. Re-hooks near 25 / 50 / 75 %. One peak at 60-80 %. End on the verdict line, with no
  dead tail.
- No end screen, except a ~2.5 s "full video on YouTube @ChilledBeer" card when a long video goes with it.
- Captions on (2-4 words, the active word in the accent colour), inside y 270-1350 on 1080x1920.

## Long-form

- A hook of 6-10 s on his face with the stakes on frame 1, then the promise.
- Takeovers take 15-30 % of the runtime, 4-12 s each, with 3 s+ of his face between two.
- 4K at 60 fps when the take is 4K60 (`"res": 2160`); never convert the frame rate down.
- B-roll is short (2-5 s), motivated by the line, about one a minute. Never overuse it.
- Chapter cards with real titles. A recap that calls back the opening.
- Upload copy: a title (keep the search terms), a description whose first 2 lines are the hook, chapters checked
  against the cut, credits (pages shown, music) and tags. Tick YouTube's "altered or synthetic content" box when
  AI-made shots of him are in it.

## Working with him

- Follow the footage: he shoots with the story in mind. Plan from his hook and the real order. Don't pitch invented
  storylines.
- Finish end to end and list what is still open, rather than stopping to ask small questions.
- Show a short sample before a whole film when the style is new to the film.
- When he shares a reference edit, take only the ideas he names.
- Previews render at 1080p or less. Render 4K once, at the end.

## Your notes (add new ones here, dated)

- (add your own notes here, dated)