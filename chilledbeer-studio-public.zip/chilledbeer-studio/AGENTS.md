# chilledbeer-studio: rules for the coding agent

You edit the creator's talking-head takes into finished YouTube videos and Reels in the ChilledBeer style. The
style and a complete render engine live in the skill `chilledbeer-edit`. The engine does the editing judgement (cut,
plan, camera, transitions, sound, checks). Your job:
- run it in order;
- read its reports;
- fix what they list;
- never break the rules.

**Before the first edit of a session, load the skill.** Use the skill tool, or read
`.opencode/skills/chilledbeer-edit/SKILL.md` (it ships inside this folder). Then read its `reference/STYLE.md`, `reference/STAGES.md` and
`reference/PLAN.md`.

You are already in the project folder. Don't `cd`. Run every engine command as `./cb ...` from here. Never call
python on the engine directly, never edit files inside the skill, and never `pip install` anything.

## Resource safety: mandatory

Treat **75% of available logical CPUs as a ceiling on WSL and a planning budget on macOS**. Keep the computer responsive for other work.
The packaged `./cb` now chooses a safe number of parallel render workers from CPU, memory and output resolution,
limits FFmpeg and transcription threads, gives its processes lower priority, and runs Whisper on CPU with GPU disabled.
Do not bypass `./cb`, launch a second edit, call FFmpeg/Whisper directly, bypass the worker/thread caps, or enable
Metal/CUDA/GPU processing. Use a cloud-hosted OpenCode model;
do not launch a local LLM server or another AI generation job while editing. Use a draft before a final render.
If the machine becomes sluggish, do not start another heavy step;
tell the user what is running and wait for them to stop it or free resources. These settings reduce load but cannot
promise an exact Activity Monitor percentage, especially when other apps are active.

## Folders
- `inputs/`: their raw takes (read only: never move, re-encode, overwrite or delete them).
- `edits/<name>/`: one folder per video (`<name>` is the take's file name without its extension):
  - `edit.json`: the plan;
  - `script.txt`: the cut, sentence by sentence: `time  s12  w140-w152  text`, where `s12` is the sentence id and
    `w140` a word id;
  - `auto_report.md`: the director's decisions and your to-do list;
  - `out/`: the videos, `stills.jpg` (one frame per beat) and `sheet.jpg`.
- `assets/`: screenshots and logos they give you.
- `music/long` and `music/reel`: the beds. See `music/README.md`.

## The workflow (follow it in this order)

0. **Get the take into `inputs/`.** They may give a file name, drag a video into the chat, attach it, or paste a path
   from anywhere (it may start with `@`, or have `\ ` before spaces). Unless it is already in `inputs/`, run
   `./cb add "<the path exactly as given>"`. It copies the file in with a safe name (the original is untouched) and
   prints the `inputs/...` path to use from now on. You can't watch a video, and you don't need to: the engine reads
   it.
1. **Make it:** run `./cb start make inputs/<file> --draft` (add `--reel` for a 9:16 Reel or Short). Then run
   `./cb wait` again and again until it prints `FINISHED exit=0`.
   - `start` runs the long job in the background, so your tool timeout can't kill it. Each `./cb wait` waits up to
     100 s and shows progress.
   - The job transcribes, tidies the cut, writes the plan, checks it and renders a quick draft.
   - If it ends with `exit=1`, read the last lines of the log it printed, then `edits/<name>/auto_report.md`.
2. **Read** `edits/<name>/auto_report.md` and `edits/<name>/script.txt` completely.
3. **Fix the words** (all of these BEFORE any hand edit to the plan):
   a. **Spellings.** The report lists "Names to check", each with its word ids. Whisper sometimes mishears a name
      ("Cloud" when they said Claude). Fix a name only when you are confident it is wrong, using the topic of the
      video; leave correct names alone. Find a word's id with `./cb words edits/<name>/edit.json --word Cloud`
      (prints `w59@14.82:Cloud`). Add the fix to `"respell"` in edit.json as `{"<word id>": "<correct spelling>"}`,
      keeping the word's punctuation. If you are unsure, don't guess: list it as open.
   b. **Cut.** Drop only WHOLE sentences:
      - **Restarts:** they say the same line again. Drop the earlier, keep the LAST.
      - **Asides:** filler sentences that add nothing ("Right?", "Like we all know that.", "So, yeah."). The report
        lists possible asides.
      - **Off-topic** stretches.

      Keep questions they ask the viewer, even when two ask nearly the same thing; they are part of how they talk.
      Run `./cb cut edits/<name>/edit.json --drop 12,19`, where the numbers are `s` ids from script.txt. Drops add to
      the earlier ones, and `--keep 12` takes one back. If nothing needs dropping, skip this.
   c. **Re-plan, once:** `./cb auto edits/<name>/edit.json --no-recut`. Then re-read the new `auto_report.md`.
4. **Do the report's to-do list** by editing `edits/<name>/edit.json`:
   - **Hinglish lines:** add English subtitle events exactly as the report shows into `"type"`:
     `{"at": "w40", "until": "w52.end", "style": "sub", "text": "<faithful English meaning>"}`.
   - **On-screen texts:** every `"text"` in beats and type events must be THEIR words from that beat's sentences, with
     at most ~7 words and one `*accent*` on the key word. Replace a weak one (for example "Discuss that *only.*")
     with a stronger phrase from the same beat. Never invent words, claims or numbers.
   - **Browser and screenshots:** a browser beat with `"player": true` shows their own video as a page's player. That
     is fine. Only when a screenshot of the site they name is in `assets/`, switch it to the page:
     `"props": {"image": "../../assets/<file>.png", "url": "<site>", "scroll": [0, 0.5]}`. Otherwise list
     "screenshot of <site>" as open.
   - **Opportunity lines** (from `./cb check`): these are ideas, not tasks. Leave them unless they asked for more
     context scenes.
5. **Gate and look:**
   - Run `./cb check edits/<name>/edit.json`. It must show `0 errors`. Fix each WARN (each says what to change), or
     say in your report why you kept it.
   - Then run `./cb stills edits/<name>/edit.json --auto`. This refreshes `out/stills.jpg`, one frame per beat, for
     them to look at.
6. **Render.** For a 4K take that they want in 4K, set `"res": 2160` in edit.json first. Then run each of these with
   `./cb start ...`, followed by `./cb wait` until FINISHED:
   - `./cb start render edits/<name>/edit.json --draft`: replaces the step-1 draft with your fixed plan, as
     `out/<name>_draft.mp4`.
   - `./cb start render edits/<name>/edit.json`: the final `out/<name>.mp4`. This also refreshes `out/stills.jpg`.
   - Then `./cb qa edits/<name>/out/<name>.mp4 --sheet edits/<name>/out/sheet.jpg`. It must say `qa: PASS`.
7. **Report back** in 6-10 lines:
   - the output path;
   - the length;
   - the rhythm line from auto_report.md;
   - what you changed;
   - what is still open (screenshots, names you could not confirm);
   - the music file used (remind the user to credit it if its licence asks).

   Then ask them to watch it, along with `out/stills.jpg`.

## The rules (never break them)

1. Whole sentences only. Never cut inside a sentence.
2. The creator is shown full screen in their own room, or inside a shape or device screen. Never blur, replace or whiten their
   background.
3. The video opens on their face. There is no logo or title card first.
4. On-screen words are their words. Numbers only if they said them. No invented facts.
5. Handles shown on screen come from `"handle"` in edit.json: set it to your own.
6. Reels have no end screen.
7. Keep the frame rate and quality: never lower `fps` or `crf`, and never add filters.

## Editing the plan by hand (when they give feedback)

Use STAGES.md (the props of every stage) and PLAN.md (the schema).
- **Times are word ids** (`"w123"`, `"w123.end"`, `"w123+0.2"`), so they survive re-cuts. Use them, not seconds.
  `./cb words <edit.json> --find <text>` finds ids, and `--word <word>` matches the whole word only.
- **After hand edits, NEVER run `./cb auto` again:** it rewrites `beats`, `type` and `punch` and loses your edits. To
  change the cut, use `./cb cut` (word ids keep the plan valid). Then run `./cb check`, `./cb stills ... --auto`,
  and render.
- **You may not be able to see images.** Don't claim you looked at a frame. Rely on `./cb check` (it measures text
  over their face, still stretches, layout share, time away and transitions) and on `qa`. When something is visual,
  ask them to look at `out/stills.jpg`.

Common feedback, and what to change:
| They say | Change |
|---|---|
| "too slow" / "fast paced me" | `"speed": 1.06`; more `punch` word ids (3 s+ apart) |
| "text on my face" | that type event's `"pos": "left"` / `"right"` / `"top"` |
| "put me in the editor/phone/TV here" | that beat's `"stage"`; its `"why"` quotes their words; props from STAGES.md |
| "music too loud" / "too soft" | `music.db` -20 / -15 (long-form), -14 / -10 (Reel) |
| "remove this line" | `./cb cut ... --drop <sentence id>` |
| "zoom on this word" | add the word id to `"punch"` |
| "wrong word on screen" | fix `"respell"` or the type event's `"text"` |
| "captions" / "no captions" | `"captions": "full"` / `"off"` |

## Commands you need (all allowed without asking)

- `./cb ...` (including `./cb add "<path>"` for a take from anywhere);
- `ls`, `cat`, `head`, `tail`, `grep`, `wc`, `find`;
- `ffprobe` (optional: the engine already checks the take).

Anything else asks them for permission, so avoid it. Don't chain commands with `&&` or `;`: run one per call.

## Don'ts
- Don't touch the skill's files, `inputs/`, or another video's folder.
- Don't write a plan from scratch: `./cb make` and `./cb auto` write better ones.
- Don't render 4K drafts. Don't run two jobs at once (`./cb start` refuses while one runs).
- Run short commands (`words`, `cut`, `auto`, `check`, `stills`, `qa`) directly. Only `make` and `render` go through
  `./cb start` + `./cb wait`.
- Don't push this folder anywhere. Keep the user's videos and output on their own computer.
