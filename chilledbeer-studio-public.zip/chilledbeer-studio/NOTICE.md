# Third-party notices

- **Fonts** in `.opencode/skills/chilledbeer-edit/assets/fonts/`: Inter, Schibsted Grotesk, JetBrains Mono, Caveat,
  Anton and Instrument Serif. All are under the SIL Open Font License 1.1 (from Google Fonts).
- **Face detection model**: `face_detection_yunet_2023mar.onnx`, YuNet from OpenCV Zoo, MIT License.
- **Tools it calls** (installed separately): FFmpeg, whisper.cpp / faster-whisper, OpenCV, OpenCode.
